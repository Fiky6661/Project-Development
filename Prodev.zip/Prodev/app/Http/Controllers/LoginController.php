<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\User;

class LoginController extends Controller
{
    public function __construct(){
        $this->middleware('guest');
    }
    
    public function getLogin(){
        
    return view('login');
    }

    public function postLogin(Request $request){
        
        //ADMIN==========================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 1
        ])){
            return redirect('/userapproval');
        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 1
        ])){
            return redirect('/userapproval');
        }

        //PV============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 2
        ])){
            return redirect()->route('approvalformula');
        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 2
        ])){
            return redirect()->route('approvalformula');
        }

        //Development============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 3
        ])){
            return redirect()->route('myworkbooks');
        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 3
        ])){
            return redirect()->route('myworkbooks');
        }
        
        //Produksi============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 4
        ])){
            return redirect()->route('formula.feasibility');
        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 4
        ])){
            return redirect()->route('formula.feasibility');        }

        //KEMAS============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 5
        ])){
            return redirect()->route('formula.feasibility');        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 5
        ])){
            return redirect()->route('formula.feasibility');        }

        //Evaluator============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 6
        ])){
            return redirect()->route('formula.feasibility');
        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 6
        ])){
            return redirect()->route('formula.feasibility');
        }

        //Finance============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 7
        ])){
            return redirect()->route('formula.feasibility');        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 7
        ])){
            return redirect()->route('formula.feasibility');        }

        //SuperAdmin============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 8
        ])){
            return redirect('/');
        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 8
        ])){
            return redirect('/');
        }

        //Lab============================================================================================
        if(Auth::attempt([
            'email' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 9
        ])){
            return redirect()->route('formula.feasibility');        }
        elseif(Auth::attempt([
            'username' =>$request->inputEmailUser,
            'password' => $request->password,
            'status' => 'active',
            'role_id' => 9
        ])){
            return redirect()->route('formula.feasibility');        }

        //Gagal==========================================================================================
        else{
            return back()->withErrors([
                'message' => 'The email Username or password is incorrect, or maybe your Account have not approve'
            ]);
        }
    }
}
