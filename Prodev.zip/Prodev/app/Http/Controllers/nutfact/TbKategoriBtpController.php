<?php

namespace App\Http\Controllers\nutfact;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TbKategoriBtpController extends Controller
{
    //
}
