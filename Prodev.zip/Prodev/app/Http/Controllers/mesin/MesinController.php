<?php

namespace App\Http\Controllers\mesin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Modelmesin\workcenter;
use App\Modelmesin\kategori;
use App\Modelmesin\datamesin;
use App\Modelfn\finance;
use App\modelfn\pesan;
use App\Modelmesin\Dmesin;
use App\Modelmesin\oh;

class MesinController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        $this->middleware('rule:evaluator');
    }

    public function index($id)
    {
        $workcenter =workcenter::all();
        $kategori =kategori::all();
        $mesins = datamesin::all();
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        $fe=finance::find($id);
        return view('mesin.datamesin')->with([
            'id' => $id,
            'fe' => $fe,
            'mesins' => $mesins,
            'dataF' => $dataF,
            'workcenter' => $workcenter,
            'kategori' => $kategori
            ]);
    }

    public function inbox($id)
    {
        $inboxs = pesan::all()->sortByDesc('created_at')->where('user','inputor');
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        return view('mesin.inboxmesin')
        ->with(['id' => $id])
        ->with(['dataF' => $dataF])
        ->with(['inboxs' => $inboxs]);
    }

    public function runM(Request $request, $id_mesin)
    {
        $data_mesin = Dmesin::where('id_mesin', $id_mesin)->first();
        $input = $request->all();
        $data_mesin->runtime = $input['runtime'];
        $data_mesin->save();

        return redirect()->back();
	 }
	 
	 public function runO(Request $request, $id_oh)
    {
        $data_oh = oh::where('id_oh', $id_oh)->first();
        $input = $request->all();
        $data_oh->runtime = $input['runtime'];
        $data_oh->save();

        return redirect::back();
   }

   public function runtimemesin($id)
    {
        $mesins = datamesin::all();
        $update =Dmesin::all();
        $fe=finance::find($id);
        $Mdata = Dmesin::with('meesin')->get()->where('id', $id);
        $dataF = finance::with('formula')->get()->where('idy', $id)->first();
        return view('mesin.runtimemesin',['fe'=>$fe])
        ->with(['update' => $update])
        ->with(['mesins' => $mesins])
        ->with(['dataF' => $dataF])
        ->with(['id' => $id])
        ->with(['Mdata' => $Mdata ]);
    }

    public function runtimeoh($id)
    {
        $fe=finance::find($id);
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        $dataO = oh::with('dataoh')->get()->where('id', $id);
        return view('mesin.runtimeoh',['fe'=>$fe])
        ->with(['id' => $id])
        ->with(['dataF' => $dataF])
        ->with(['dataO' => $dataO]);
    }

    public function destroy($id)
    {
        $mesin = Dmesin::find($id);
        $mesin->delete();
        return redirect::back()->with('message', 'Data berhasil dihapus!');
    }

    public function destroyoh($id)
    {
        $mesin = oh::find($id);
        $mesin->delete();
        return redirect::back()->with('message', 'Data berhasil dihapus!');
    }
    
}
