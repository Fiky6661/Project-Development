<?php

namespace App\Http\Controllers\produksi;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Modelmesin\datamesin;
use App\Modelfn\finance;
use App\Modelmesin\Dmesin;
use App\Modelmesin\oh;
use App\modelfn\pesan;

class ProduksiController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        $this->middleware('rule:produksi');
    }
    
    public function index($id)
    {
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        $dataM = Dmesin::with('meesin')->get()->where('id', $id);
        $dataO = oh::with('dataoh')->get()->where('id', $id);
        $fe=finance::find($id);
        return view('produksi.produksi')->with([
            'fe'=>$fe,
            'id' => $id,
            'dataM' => $dataM,
            'dataO' => $dataO,
            'dataF' => $dataF
            ]);
        
    }

    public function inbox($id)
    {
        $inboxs = pesan::all()->sortByDesc('created_at')->where('user','produksi');
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        return view('produksi.inboxproduksi')->with([
            'inboxs' => $inboxs,
            'dataF' => $dataF,
            'id' => $id,]);
    }
}
