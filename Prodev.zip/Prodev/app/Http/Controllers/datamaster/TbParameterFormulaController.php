<?php

namespace App\Http\Controllers\datamaster;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TbParameterFormulaController extends Controller
{
    public function datanut(){
        return view('nutfact.nutfact');
    }
}
