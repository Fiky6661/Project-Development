<?php

namespace App\Http\Controllers\formula;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\dev\Bahan;
use App\master\Satuan;
use App\master\Subkategori;
use App\master\Curren;
use App\master\Kelompok;
use Auth;
use Redirect;

class MyRamenController extends Controller
{
    public function __construct(){
        
        $this->middleware('auth');
        $this->middleware('rule:development');
    }
    
    public function index($idf){
        $satuans = Satuan::all();
        $subkategoris = Subkategori::all();
        $currens = Curren::all();
        $kelompoks = Kelompok::all();
        return view('formula.myramen')->with([
            'satuans' =>$satuans,
            'subkategoris' => $subkategoris,
            'currens' => $currens,
            'kelompoks' => $kelompoks,
            'idf' => $idf
            ]);

    }

    public function insert($idf,Request $request){
        $bahan = new Bahan;
        $bahan->nama_sederhana = $request->nama_sederhana;
        $bahan->nama_bahan = $request->nama_bahan;
        $bahan->kode_oracle = $request->kode_oracle;
        $bahan->kode_komputer = $request->kode_komputer;
        $bahan->supplier = $request->supplier;
        $bahan->principle = $request->principle;
        $bahan->no_HEIPBR = $request->no_HEIPBR;
        $bahan->PIC = $request->PIC;
        $bahan->cek_halal = $request->cek_halal;
        $bahan->subkategori_id = $request->subkategori;
        $bahan->kelompok_id = $request->kelompok;
        $bahan->berat = $request->berat;
        $bahan->satuan_id = $request->satuan;
        $bahan->harga_satuan = $request->harga_satuan;
        $bahan->curren_id = $request->curren;
        $bahan->user_id = $request->user;
        $bahan->status = 'nonactive';
        $bahan->save();

        return Redirect()->route('step2',$idf)->with('status', 'Departement '.$bahan->nama_sederhana.' Telah Ditambahkan!');
    }
}
