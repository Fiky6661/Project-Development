<?php

namespace App\Http\Controllers\formula;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\master\Subbrand;
use App\master\Gudang;
use App\master\Produksi;
use App\master\Maklon;
use App\User;
use App\users\Departement;
use App\dev\Workbook;
use App\dev\Formula;
use App\dev\Fortail;
use App\dev\Premix;
use App\dev\Pretail;
use App\dev\Bahan;

class Step3Controller extends Controller
{
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:development');
    }
    
    public function create($id){
        $no = 1;
        $formula = Formula::where('id',$id)->first();
        $fortails = Fortail::where('formula_id',$formula->id)->get();
        return view('formula/step3')->with([
            'no' => $no,
            'fortails' => $fortails,
            'formula' => $formula
            ]);
    }

    
}
