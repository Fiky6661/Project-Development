<?php

namespace App\Http\Controllers\formula;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\master\Subbrand;
use App\master\Gudang;
use App\master\Produksi;
use App\master\Maklon;
use App\User;
use App\users\Departement;
use App\dev\Workbook;
use App\dev\Formula;
use App\dev\Fortail;
use App\dev\Premix;
use App\dev\Pretail;
use App\dev\Bahan;

class Step1Controller extends Controller
{
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:development');
    }
    
    public function create($id){
        $depts = Departement::all();
        $subbrands = Subbrand::all();
        $gudangs = Gudang::all();
        $produksis = Produksi::all();
        $maklons = Maklon::all();
        $formula = Formula::find($id);
        return view('formula/step1')->with([
            'formula' => $formula,
            'depts' => $depts,
            'subbrands' => $subbrands,
            'gudangs' => $gudangs,
            'produksis' => $produksis,
            'maklons' => $maklons,
            ]);
    }

    public function update($id,Request $request){

        $this->validate(request(), [
            'bj' => 'numeric',
            'batch' => 'numeric',
            'serving' => 'numeric',
            'liter' => 'numeric'
        ]);

        $formula = Formula::find($id);
        $formula->nama_produk = $request->nama_produk;
        $formula->kode_formula = $request->kode_formula;
        $formula->subbrand_id = $request->subbrand;
        $formula->gudang_id = $request->gudang;
        $formula->produksi_id = $request->produksi;
        $formula->maklon_id = $request->maklon;
        $formula->main_item = $request->main_item;
        $formula->main_item_eks = $request->main_item_eks;
        $formula->bj = $request->bj;
        $formula->batch = $request->batch;
        $formula->serving = $request->serving;
        $formula->liter = $request->liter;
        $formula->keterangan = $request->keterangan;
        $formula->save();
        
        return Redirect()->route('step2', $formula->id);

    }

    
}
