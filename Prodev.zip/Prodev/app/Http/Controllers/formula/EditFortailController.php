<?php

namespace App\Http\Controllers\formula;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\dev\Fortail;
use App\dev\Bahan;

class EditFortailController extends Controller
{
    public function __construct(){
            
        $this->middleware('auth');
        $this->middleware('rule:development');
        }
        
    public function index($idf,$id){
        
        $fortail = Fortail::where('id',$id)->first();
        $myprioritas = Bahan::where('id',$fortail->bahan_id)->first();
        $bahans = Bahan::all();
        $count_bahan = 5;
        for($i = 2;$i<=5;$i++){
            $ask = 'kode_komputer'.$i;
            $ii=$i-1;
            $alternatif[$ii] = Bahan::where('kode_komputer',$fortail->$ask)->first();
            if($fortail->$ask == null){
                $count_bahan--;
            }
        }
        $count_alternatif = $count_bahan-1;

        return view('formula.editfortail')->with([
            'idf' => $idf,
            'fortail' => $fortail,
            'bahans' => $bahans,
            'count_bahan' => $count_bahan,
            'count_alternatif' => $count_alternatif
        ]);
    }

    public function update($idf,$id,Request $request){

        $bp = Bahan::where('id', $request->prioritas)->first();
        $pkk = $bp->kode_komputer;
        $pns = $bp->nama_sederhana;
        $pko = $bp->kode_oracle;

        $fortails = Fortail::where('id',$id);
        $fortails->kode_komputer1 = $bp->kode_komputer;

        $c = $request->c;
        if($c>0){
            for($d = 1;$d<=$c;$d++){
                $ba[$d] =  Bahan::where('id',$request->alternatif[$d])->first();
                $pkk = $pkk.' / '.$ba[$d]->kode_komputer;
                $pns = $pns.' / '.$ba[$d]->nama_sederhana;
                $pko = $pko.' / '.$ba[$d]->kode_oracle;
                $e=$d+1;
                
                $nk = 'kode_komputer'.$e;
                $fortails->$nk = $ba[$d]->kode_komputer;
            }
        }
        

        $fortails->formula_id = $idf;
        $fortails->kode_komputer = $pkk;
        $fortails->nama_sederhana = $pns;
        $fortails->kode_oracle = $pko;
        $fortails->bahan_id = $bp->id;
        $fortails->nama_bahan = $bp->nama_bahan;
        $fortails->per_batch = $request->per_batch;
        $fortails->per_serving = $request->per_serving;
        if($c>0){
            $fortails->alternatif= $ba[1]->nama_sederhana;
        }
        if($request->per_batch >= 3000){
            $fortails->jenis_timbangan='B';
        }elseif($request->per_batch < 3000){
            $fortails->jenis_timbangan='A';
        }

        // $fortails->save();

        return Redirect()->route('step2',$idf)->with('status','Bahan Baku Telah Di Update');
    }
}
