<?php

namespace App\Http\Controllers\formula;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\master\Subbrand;
use App\master\Gudang;
use App\master\Produksi;
use App\master\Maklon;
use App\User;
use App\users\Departement;
use App\dev\Workbook;
use App\dev\Formula;
use App\dev\Fortail;
use App\dev\Premix;
use App\dev\Pretail;
use App\dev\Bahan;
use Auth;
use DB;
use Redirect;

class Step2Controller extends Controller
{
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:development');
    }
    
    public function create($id){
        

        $formula = Formula::find($id)->first();
        $idf = $id;
        $fortails = Fortail::where('formula_id',$id)->get();
        $ada= Fortail::where('formula_id',$id)->count();
        $bahans = Bahan::where('status','active')->orWhere('user_id',Auth::id())->get();
        $no = 1;
        return view('formula/step2')->with([
            'formula' => $formula,
            'fortails' => $fortails,
            'bahans' => $bahans,
            'no' => $no,
            'idf' => $idf,
            'ada' => $ada,
            ]);
        }

    public function insert($vf,Request $request){
        

        $bp = Bahan::where('id', $request->prioritas)->first();
        $pkk = $bp->kode_komputer;
        $pns = $bp->nama_sederhana;
        $pko = $bp->kode_oracle;

        $fortails = new Fortail;

        $c = $request->c;
        if($c>0){
            for($d = 1;$d<=$c;$d++){
                $ba[$d] =  Bahan::where('id',$request->alternatif[$d])->first();
                $pkk = $pkk.' / '.$ba[$d]->kode_komputer;
                $pns = $pns.' / '.$ba[$d]->nama_sederhana;
                $pko = $pko.' / '.$ba[$d]->kode_oracle;
                $e=$d+1;
                
                $nk = 'kode_komputer'.$e;
                $fortails->$nk = $ba[$d]->id;
            }
        }
        

        $fortails->formula_id = $vf;
        $fortails->kode_komputer = $pkk;
        $fortails->nama_sederhana = $pns;
        $fortails->kode_oracle = $pko;
        $fortails->bahan_id = $bp->id;
        $fortails->nama_bahan = $bp->nama_bahan;
        $fortails->per_batch = $request->per_batch;
        $fortails->per_serving = $request->per_serving;
        if($c>0){
            $fortails->alternatif= $ba[1]->nama_sederhana;
        }
        if($request->per_batch >= 3000){
            $fortails->jenis_timbangan='B';
        }elseif($request->per_batch < 3000){
            $fortails->jenis_timbangan='A';
        }

        $fortails->save();

        return Redirect::back()->with('status','BahanBaku Berhasil Ditambahkan');
    }

    public function destroy($id,$vf){
        $fortail = Fortail::where([
            ['id',$id],
            ['formula_id',$vf]
            ])->first();
        $premixs = Premix::where('fortail_id',$fortail->id)->get();
                foreach($premixs as $premix){
                    $pretails = Pretail::where('premix_id',$premix->id)->get();
                    foreach($pretails as $pretail){
                        $pretail->delete();
                    }
                $premix->delete();
                }
            $fortail->delete();
        return Redirect::back()->with('error','BahanBaku Telah Berhasil Dihapus');
    }


    
}