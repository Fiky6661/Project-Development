<?php

namespace App\Http\Controllers\finance;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Modelmesin\Dmesin;
use App\Modelmesin\oh;
use App\Modelfn\finance;
use App\Modelfn\pesan;
use App\Modelmesin\aktifitasOH;
use App\Modelmesin\workcenter;
use App\Modelmesin\kategori;
use App\Modelmesin\datamesin;

class FinanceController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        $this->middleware('rule:finance');
    }

    public function index($id)
    {
        $dataM = Dmesin::with('meesin')->get()->where('id', $id);
        $dataO = oh::with('dataoh')->get()->where('id', $id);
        $fe=finance::find($id);
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        return view('finance.finance')->with([
            'id' => $id,
            'fe' => $fe,
            'dataM' => $dataM,
            'dataO' => $dataO,
            'dataF' => $dataF
        ]);
    }

    public function inboxfn($id)
    {
        $inboxs = pesan::all()->sortByDesc('created_at');
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
       return view('finance.inboxfn')->with([
            'id' => $id,
           'inboxs' => $inboxs,
            'dataF' => $dataF
            ]);
    }

    public function komentar($id)
    {
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        $fe=finance::find($id);
        return view('finance.komentar')->with([
            'id' => $id,
            'fe' => $fe,
            'dataF' => $dataF
        ]);
    }

    public function store(Request $request)
    {
        $fnn= new pesan;
        $fnn->id_feasibility=$request->finance;
        $fnn->pengirim='finance';
        $fnn->user=$request->get('users');
        $fnn->subject=$request->sub;
        $fnn->message=$request->get('mail');
        $fnn->save();

    	return redirect()->route('myFeasibility');
    }

    public function DMmesin($id)
    {
        $workcenter =workcenter::all();
        $kategori =kategori::all();
        $mesins = datamesin::all();
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        $dataM = Dmesin::with('meesin')->get()->where('id', $id);
        $fe=finance::find($id);
        return view('finance.DMmesin')->with([
            'dataM' => $dataM,
            'mesins' => $mesins,
            'id' => $id,
            'fe' => $fe,
            'dataF' => $dataF,
            'workcenter' => $workcenter,
            'kategori' => $kategori
            ]);
    }

    public function DMoh($id)
    {
      $workcenter =workcenter::all();
        $kategori =kategori::all();
        $aktifitas = aktifitasOH::all();
        $dataO = oh::with('dataoh')->get()->where('id', $id);
        $dataF = finance::with('formula')->get()->where('id', $id)->first();
        $fe=finance::find($id);
        return view('finance.DMoh')->with([
            'id' => $id,
            'fe' => $fe,
            'aktifitas' => $aktifitas,
            'dataO' => $dataO,
            'workcenter' => $workcenter,
            'kategori' => $kategori,
            'dataF' => $dataF
            ]);
    }

    public function createDMmesin(Request $request)
    {

      $Dm= new datamesin;
      $Dm->workcenter=$request->workcenter;
      $Dm->gedung=$request->gedung;
      $Dm->kategori=$request->kategori;
      $Dm->Direct_Activity=$request->aktifitas;
      $Dm->nama_kategori=$request->Nkategori;
      $Dm->save();
        
      return redirect()->back();
    }

    public function createDMoh(Request $request)
    {

      $Do= new aktifitasOH;
      $Do->workcenter=$request->workcenter;
      $Do->gedung=$request->gedung;
      $Do->kategori=$request->kategori;
      $Do->direct_activity=$request->aktifitas;
      $Do->driver=$request->driver;
      $Do->save();
        
      return redirect()->back();
    }
}
