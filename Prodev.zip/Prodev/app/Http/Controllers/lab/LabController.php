<?php

namespace App\Http\Controllers\lab;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Modellab\Dlab;
use App\Modelfn\finance;

class LabController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        $this->middleware('rule:lab');
    }

    public function index($id)
    {
        $fe=finance::find($id);
        return view('lab.datalab',['fe'=>$fe]);
    }

    public function create(Request $request)
    {
        
        $lab= new Dlab;
        $lab->id_feasibility=$request->get('finance');
    	$lab->refer_exist=$request->refer;
    	$lab->nama_item=$request->item;

    	$lab->jumlah_sample=$request->sempel;
    	$lab->parameter=$request->parameter;
        $lab->total=$request->total;
        
        $lab->save();

        $lab= new finance;
        $lab->status_lab='sending';
        $lab->save();

    	return redirect()->route('formula.feasibility');
    }
}
