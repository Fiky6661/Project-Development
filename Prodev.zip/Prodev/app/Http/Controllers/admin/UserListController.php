<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\users\Departement;
use App\Role;
use Redirect;

class UserListController extends Controller
{
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:admin');
    }

    public function index()
    {
        $users = new User;
        $users = User::all();
        return view('admin.listuser')->with([
            'users' => $users]);
    }

    public function blok($id){

        $user = User::find($id)->update(['status'=>'nonactive']);
        return Redirect::back();
        }

    public function open($id){

        $user = User::find($id)->update(['status'=>'active']);
        return Redirect::back();
    }
        
    

    public function show($id)
    {
        $users = User::find($id);
        $roles = Role::all();
        $depts = Departement::all();

        return view('admin.detail')->with([
            'users' => $users,
            'depts' =>$depts,
            'roles' =>$roles]);
    }

    public function update($id,Request $request)
    {
        
        $user = User::find($id);
        
        $this->validate(request(), [
            'username' => 'unique:users,username,'.$user->id,
            'email' => 'unique:users,email,'.$user->id
        ]);
        
        
        $user->name = $request->name;
        $user->username = $request->username;
        $user->email = $request->email;
        $user->departement_id = $request->departement;
        $user->role_id = $request->role;
        $user->save();
        
        return Redirect::back()->with('status','Profil User Telah Dirubah !');
    }
}
