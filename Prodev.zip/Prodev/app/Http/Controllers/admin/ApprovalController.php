<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Yajra\Datatables\Datatables;

class ApprovalController extends Controller
{
    
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:admin');
    }
    
    public function index()
    {
        
        $users = new User;
        $users = User::all();
        return view('admin.approval')->withusers($users);
    }

    public function update($id)

    {

        $affectedRows = User::where('id', '=', $id)->update(['status' => 'active']);
        return redirect()->to('userapproval');

    }

    public function destroy($id)

    {

        $affectedRows = User::where('id', '=', $id)->delete();
        return redirect()->to('userapproval');

    }
}
