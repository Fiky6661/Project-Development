<?php

namespace App\Http\Controllers\feasibility;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modelfn\finance;
use App\dev\Formula;
use Redirect;

class ListFeasibilityController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    public function index($id){
        $myFormula = Formula::where('id',$id)->first();
        $dataF = finance::where('id_formula',$id)->get();

        return view('feasibility.feasibility')->with([
            'myFormula' => $myFormula,
            'dataF' => $dataF
        ]);
    }
}
