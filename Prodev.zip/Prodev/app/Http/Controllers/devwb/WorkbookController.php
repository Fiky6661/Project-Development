<?php

namespace App\Http\Controllers\devwb;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\dev\Workbook;
use App\dev\Formula;
use App\dev\Fortail;
use App\dev\Premix;
use App\dev\Pretail;
use App\master\Tarkon;
use App\User;   
use Auth;
use Redirect;

class WorkbookController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        $this->middleware('rule:development');
    }

    public function index()
    {
        
        $id = Auth::id();
        $workbooks = Workbook::where('user_id',$id)->get();
        
        foreach ($workbooks as $workbook){
            $formulas = Formula::where('workbook_id',$workbook->id)->get();
            $count_proses = 0;
            $count_selesai = 0;
            foreach ($formulas as $formula){
                if($formula->status == 'proses'){
                    $count_proses = $count_proses+1;
                    if($count_proses==1){
                        $workbook->status = 'proses';
                            if($formula->vv == 'proses'){
                                $workbook->keterangan = 'Formula '.$formula->nama_produk.' Versi '.$formula->versi.' Sedang Dalam Proses Pengecekan Oleh PV';
                            }
                            elseif($formula->status_fisibility == 'proses'){
                                $workbook->keterangan = 'Formula '.$formula->nama_produk.' Versi '.$formula->versi.' Sedang Dalam Proses Pengecekan Feasibility';
                            }
                            elseif($formula->status_nutfact == 'proses'){
                                $workbook->keterangan = 'Formula '.$formula->nama_produk.' Versi '.$formula->versi.' Sedang Dalam Proses Pengecekan Nutrition Fact';
                            }
                        $workbook->save();
                    }
                }
                elseif($formula->status == 'selesai'){
                    $count_selesai = $count_selesai+1;
                    if($count_selesai ==1){

                        $workbook->status = 'selesai';
                        $workbook->keterangan = 'Formula '.$formula->nama_produk.' Versi '.$formula->versi.' Selesai';
                        $workbook->save();
                    }
                    
                }
            }
            
            if($count_proses==0){

                    $workbook->status = null;
                    $workbook->keterangan = 'Tidak ada Formula Yang Sedang Dalam Proses';
                    $workbook->save();
            }
        }

        $tarkons = new Tarkon;
        $tarkons = Tarkon::all();
        return view('devwb.workbooks')->with([
            'workbooks' => $workbooks,
            'tarkons' => $tarkons]);
    }

    public function store(Request $request)
    {
        
        $workbooks = new Workbook;
        $workbooks->user_id = $request->user;
        $workbooks->nama_project = $request->nama;
        $workbooks->mnrq = $request->mnrq;
        $workbooks->tarkon_id = $request->tarkon;
        $workbooks->save();
        
        return Redirect::back()->with('status', 'Workbook '.$workbooks->nama_project.' Telah Ditambahkan!');
    }

    public function update($id,Request $request)
    {
        
        $workbooks = Workbook::find($id);
        $workbooks->nama_project = $request->nama;
        $workbooks->mnrq = $request->mnrq;
        $workbooks->tarkon_id = $request->tarkon;
        $workbooks->save();
        
        return Redirect::back()->with('status', 'Workbook '.$workbooks->nama_project.' Berhasil Di Update!');
    }

    public function show($id)
    {
        
        $workbooks = Workbook::find($id);
        $formulas = DB::table('formulas')->where('workbook_id', $id)->get();

        // FormulaProses
        $Forpros = $formulas->where('status','proses')->first();
        $cp=0;
         if($Forpros!=null){
             $cp=$cp+1;
         }
         // FormulaSelesai
         $Forsel = $formulas->where('status','selesai')->first();
         $cs=0;
          if($Forsel!=null){
              $cs=$cs+1;
          }

        $cf=Formula::where('workbook_id', $id)->count();
        $tarkons = new Tarkon;
        $tarkons = Tarkon::all();
        $users = DB::table('users')->where([
            ['id',"!=", Auth::id()],
            ['role_id', Auth::user()->role_id],
            ['status', 'active']
            ])->get();

        return view('devwb.formulas')->with([
            'workbooks' => $workbooks,
            'formulas' => $formulas,
            'Forpros' => $Forpros,
            'cp' => $cp,
            'cs' => $cs,
            'cf' => $cf,
            'tarkons' => $tarkons,
            'users' => $users,
            ]);
    }

    public function alihkan($id,Request $request)
    {
        
        $workbooks = Workbook::find($id);
        $workbooks->user_id = $request->user;
        $workbooks->save();
        $pp = User::find($request->user);
        
        return Redirect()->route('myworkbooks')->with('status', 'Workbook '.$workbooks->nama_project.' Telah Dialihkan Kepada '.$pp->name);
    }

    public function destroy($id)
    {
        // find all & delete all
        $workbook = Workbook::where([
            ['id',$id],
            ['user_id',Auth::id()]
        ])->first();
        $n = $workbook->nama_project;

        $formulas = Formula::where('workbook_id',$workbook->id)->get();
        foreach($formulas as $formula){
            $fortails = Fortail::where('formula_id',$formula->id)->get();
            foreach($fortails as $fortail){
                $premixs = Premix::where('fortail_id',$fortail->id)->get();
                foreach($premixs as $premix){
                    $pretails = Pretail::where('premix_id',$premix->id)->get();
                    foreach($pretails as $pretail){
                        $pretail->delete();
                    }
                $premix->delete();
                }
            $fortail->delete();
            }
        $formula->delete();
        }
        $workbook->delete();

        return Redirect::back()->with('error', 'Workbook '.$n.' Telah Dihapus!');
    }

}