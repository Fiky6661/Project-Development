<?php

namespace App\Http\Controllers\devwb;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\dev\Formula;
use App\dev\Fortail;
use App\dev\Premix;
use App\dev\Pretail;
use Auth;
use Redirect;

class FormulaController extends Controller
{
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:development');
    }

    public function new(Request $request)
    {
        
        $formulas = new Formula;
        $formulas->workbook_id = $request->workbook_id;
        $formulas->revisi = $request->revisi;
        $formulas->jenis = $request->jenis;
        $formulas->versi = 1;
        $formulas->kode_formula = $request->kode_formula;
        $formulas->nama_produk = $request->nama_produk;
        $formulas->jenis = 'baru';
        $formulas->save();
        
        return Redirect::back()->with('status', 'Formula '.$formulas->nama_produk.' Telah Ditambahkan!');
    }

    public function detail($id){

        $formula = Formula::where('id',$id)->first();
        $fortail = Fortail::where('formula_id',$formula->id);

        return view('devwb/detailformula')->with([
            'formula' => $formula,
            'fortail' => $fortail
        ]);
    }
 
}
