<?php

namespace App\Http\Controllers\devwb;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\dev\Formula;
use App\Modelfn\finance;
use Redirect;

class PengajuanFormulaController extends Controller
{
    public function vp($id){

        $formula = Formula::find($id);
        
        $formulas = Formula::where('workbook_id',$formula->workbook_id)->get();
        foreach($formulas as $f){
            if($f->status != 'selesai'){
                $f->status = 'draft';
                $f->save();
            }
        }

        $formula = Formula::find($id);
        $formula->vv = 'proses';
        $formula->status = 'proses';
        $formula->save();
        
        return Redirect::back()->with('status', 'Formula '.$formula->nama_produk.' Telah Di Ajukan VP');
    }

    public function fs($id){
        $formulas = Formula::where('workbook_id',$formula->workbook_id)->get();
        foreach($formulas as $f){
            if($f->status != 'selesai'){
                $f->status = 'draft';
                $f->save();
            }
        }

        $formula = Formula::find($id);
        $formula->status_fisibility = 'proses';
        $formula->status = 'proses';
        $formula->save();

        $finance = new Finance;
        $finance->id_formula = $id;
        $finance->messange = 'Pengajuan Feasibility Baru';
        $finance->save();
        
        return Redirect::back()->with('status', 'Formula '.$formula->nama_produk.' Telah Di Ajukan Feasibility');
    }

    public function nf($id){

        $formulas = Formula::where('workbook_id',$formula->workbook_id)->get();
        foreach($formulas as $f){
            if($f->status != 'selesai'){
                $f->status = 'draft';
                $f->save();
            }
        }

        $formula = Formula::find($id);
        $formula->status_nutfact = 'proses';
        $formula->status = 'proses';
        $formula->save();
        
        return Redirect::back()->with('status', 'Formula '.$formula->nama_produk.' Telah Di Ajukan Nutfact');
    }
}
