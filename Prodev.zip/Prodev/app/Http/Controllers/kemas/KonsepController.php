<?php

namespace App\Http\Controllers\kemas;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Modelfn\finance;
use App\Modelkemas\konsep;
use Redirect;

class KonsepController extends Controller
{
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:kemas');
    }

    public function index($id){
        $fe=finance::find($id);
        $dataF = finance::where('id_formula',$id)->first();
        $count_konsep = konsep::where('id_feasibility',$id)->count();
        if($count_konsep == 1){
            return redirect()->route('uploadkemas',$id);
        }
        return view('kemas/konsep',['fe'=>$fe])->with([
            'dataF' => $dataF
        ]); 
    }

    public function insert(Request $request){
        $kemass= new konsep;
        $kemass->konsep=$request->get('konsepkemas');
        $kemass->id_feasibility=$request->finance;
        $kemass->s_primer='D';
        $kemass->primer=$request->d;
        $kemass->s_sekunder='S';
        $kemass->sekunder=$request->s;
        $kemass->s_tersier='G';
        $kemass->tersier=$request->g;
        $kemass->save();

        return redirect()->route('uploadkemas');
    }
}
