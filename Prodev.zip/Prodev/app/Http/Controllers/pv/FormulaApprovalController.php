<?php

namespace App\Http\Controllers\pv;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\dev\Formula;
use Redirect;

class FormulaApprovalController extends Controller
{
    public function __construct(){

        $this->middleware('auth');
        $this->middleware('rule:pv');
    }

    public function listapproval()
    {
        $formulas = Formula::where('vv', '=','proses')->get();

        return view('pv.approval')->with([
            'formulas' => $formulas
            ]);
    }

    public function approve($id){
        $formulas = Formula::find($id)->update(['vv' => 'ok']);
        return Redirect::back();
    }

    public function reject($id){
        $formulas = Formula::find($id)->update(['vv' => 'tidak']);
        return Redirect::back();
    }

    public function listapproved()
    {
        $formulas = Formula::where('vv','!=','proses')->get();

        return view('pv.approved')->with([
            'formulas' => $formulas
            ]);
    }
}
