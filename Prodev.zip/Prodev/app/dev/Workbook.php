<?php

namespace App\dev;

use Illuminate\Database\Eloquent\Model;

class Workbook extends Model
{
    protected $table = 'workbooks';
    
    protected $fillable = [
        'nama_project',
        'mnrq',
        'tarkon_id',
        'keterangan',
    ];

    public function User(){
        return $this->belongsTo('App\User');
    }

    public function Tarkon(){
        return $this->belongsTo('App\master\Tarkon');
    }

    public function Formula(){
        return $this->hasMany('App\dev\Formula');
    }

    
}
