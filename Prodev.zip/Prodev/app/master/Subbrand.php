<?php

namespace App\master;

use Illuminate\Database\Eloquent\Model;

class Subbrand extends Model
{
    protected $table = 'subbrands';

    public function Formula(){
        return $this->hasMany('App\dev\Formula');
    }

    public function Brand(){
        return $this->belongsTo('App\master\Brand');    }

    public function User(){
        return $this->belongsTo('App\User');
    }

    protected $fillabble = [
        'subbrand',
        'brand',
        'user_id',
    ];

}
