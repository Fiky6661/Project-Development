<?php

namespace App\master;

use Illuminate\Database\Eloquent\Model;

class Kategori extends Model
{
    protected $table = 'kategoris';

    public function Subkategori(){
        return $this->hasMany('App\master\Subkategori');
    }

    public function kategori()
    {
    	return 	$this->hasMany('App\devnf\tb_parameter','kategori','id_kategori');
    }

    protected $fillable = [
        'kategori',
    ];
}