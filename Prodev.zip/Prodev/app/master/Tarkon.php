<?php

namespace App\master;

use Illuminate\Database\Eloquent\Model;

class Tarkon extends Model
{
    protected $table = 'tarkons';

    public function Workbook(){
        return $this->hasMany('App\dev\Workbook');
    }

    public function tarkon()
    {
    	return $this->hasMany('App\devnf\tb_akg','tarkon','id');
    }

    protected $fillable = [
        'tarkon',
        'dari',
        'sampai',
    ];
}   