<?php

namespace App\Modelkemas;

use Illuminate\Database\Eloquent\Model;

class konsep extends Model
{
    protected $table ='fs_konsep_kemas';
    protected $primaryKey ='id_konsepkemas';
    protected $fillable =['id_feasibility','konsep','primer','s_primer','sekunder','s_sekunder','tersier','s_tersier'];
    
    public function konsep()
    {
        return $this->hasOne('App\Modelfn\finance','id_fk','id_konsepkemas');
    }
}
