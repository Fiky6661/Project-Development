<?php

namespace App\devnf;

use Illuminate\Database\Eloquent\Model;

class tb_hitung_hak extends Model
{
    //
}
