<?php

namespace App\devnf;

use Illuminate\Database\Eloquent\Model;

class tb_hitung_btp extends Model
{
    //
}
