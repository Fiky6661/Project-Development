<?php

namespace App\devnf;

use Illuminate\Database\Eloquent\Model;

class tb_parameter_cemaran_wb extends Model
{
    //
}
