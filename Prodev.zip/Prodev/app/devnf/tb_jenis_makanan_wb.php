<?php

namespace App\devnf;

use Illuminate\Database\Eloquent\Model;

class tb_jenis_makanan_wb extends Model
{
    //
}
