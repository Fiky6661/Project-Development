<?php

namespace App\Modelmesin;

use Illuminate\Database\Eloquent\Model;

class kategori extends Model
{
    protected $table='fs_kategori';
    protected $fillable =['kategori'];
}
