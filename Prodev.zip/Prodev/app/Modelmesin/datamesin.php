<?php

namespace App\Modelmesin;

use Illuminate\Database\Eloquent\Model;

class datamesin extends Model
{
    protected $table ='fs_datamesin';

    protected $fillable =[
        'workcenter','gedung','kategori','Direct_Activity','nama_kategori','rate_mesin','defaultSDM','harga_sdm'
    ];

    public function datamesin()
    {
        return $this->hasMany('App\Modelmesin\Dmesin','id_data_mesin','id_data_mesin');
    }
}
