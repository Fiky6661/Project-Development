<?php $__env->startSection('title', 'Data BahanBaku'); ?>

<?php $__env->startSection('judulnya','Data BahanBaku'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">


            <?php if(session('status')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('status')); ?>

            </div>
            </div>
            <?php elseif(session('error')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('error')); ?>

            </div>
            </div>
            <?php endif; ?>



    <div class="col-md-12">
        <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Bahan Baku</a>

<table class="table table-striped table-advance table-hover" id="Table">
<thead>
<tr>

    <th>ID</th>
    <th>Nama_Sederhana</th>
    <th>Nama_Bahan </th>
    <th>Kode_Oracle</th>
    <th>Kode_Komputer</th>
    <th>Supplier</th>
    <th>Principle</th>
    <th>no_HEIPBR</th>
    <th>PIC</th>
    <th>Cek Halal</th>
    <th>Berat</th>
    <th>Satuan</th>
    <th>Kategori</th>
    <th>Harga Satuan</th>
    <th>Currency</th>
    <th>User</th>
    <th>Kelompok</th>
    <th>Status</th>
    <th>Created</th>
    <th>Updated</th>
    <th>_____Action_____</th>
        

</tr>
</thead>

<tbody>
<?php $__currentLoopData = $bahans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>

<td><?php echo e($bahan->id); ?></td>
<td><?php echo e($bahan->nama_sederhana); ?></td>
<td><?php echo e($bahan->nama_bahan); ?></td>
<td><?php echo e($bahan->kode_oracle); ?></td>
<td><?php echo e($bahan->kode_komputer); ?></td>
<td><?php echo e($bahan->supplier); ?></td>
<td><?php echo e($bahan->principle); ?></td>
<td><?php echo e($bahan->no_HEIPBR); ?></td>
<td><?php echo e($bahan->PIC); ?></td>
<td><?php echo e($bahan->cek_halal); ?></td>
<td><?php echo e($bahan->berat); ?></td>
<td><?php echo e($bahan->satuan->satuan); ?></td>
<td><?php echo e($bahan->subkategori->subkategori); ?></td>
<td><?php echo e($bahan->harga_satuan); ?></td>
<td><?php echo e($bahan->curren->currency); ?></td>
<td><?php echo e($bahan->user->name); ?></td>
<td><?php echo e($bahan->kelompok->nama); ?></td>
<td><?php echo e($bahan->status); ?></td>
<td><?php echo e($bahan->created_at); ?></td>
<td><?php echo e($bahan->updated_at); ?></td>
<td>
    <a class="btn btn-primary" href="<?php echo e(route('updatebahan',$bahan->id)); ?>" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
    <a class="btn btn-danger" onclick="return confirm('Hapus Bahan Baku ?')" href="<?php echo e(route('delbahan',$bahan->id)); ?>"><i class="fa fa-trash-o"></i></a>
    <?php if($bahan->status == 'active'): ?>
    <a class="btn btn-warning" onclick="return confirm('NonAktif BahanBaku ?')" href="<?php echo e(route('nonactivebahan',$bahan->id)); ?>" data-toggle="tooltip" data-placement="top" title="NonActive"><i class="fa fa-minus"></i></a>
    <?php elseif($bahan->status == 'nonactive'): ?>
    <a class="btn btn-info" onclick="return confirm('Aktifkan BahanBaku ?')" href="<?php echo e(route('activebahan',$bahan->id)); ?>" data-toggle="tooltip" data-placement="top" title="Aktifkan"><i class="fa fa-check"></i></a>
    <?php endif; ?>
</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
    
    
    </div>



<div class="col-md-12" id="add" style="background-color:#2f323a;display:none">
        <div class="form-panel" >
        <form method="POST" action="<?php echo e(route('addbahan')); ?>">
        <h4><i class="fa fa-plus"></i> Tambah Bahan Baku</h4>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                    <label for="nama_sederhana" class="control-label">Nama Sederhana</label>
                    <input class="form-control" id="nama_sederhana" name="nama_sederhana"  type="text" value="<?php echo e(old('nama_sederhana')); ?>" required />
                    <label for="nama_bahan" class="control-label">Nama Bahan</label>
                    <input class="form-control" id="nama_bahan" name="nama_bahan"  type="text" value="<?php echo e(old('nama_bahan')); ?>" required />
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <label for="kode_oracle" class="control-label">Kode_Oracle</label>
                                <input class="form-control" id="kode_oracle" name="kode_oracle"  type="text" value="<?php echo e(old('kode_oracle')); ?>" required />
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <label for="kode_komputer" class="control-label">Kode_Komputer</label>
                                <input class="form-control" id="kode_komputer" name="kode_komputer"  type="text" value="<?php echo e(old('kode_komputer')); ?>" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <label for="supplier" class="control-label">Supplier</label>
                                <input class="form-control" id="supplier" name="supplier"  type="text" value="<?php echo e(old('supplier')); ?>" required />
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <label for="principle" class="control-label">Principle</label>
                                <input class="form-control" id="principle" name="principle"  type="text" value="<?php echo e(old('principle')); ?>" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <label for="no_HEIPBR" class="control-label">No HEIPBR</label>
                                <input class="form-control" id="no_HEIPBR" name="no_HEIPBR"  type="text" value="<?php echo e(old('no_HEIPBR')); ?>" required />
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <label for="PIC" class="control-label">PIC</label>
                                <input class="form-control" id="PIC" name="PIC"  type="text" value="<?php echo e(old('PIC')); ?>" required />
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <label for="cek_halal" class="control-label">Cek Halal</label>
                                <input class="form-control" id="cek_halal" name="cek_halal"  type="text" value="<?php echo e(old('cek_halal')); ?>" required />
                            </div>
                        </div>
                    
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                            <label for="" class="control-label">Kategori</label>
                            <br>
                            <select id="subkategori" name="subkategori" class="form-control" style="width:250px;">
                            <?php $__currentLoopData = $subkategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subkategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($subkategori->id); ?>" <?php echo e(old('subkategori') == $subkategori->id ? 'selected' : ''); ?>><?php echo e($subkategori->subkategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                            <label for="" class="control-label">kelompok</label>
                            <br>
                            <select id="kelompok" name="kelompok" class="form-control" style="width:250px;">
                            <?php $__currentLoopData = $kelompoks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelompok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($kelompok->id); ?>" <?php echo e(old('kelompok') == $kelompok->id ? 'selected' : ''); ?>><?php echo e($kelompok->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                            <label for="berat" class="control-label">Berat</label>
                            <input type="number" step="any" class="form-control" id="berat" name="berat" value="<?php echo e(old('berat')); ?>" required />
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                            <label for="" class="control-label">Satuan</label>
                            <br>
                            <select id="satuan" name="satuan" class="form-control" style="width:250px;">
                            <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($satuan->id); ?>" <?php echo e(old('satuan') == $satuan->id ? 'selected' : ''); ?> ><?php echo e($satuan->satuan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                            <label for="harga_satuan" class="control-label">Harga Satuan</label>
                            <input type="number" step="any" class="form-control" id="harga_satuan" name="harga_satuan" value="<?php echo e(old('harga_satuan')); ?>" required />
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                            <label for="" class="control-label">Currency</label>
                            <br>
                            <select id="curren" name="curren" class="form-control" style="width:250px;">
                            <?php $__currentLoopData = $currens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($curren->id); ?>" <?php echo e(old('curren') == $curren->id ? 'selected' : ''); ?>><?php echo e($curren->currency); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>
                        <br>
                        <br>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user" value="<?php echo e(Auth::id()); ?>">
                        <input type="submit" class="btn btn-primary" value="+ Submit">
                        <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
                        </form>
            </div>
        </div>
        </div>
</div>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
$('#subkategori').select2();
$('#kelompok').select2();
$('#satuan').select2();
$('#curren').select2();

$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 1000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });
});

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>