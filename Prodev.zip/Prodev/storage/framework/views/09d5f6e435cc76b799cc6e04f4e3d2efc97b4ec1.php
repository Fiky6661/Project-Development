<?php $__env->startSection('content'); ?>
    <div class="col-md-18">
      <div class="showback">
        <div class="row">
          <div class="col-md-6"><h4><i class="fa fa-book"></i> Hasil Analisa</h4> </div>
          <div class="col-md-6 text-right"><h5><i class="fa fa-home"></i> / <a href="<?php echo e(url('/hasilanalisa')); ?>">Hasil Analisa</a></h5></div>
        </div>
      </div>
    </div>
<div class="row">		
	<div class="col-md-16">
		<div class="showback" style="box-shadow: 4px 4px 4px #d4d7db; border-radius:3px;">
				<div class="col-md-12"> 
					<!-- <a href="<?php echo e(url('/datapn')); ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin ?')" style="margin-left: 1%;"><i class="fa fa-arrow-left"></i> Kembali</a> -->
					<div class="btn-group" style="margin-left: 10%;">
						<a href="<?php echo e(url('datanutri')); ?>" class="btn btn-info">List Ingredient</a>
						<a href="<?php echo e(url('hasilanalisa')); ?>" class="btn btn-info active">Hasil Analisa</a>
						<a href="<?php echo e(url('hitungHAK')); ?>" class="btn btn-info">Perhitungan HAK</a>
						<a href="<?php echo e(url('hitungAKG')); ?>" class="btn btn-info">Perhitungan AKG</a>
						<a href="<?php echo e(url('hitungBTP')); ?>" class="btn btn-info">Perhitungan BTP Carry Over</a>
						<a href="<?php echo e(url('CompareNutfact')); ?>" class="btn btn-info">Nutrition Fact</a>
					</div>
					<hr style="border-color: #d4d7db;">
					<div class="col-md-6 col-md-offset-3">		
		        		<h3 align="center">
		        			<p><b></b></p><br>
		        		</h3>
					</div>
				</div>
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<div class="col-md-5">
							<label class="col-md-12 control-label pull-right" style="margin-top: 5px;">Serving Size&nbsp:</label>
						</div>
                        <div class="col-md-3">
                            <input type="text" class="form-control pull-left" id="ss" value="15" readonly />
                        </div>
                        <div class="col-md-1 pull-left" style="margin-top: 5px;">gram</div>
                    </div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
                        <label class="col-md-6 control-label" style="margin-top: 5px;">Serving Size (liquid) :</label>
                        <div class="col-md-3">
                            <input type="text" class="form-control" readonly id="ssl" />
                        </div>
                        <div class="col-md-1" style="margin-top: 5px;">ml</div>
                    </div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
                        <label class="col-md-4 control-label" style="margin-top: 5px;">Berat Jenis :</label>
                        <div class="col-md-3">
                            <input type="text" class="form-control" readonly id="bj" value="3" />
                        </div>
                        <div class="col-md-1" style="margin-top: 5px;">gr/ml</div>
                    </div>
				</div>
			</div>
			<br>
			<table class="table table-hover">
				<thead>
					<tr>
						<th class="text-center">Check</th>
						<th class="text-center">No</th>
						<th class="text-center">Parameter</th>
						<th class="text-center">Per Serving</th>
						<th class="text-center">Hasil Analisa</th>
						<th class="text-center">Unit</th>
						<th class="text-center">AKG</th>
						<th class="text-center">%AKG/100g</th>
					</tr>
				</thead>
				<form action="<?php echo e(url('hasilanalisa')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

				<tbody>
					<!-- <tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">1</td>
						<td class="text-center" colspan="6">Proksimat</td>
					</tr> -->
					<?php $__currentLoopData = $tampilkan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"><?php echo e($data->parameter); ?></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="rows[0]per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" pattern="[0-9.]+" name="rows[0]hasil_analisa" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value="<?php echo e($data->hasil_analisa); ?>" required></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg">325<?php echo e($data->id_akg); ?></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="rows[0]%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- <tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">2</td>
						<td class="text-center" colspan="6">Lemak</td>
					</tr>
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value=""></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg"></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr>
					<tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">3</td>
						<td class="text-center" colspan="6">Karbohidrat Lain</td>
					</tr>
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value=""></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg"></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr>
					<tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">4</td>
						<td class="text-center" colspan="6">Mineral</td>
					</tr>
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value=""></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg"></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr>
					<tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">5</td>
						<td class="text-center" colspan="6">Vitamin</td>
					</tr>
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value=""></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg"></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr>
					<tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">6</td>
						<td class="text-center" colspan="6">Zat Gizi non AKG</td>
					</tr>	
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value=""></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg"></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr>
					<tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">7</td>
						<td class="text-center" colspan="6">Asam Amino</td>
					</tr>
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value=""></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg"></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr>
					<tr style="background-color: #20c997;color: white;">
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center" style="width: 8%;">8</td>
						<td class="text-center" colspan="6">(Sesuai kategori produk)</td>
					</tr>
					<tr>
						<td class="text-center" style="width: 5%;">
							<i class="fa fa-check"></i>
						</td>
						<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
						<td class="text-center"></td>
						<td class="text-center" style="width: 17%;">
							<input type="number" name="per_serving" class="form-control" id="ps" readonly >
						</td>
						<td class="text-center" style="width: 15%;">
							<div class="form-group"><input type="text" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value=""></div>
						</td>
						<td class="text-center">%</td>
						<td  class="text-center">
							<span id="akg"></span>
						</td>
						<td  class="text-center" style="width: 17%;">
							<input type="number" name="%akg/100g" class="form-control" id="akgg" readonly>
						</td>
					</tr> -->
				</tbody>
			</table>
			<hr style="border-color: #d4d7db;">
			<button type="submit" class="btn btn-block btn-lg btn-success" name="simpan">Simpan</button>
		</form>
		</div>
	</div>
</div>
<script type="text/javascript">
// function addOctDate() {
//         var cls = document.getElementsByClassName("oct_days"); 
//         for (n=0, length = cls.length; n < length; n++) {
//             cls[n].id= "oct_" + (n + 1); 
//         }
//     }; 

// 	addOctDate()
function mulaiHitung(){
	otomatis = setInterval("hitung()",1);
}

function hitung(){
	var ss   = document.getElementById('ss').value;
	var ssl  = document.getElementById('ssl').value;
	var bj   = document.getElementById('bj').value;
	var ha   = document.getElementById('ha').value;
	var ps   = document.getElementById('ps').value;
	var akg  = document.getElementById('akg').innerHTML;

	var hitung  =(ss/bj);
	var hitung1 = (ss * 1) / 100;
	var hitung2 = (hitung1 * ha);
	var hitung3 = (ha / akg * 100);
	hitung2     = hitung2.toFixed(2);
	hitung3		= hitung3.toFixed(1);
	document.getElementById('ssl').value = hitung;
	document.getElementById('ps').value = hitung2;
	document.getElementById('akgg').value = hitung3;
}

function stopHitung(){
	clearInterval(otomatis);
}



// $(document).ready(function(){      
//       var postURL = "<?php echo url('addmore'); ?>";
//       var i=1;  

//       $('#add').click(function(){  
//            i++;  
//            $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="text" name="name[]" placeholder="Kategori" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
//       });  

//       $(document).on('click', '.btn_remove', function(){  
//            var button_id = $(this).attr("id");   
//            $('#row'+button_id+'').remove();  
//       });  

//       $.ajaxSetup({
//           headers: {
//             'X-CSRF-TOKEN': $('meta[keterangan="csrf-token"]').attr('content')
//           }
//       });

//       $('#submit').click(function(){            
//            $.ajax({  
//                 url:postURL,  
//                 method:"POST",  
//                 data:$('#add_name').serialize(),
//                 type:'json',
//                 success:function(data)  
//                 {
//                     if(data.error){
//                         printErrorMsg(data.error);
//                     }else{
//                         i=1;
//                         $('.dynamic-added').remove();
//                         $('#add_name')[0].reset();
//                         $(".print-success-msg").find("ul").html('');
//                         $(".print-success-msg").css('display','block');
//                         $(".print-error-msg").css('display','none');
//                         $(".print-success-msg").find("ul").append('<li>Record Inserted Successfully.</li>');
//                     }
//                 }  
//            });  
//       });  

//       function printErrorMsg (msg) {
//          $(".print-error-msg").find("ul").html('');
//          $(".print-error-msg").css('display','block');
//          $(".print-success-msg").css('display','none');
//          $.each( msg, function( key, value ) {
//             $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
//          });
//       }
//     });  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>