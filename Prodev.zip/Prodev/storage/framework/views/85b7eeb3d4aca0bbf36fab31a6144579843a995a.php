<?php $__env->startSection('title', 'Formula'); ?>

<?php $__env->startSection('judulnya', 'FORMULA LIST'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('status')); ?>

        </div>
</div>
<?php endif; ?>
<div class="col-lg-6 col-md-6 col-sm-6">
            <div class="showback">
        <h4>INFORMASI WORKBOOK</h4>
        <br>
        <table class="table table-hover">
                <tbody>
                  <tr>
                    <td>NAMA WORKBOOK</td>
                    <td><?php echo e($workbooks->nama_project); ?></td>
                  </tr>
                  <tr>
                    <td>MANDATORY REQUIREMENT</td>
                    <td><?php echo e($workbooks->mnrq); ?></td>
                  </tr>
                  <tr>
                    <td>TARGET KONSUMEN</td>
                    <td><?php echo e($workbooks->tarkon->tarkon); ?></td>
                  </tr>
                  <tr>
                    <td>TOTAL VERSI FORMULA</td>
                    <td><?php echo e($cf); ?></td>
                  </tr>
                </tbody>
              </table>
    
        </div>
        </div>

        

        <div class="col-lg-6 col-md-6 col-sm-6">
            <div class="showback">
        <button type="button" class="btn btn-primary" disable>STATUS WORKBOOK : <?php echo e($workbooks->status); ?><?php echo e(($workbooks->status == null) ? ' --------- ' : ''); ?></button>
        <h4>ACTION</h4>
        <button class="btn btn-theme03" data-toggle="modal" data-target="#editwb"><i class="fa fa-edit"></i> Edit Workbooks</button>
        <?php if($cf == 0): ?>
        <button class="btn btn-info" data-toggle="modal" data-target="#FB"><i class="fa fa-plus"></i>Formula Baru</button>
        <?php elseif($cf>0): ?>
        <a class="btn btn-info" onclick="return confirm('Naik Versi Formula ?')" href="<?php echo e(route('upversion',['cf'=>$cf,'id'=>$workbooks->id])); ?>"><i class="fa fa-plus"></i> Naik Versi</a>
        <?php endif; ?>

        <?php if($cs<0): ?>
        <a class="btn btn-warning" href="<?php echo e(route('workbook.selesai',$workbooks->id)); ?>" onclick="return confirm('Selesaikan Project ?')"><i class="fa fa-check"></i> SELESAI</a>
        <?php endif; ?>

        <?php if(@cp>0): ?>
        <a class="btn btn-danger"><i class="fa fa-times"></i> BATAL</a>
        <?php endif; ?>
        <button class="btn btn-theme04" id="show" onclick="show()" ><i class="fa fa-user"></i> Alihkan Workbooks</button>
        </div>


        <div class="showback" id="divalih" style="visibility:hidden; background-color:#797979">
        <div class="row">

        <div class="col-lg-8 col-md-8 col-sm-8">
        <form method="POST" action="<?php echo e(route('alihkan',$workbooks->id)); ?>">
        <label for="" style="color:white" class="control-label">Pilih Penerima Project</label>
        <br>
        <select class="cari form-control" style="width:400px;" id="user" name="user">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <?php echo e(method_field('PATCH')); ?>

        
        </div>

        <div class="col-lg-4 col-md-4 col-sm-4">
        <br>
        <button type="submit" onclick="return confirm('Alihkan Workbook ?')" class="btn btn-theme03"><i class="fa fa-send"></i> Alihkan</button>
        </form>
        <button class="btn btn-danger" id="hide" onclick="hide()"><i class="fa fa-times"></i> Batal</button>
        </div>

        </div>
        </div>
        </div>


<!-- FORMULA PROSES -->
<?php if($cp>0): ?>
<div class="row mt">
          <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="showback">
                <h4>FORMULA YANG SEDANG DIPROSES</h4>
                <table class="table table-striped table-advance table-hover">
                <thead>
                <tr>

                <th>ID</th>
                <th>Kode Forpros</th>
                <th>Nama Produk</th>
                <th>Revisi</th>
                <th>Versi</th>
                <th>PV</th>
                <th>Feasibility</th>
                <th>Nutfact</th>
                <th>Status</th>
                <th>Action</th>
                <th>Pengajuan</th>

                </tr>
                </thead>

                <tbody>
              <tr>
              <td><?php echo e($Forpros->id); ?></td>
              <td><?php echo e($Forpros->kode_formula); ?></td>
              <td><?php echo e($Forpros->nama_produk); ?></td>
              <td><?php echo e($Forpros->revisi); ?></td>
              <td><?php echo e($Forpros->versi); ?></td>
              <td><?php echo e($Forpros->vv); ?></td>
              <td><?php echo e($Forpros->status_fisibility); ?></td>
              <td><?php echo e($Forpros->status_nutfact); ?></td>
              <td><?php echo e($Forpros->status); ?></td>
              <td>
              <?php echo e(csrf_field()); ?>

              <a class="btn btn-info" href="<?php echo e(route('formula.detail',$Forpros->id)); ?>">Show</a>
              <?php if($Forpros->status!='proses'): ?>
              <a class="btn btn-warning" href="<?php echo e(route('step1',$Forpros->id)); ?>">Edit</a>
              <?php endif; ?>
              </td>
              <td>
          <?php if($workbooks->status!='proses'): ?>
            <?php if($Forpros->status!='proses'): ?>
              <?php if(empty($Forpros->vv)): ?>
                <a class="btn btn-info" href="<?php echo e(route('ajukanvp',$Forpros->id)); ?>">PV</a>
              <?php endif; ?>
                <?php if($Forpros->vv=='ok'): ?>
                  <?php if(empty($Forpros->status_fisibility)): ?>
                  <a class="btn btn-info" href="<?php echo e(route('ajukanfs',$Forpros->id)); ?>">Feasibility</a>
                  <?php endif; ?>
                  <?php if(empty($Forpros->status_nutfact)): ?>
                  <a class="btn btn-primary" href="<?php echo e(route('ajukannf',$Forpros->id)); ?>">Nutfact</a>
                  <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
          <?php endif; ?>
              </td>
              </tr>
              </tbody>
                </table>
              </div>
              <a class="btn btn-primary btn-lg btn-block" id="tfl" href="#Table"><i class="fa fa-bars"></i> List Formula</a>     
          </div>
</div>
<?php endif; ?>
        
        
        <div class="row mt" id="FL">
          <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="showback">
                <h4>FORMULA LIST</h4>
                <table class="table table-striped table-advance table-hover" id="Table">
                <thead>
                <tr>

                <th>ID</th>
                <th>Kode Formula</th>
                <th>Nama Produk</th>
                <th>Revisi</th>
                <th>Versi</th>
                <th>PV</th>
                <th>Feasibility</th>
                <th>Nutfact</th>
                <th>Status</th>
                <th>Action</th>
                <th>Pengajuan</th>

                </tr>
                </thead>

                <tbody>

              <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>

              <td><?php echo e($formula->id); ?></td>
              <td><?php echo e($formula->kode_formula); ?></td>
              <td><?php echo e($formula->nama_produk); ?></td>
              <td><?php echo e($formula->revisi); ?></td>
              <td><?php echo e($formula->versi); ?></td>
              <td><?php echo e($formula->vv); ?></td>
              <td><?php echo e($formula->status_fisibility); ?></td>
              <td><?php echo e($formula->status_nutfact); ?></td>
              <td><?php echo e($formula->status); ?></td>

              <td>
              <?php echo e(csrf_field()); ?>

              <a class="btn btn-info" href="<?php echo e(route('formula.detail',$formula->id)); ?>">Show</a>
              <?php if($formula->status!='proses'): ?>
              <a class="btn btn-warning" href="<?php echo e(route('step1',$formula->id)); ?>">Edit</a>
              <?php endif; ?>
              </td>

              <td>
          <?php if($workbooks->status!='proses'): ?>
            <?php if($formula->status!='proses'): ?>
              <?php if(empty($formula->vv)): ?>
                <a class="btn btn-info" href="<?php echo e(route('ajukanvp',$formula->id)); ?>">PV</a>
              <?php endif; ?>
                <?php if($formula->vv=='ok'): ?>
                  <?php if(empty($formula->status_fisibility)): ?>
                  <a class="btn btn-info" href="<?php echo e(route('ajukanfs',$formula->id)); ?>">Feasibility</a>
                  <?php endif; ?>
                  <?php if(empty($formula->status_nutfact)): ?>
                  <a class="btn btn-primary" href="<?php echo e(route('ajukannf',$formula->id)); ?>">Nutfact</a>
                  <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
          <?php endif; ?>
              </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
                
                </table>

              </div>

              

          </div>
</div>
</div>



<!-- Formula Baru -->
<div class="modal fade" id="FB" tabindex="-1" role="dialog" aria-labelledby="hm" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="hm">Formula Baru</h4>
                    </div>
                    <div class="modal-body">
                    <form class="cmxform form-horizontal style-form" method="POST" action="<?php echo e(route('addformula')); ?>">
                        
                        <input class="form-control " id="workbook_id" name="workbook_id" type="hidden" value="<?php echo e($workbooks->id); ?>"/>   
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Nama Produk</label>
                            <div class="col-lg-8">
                            <input class="form-control " id="nama_produk" name="nama_produk" type="text" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Jenis Formula</label>
                            <div class="col-lg-8">
                                <select class="form-control" id="jenis" name="jenis">
                                <option value="baru">Baru</option>
                                <option value="revisi">Revisi</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Revisi</label>
                            <div class="col-lg-8">
                            <input class="form-control " id="revisi" name="revisi" type="text" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Kode Formula</label>
                            <div class="col-lg-8">
                            <input class="form-control " id="kode_formula" name="kode_formula" type="text" required/>
                            </div>
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                      <button type="submit" class="btn btn-primary"><i class="fa fa-plus-plus"></i> Add</button>
                        </div>
                        </form>
                  </div>
                </div>
              </div>

<!-- Edit Workbook -->
<div class="modal fade" id="editwb" tabindex="-1" role="dialog" aria-labelledby="EWBModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="EWBModalLabel">Edit Workbook</h4>
                    </div>
                    <div class="modal-body">
                    <form class="cmxform form-horizontal style-form" id="new" method="POST" action="<?php echo e(route('updateworkbooks',$workbooks->id)); ?>">
                        
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Nama Project</label>
                            <div class="col-lg-8">
                            <input class="form-control" id="nama" name="nama" type="text" value="<?php echo e($workbooks->nama_project); ?>" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Mandatory Requirement</label>
                            <div class="col-lg-8">
                            <input class="form-control" id="mnrq" name="mnrq" type="text" value="<?php echo e($workbooks->mnrq); ?>" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Target Konsumen</label>
                            <div class="col-lg-8">
                            <select class="form-control" id="tarkon" name="tarkon">
                            <?php $__currentLoopData = $tarkons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarkon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tarkon->id); ?>"<?php echo e(( $tarkon->id == $workbooks->tarkon_id ) ? ' selected' : ''); ?> ><?php echo e($tarkon->tarkon); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo e(method_field('PATCH')); ?>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                      <button type="submit" class="btn btn-primary"><i class="fa fa-edit"></i> Simpan Perubahan</button>
                        </div>
                        </form>
                  </div>
                </div>
              </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
  $('.cari').select2({
        placeholder: 'Pilih Penerima...'
      });

  function show() {
    document.getElementById("divalih").style.visibility = "visible";
  }
  function hide() {
    document.getElementById("divalih").style.visibility = "hidden";
  }

$(document).ready(function(){  
    $("#tfl").click(function(e) {
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 1000);
    });
});
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('devwb.tempwb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>