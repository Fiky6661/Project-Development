<?php $__env->startSection('title', 'detailuser'); ?>


<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('status')); ?>

        </div>
</div>
<?php endif; ?>
<div class="row content-panel">
      <!-- /panel-heading -->
      <div class="panel-body">
        <div class="tab-content">
          <div id="overview" class="tab-pane active">
            <div class="row">
              <div class="col-md-5 profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                  <h3><?php echo e($users->name); ?></h3>
                  <p>Last update : <?php echo e($users->updated_at); ?></p>
                    <div class="profile-pic">
                      <p><img src="<?php echo e(asset('img/proo.png')); ?>" class="img-circle"></p>
                      <p><button class="btn btn-theme"><i class="fa fa-check"></i><?php echo e($users->status); ?></button></p>
                    </div>
                </div>
                <div class="right-divider hidden-sm hidden-xs">
                  <h4><?php echo e($users->email); ?></h4>
                  <p>E-mail</p>
                  <h4><?php echo e($users->username); ?></h4>
                  <p>Username</p>
                  <h4><?php echo e($users->departement->dept); ?></h4>
                  <p>Departement</p>
                  <h4><?php echo e($users->role->namaRule); ?></h4>
                  <p>Level</p>
                </div>
              </div>
              <!-- /col-md-4 -->
              <div class="col-md-7 centered">
                <div class="row">
                  <div class="col-lg-8 col-lg-offset-2 detailed">
                    <h4 class="mb">Edit User Profile</h4>
                      <div class="form">
                        <form class="cmxform form-horizontal style-form" method="POST" action="<?php echo e(route('userupdate',$users->id)); ?>">
                          <br>
                          <input class="form-control" id="name" name="name" placeholder="nama" value="<?php echo e($users->name); ?>" type="text" minlength="2" autofocus required/>
                          <br>
                          <input class="form-control" id="username" name="username" placeholder="username" value="<?php echo e($users->username); ?>" type="text" minlength="6" maxlength="12" required/>
                          <br>
                          <input class="form-control" id="email" name="email" placeholder="E-mail" value="<?php echo e($users->email); ?>" type="email" required/>
                          <br>
                          <select id="departement" name="departement" class="form-control" >
                          <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($dept->id); ?>"<?php echo e(( $dept->id == $users->departement_id ) ? ' selected' : ''); ?> ><?php echo e($dept->dept); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <br>
                          <select class="form-control" id="role" name="role">
                          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($role->id); ?>"<?php echo e(( $role->id == $users->role_id ) ? ' selected' : ''); ?>><?php echo e($role->namaRule); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <br>
                          <button class="btn btn-theme btn-block" type="submit"><i class="fa fa-edit"></i> Simpan Perubahan</button>
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo $__env->make('formerrors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </form>
                      </div>   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>