<?php $__env->startSection('title','PRODEV | FEASIBILITY'); ?>

<?php $__env->startSection('content'); ?>

<div class="row" >
  <div class="col-md-14">
    <div class="showback">
      <div class="row">
        <div class="col-md-10"><h4><i class="fa fa-book"></i> Data Pengajuan Feasibility</h4> </div>
        <div class="col-md-2"><h4><i class="fa fa-user"></i> <?php echo e(Auth::user()->role->namaRule); ?></h4> </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12"> 
    <div class="showback" style="border-radius:3px;">
      <table class="table table-hover table-bordered table table-striped">
        <thead>
          
          <tr>
            <th rowspan="2" class="text-center">No</th>
            <th rowspan="2" class="text-center">Formula</th>
            <th rowspan="2" class="text-center">Tanggal Masuk</th>
            <th colspan="5" class="text-center">Progress</th>
            <th rowspan="2" class="text-center">Aksi</th>
          </tr>
          <tr>
            <th class="text-center">Kemas</th>
            <th class="text-center">Inputor</th>
            <th class="text-center">Produksi</th>
            <th class="text-center">Lab</th>
            <th class="text-center">Finance</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $dataF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dF): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="text-center"><?php echo e($df->id_feasibility); ?></td>
            <td class="text-center"><?php echo e($df->formula->nama_produk); ?> </td>
            <td class="text-center"><?php echo e($df->formula->updated_at); ?></td>
            <td class="text-center"><a href='<?php echo url('/konsep');; ?>' type="submit" class="btn btn-danger fa fa-edit"></a>
            <button type="submit" class="btn btn-info fa fa-check" disabled></button></td>
            <td class="text-center"><a href='<?php echo url('/mes');; ?>' type="submit" class="btn btn-danger fa fa-edit"></a>
            <button type="submit" class="btn btn-info fa fa-check" disabled></button></td>
            <?php if(auth()->user()->role->namaRule === 'produksi'): ?>
            <td class="text-center"><a href='<?php echo url('/prod');; ?>' type="submit" class="btn btn-danger fa fa-edit"></a>
            <button type="submit" class="btn btn-info fa fa-check" disabled></button></td>
            <?php elseif(auth()->user()->role->namaRule === 'inputor'): ?>
            <td class="text-center"><a href='<?php echo url('/prod2');; ?>' type="submit" class="btn btn-danger fa fa-edit"></a>
            <button type="submit" class="btn btn-info fa fa-check" disabled></button></td>
            <?php else: ?>
            <td class="text-center"><a href='<?php echo url('/prod');; ?>' type="submit" class="btn btn-danger fa fa-edit"></a>
            <button type="submit" class="btn btn-info fa fa-check" disabled></button></td>
            <?php endif; ?>
            <td class="text-center"><a href='<?php echo url('/datalab');; ?>' type="submit" class="btn btn-danger fa fa-edit"></a>
            <button type="submit" class="btn btn-info fa fa-check" disabled></button></td>
            <td class="text-center"><a href='<?php echo url('/fin');; ?>' type="submit" class="btn btn-danger fa fa-edit"></a>
            <button type="submit" class="btn btn-info fa fa-check" disabled></button></td>
            <td class="text-center">
              <div class="btn-group">
                <button class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Selesai" disabled><i class="fa fa-check">Selesai</i></button>
                </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>