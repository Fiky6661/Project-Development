<?php $__env->startSection('judulnya', 'NUTRITION FACT'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-info">
                <div class="panel-heading"><h4><b>Input Nutrition Data & BTP Carry Over</b></h4></div>
                <div class="panel-body">
                    <?php $__currentLoopData = $bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(url('nutrition/'.$b->id)); ?>" method="post" enctype="multipart/form-data">
                        <table class="table">
                            <tr>
                                <td class="form-group">
                                    <label for="">BAHAN BAKU </label>
                                    <input type="text" name="bahan" class="form-control " value="1" readonly>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Lemak</label>
                                        <input type="text" name="lemak" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">SFA</label>
                                        <input type="text" name="sfa" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Karbohidrat</label>
                                        <input type="text" name="karbohidrat" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Gula Total</label>
                                        <input type="text" name="gula" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="">Laktosa</label>
                                        <input type="text" name="laktosa" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Sukrosa</label>
                                        <input type="text" name="sukrosa" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Serat</label>
                                        <input type="text" name="serat" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Serat Larut</label>
                                        <input type="text" name="serat_larut" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Protein</label>
                                        <input type="text" name="protein" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="">Kalori</label>
                                        <input type="text" name="kalori" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Na (mg)</label>
                                        <input type="text" name="na" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">K (mg)</label>
                                        <input type="text" name="k" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Ca (mg)</label>
                                        <input type="text" name="ca" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Mg (mg)</label>
                                        <input type="text" name="mg" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="">P (mg)</label>
                                        <input type="text" name="p" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Beta Glucan</label>
                                        <input type="text" name="beta" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Cr (mcg)</label>
                                        <input type="text" name="cr" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Vitamin C (mg)</label>
                                        <input type="text" name="vit_c" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Vitamin E (mg)</label>
                                        <input type="text" name="vit_e" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="">Vitamin D (IU)</label>
                                        <input type="text" name="vit_d" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Carnitin (mg)</label>
                                        <input type="text" name="carnitin" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">CLA (mg)</label>
                                        <input type="text" name="cla" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Sterol Ester (mg)</label>
                                        <input type="text" name="sterol" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Chondroitin (mg)</label>
                                        <input type="text" name="chondroitin" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="">Omega 3</label>
                                        <input type="text" name="omega_3" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">DHA</label>
                                        <input type="text" name="dha" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">EPA</label>
                                        <input type="text" name="epa" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Creatine</label>
                                        <input type="text" name="creatine" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Lysine</label>
                                        <input type="text" name="lysin" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="">Glucosamine (mg)</label>
                                        <input type="text" name="glucosamin" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Kolin</label>
                                        <input type="text" name="kolin" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">MUFA</label>
                                        <input type="text" name="mufa" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Linoleic Acid (Omega 6)</label>
                                        <input type="text" name="linoleic_acid" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Linoleic Acid</label>
                                        <input type="text" name="linoleic" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="">Oleic Acid (Omega 9)</label>
                                        <input type="text" name="oleic" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Sorbitol</label>
                                        <input type="text" name="sorbitol" class="form-control form-control-sm">
                                    </div>
                                </td>    
                                <td>
                                    <div class="form-group">
                                        <label for="">Maltitol</label>
                                        <input type="text" name="maltitol" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Kafein</label>
                                        <input type="text" name="kafein" class="form-control form-control-sm">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <label for="">Kolestrol</label>
                                        <input type="text" name="kolestrol" class="form-control form-control-sm">
                                    </div>
                                </td>
                            </tr>
                        </table>
                        <button class="btn btn-success btn-block btn-lg" stype="submit">SIMPAN</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('devwb.tempwb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>