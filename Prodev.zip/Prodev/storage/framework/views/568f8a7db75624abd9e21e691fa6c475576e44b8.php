<!DOCTYPE html>
<html lang="en">

<head>
  <title><?php echo $__env->yieldContent('title'); ?></title></title>

  <!-- Favicons -->
  <link href="<?php echo e(asset('img/favicon.ico')); ?>" rel="icon">
  <!-- Bootstrap core CSS -->
  <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('css/custom.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/daterangepicker.css')); ?>" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
  
</head>

<body> 
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        </div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><img src="<?php echo e(asset('img/pro.png')); ?>"><b>PRO<span>DEV</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
      </div>
      <div class="top-menu">
        <br>
        <ul class="nav pull-right top-menu">
        <?php if( auth()->check() ): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('MyProfile')); ?>"><i class="fa fa-user"></i> Hello,<?php echo e(Auth::user()->name); ?></a></li>
        <?php endif; ?>
          <li><a href="signout" class="btn btn-lg"><i class="fa fa-sign-out"></i> Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
      <section class="wrapper site-min-height">
       <?php echo $__env->yieldContent('content'); ?>
    </section>
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
        <strong>PT. NUTRIFOOD INDONESIA</strong>
        </p>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery-ui-1.9.2.custom.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.ui.touch-punch.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/daterangepicker.js')); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
  <!--script for this page-->

</body>
</html>