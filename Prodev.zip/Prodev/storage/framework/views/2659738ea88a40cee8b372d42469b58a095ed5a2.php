<?php $__env->startSection('title', 'Formula'); ?>

<?php $__env->startSection('judulnya', 'Formula List'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt">
          <div class="col-lg-8 col-md-8 col-sm-12">
              <div class="showback">
                <h4>FORMULA YANG SEDANG DIPROSES</h4>
                <table class="table table-striped table-advance table-hover">

                <tr>

                <th>ID</th>
                <th>Kode Formula</th>
                <th>Nama Produk</th>
                <th>Revisi</th>
                <th>Versi</th>
                <th>PV</th>
                <th>Feasibility</th>
                <th>Nutfact</th>
                <th>Status</th>
                <th>Action</th>

                </tr>

              <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($formula->workbook_id == $workbooks->id): ?>

              <tr>

              <td><?php echo e($formula->id); ?></td>
              <td><?php echo e($formula->kode_formula); ?></td>
              <td><?php echo e($formula->nama_produk); ?></td>
              <td><?php echo e($formula->revisi); ?></td>
              <td><?php echo e($formula->versi); ?></td>
              <td><?php echo e($formula->vv); ?></td>
              <td><?php echo e($formula->status_fisibility); ?></td>
              <td><?php echo e($formula->status_nutfact); ?></td>
              <td><?php echo e($formula->status); ?></td>

              <td>

              <?php echo e(csrf_field()); ?>

              <a class="btn btn-info" href="<?php echo e(route('formula.show',$formula->id)); ?>">Show</a>
              <a class="btn btn-warning" href="<?php echo e(route('formula.edit',$formula->id)); ?>">Edit</a>
              <?php echo Form::open(['method' => 'DELETE','route' => ['formula.destroy', $formula->id],'style'=>'display:inline']); ?>

              <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

              </td>

              </tr>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </table>

              </div>

              <div class="showback">
                <h4>FORMULA LIST</h4>
                <table class="table table-striped table-advance table-hover">

                <tr>

                <th>ID</th>
                <th>Kode Formula</th>
                <th>Nama Produk</th>
                <th>Revisi</th>
                <th>Versi</th>
                <th>PV</th>
                <th>Feasibility</th>
                <th>Nutfact</th>
                <th>Status</th>
                <th>Action</th>
                <th>Pengajuan</th>

                </tr>

            <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($formula->workbook_id == $workbooks->id): ?>
              <tr>

              <td><?php echo e($formula->id); ?></td>
              <td><?php echo e($formula->kode_formula); ?></td>
              <td><?php echo e($formula->nama_produk); ?></td>
              <td><?php echo e($formula->revisi); ?></td>
              <td><?php echo e($formula->versi); ?></td>
              <td><?php echo e($formula->vv); ?></td>
              <td><?php echo e($formula->status_fisibility); ?></td>
              <td><?php echo e($formula->status_nutfact); ?></td>
              <td><?php echo e($formula->status); ?></td>

              <td>

              <?php echo e(csrf_field()); ?>

              <a class="btn btn-info" href="<?php echo e(route('formula.show',$formula->id)); ?>">Show</a>
              <a class="btn btn-warning" href="<?php echo e(route('formula.edit',$formula->id)); ?>">Edit</a>
              <?php echo Form::open(['method' => 'DELETE','route' => ['formula.destroy', $formula->id],'style'=>'display:inline']); ?>

              <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

              </td>

              <td>
                <?php if(empty($formula->vv)): ?>
                <a class="btn btn-info" href="">PV</a>
                <?php endif; ?>
              <?php if($formula->vv=='ya'): ?>
                  <?php if(empty($formula->status_feasibility)): ?>
                  <a class="btn btn-info" href="">Feasibility</a>
                  <?php endif; ?>
                  <?php if(empty($formula->status_nutfact)): ?>
                  <a class="btn btn-info" href="">Nutfact</a>
                  <?php endif; ?>
              <?php endif; ?>
              </td>

              </tr>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </table>
              </div>

          </div>
          <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="showback">
        <h4>STATUS WORKBOOK</h4>
        <br>
        <table class="table table-hover">
                <tbody>
                  <tr>
                    <td>NAMA WORKBOOK</td>
                    <td><?php echo e($workbooks->nama_project); ?></td>
                  </tr>
                  <tr>
                    <td>MANDATORY REQUIREMENT</td>
                    <td><?php echo e($workbooks->mnrq); ?></td>
                  </tr>
                  <tr>
                    <td>TARGET KONSUMEN</td>
                    <td><?php echo e($workbooks->tarkon->tarkon); ?></td>
                  </tr>
                </tbody>
              </table>
        <button type="button" class="btn btn-primary btn-lg btn-block" disable>PROSES</button>
        <h4>ACTION</h4>
        <?php if(empty($formulas)): ?>
        <button class="btn btn-info" data-toggle="modal" data-target="#FB"><i class="fa fa-plus"></i>Formula Baru</button>
        <?php else: ?>
        <button class="btn btn-info" data-toggle="modal" data-target="#FB"><i class="fa fa-plus"></i> Naik Versi</button>
        <?php endif; ?>
        <button class="btn btn-warning"><i class="fa fa-check"></i> SELESAI</button>
        <button class="btn btn-danger"><i class="fa fa-times"></i> BATAL</button>
            </div>

<!-- FB Modal -->
<div class="modal fade" id="FB" tabindex="-1" role="dialog" aria-labelledby="FBModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="FBModalLabel">Formula Baru</h4>
                    </div>
                      
                    <div class="modal-body">

                    <form method="POST" action="<?php echo e(route('formula.store')); ?>">
                    <label for="nama_produk" class="control-label">Nama Produk</label>
                        <input class="form-control" id="nama_produk" name="nama_produk" minlength="2" type="text" required />
                    
                        <div class="row">
                            <div class="col-md-4">
                                <label for="revisi" class="control-label">Revisi</label>
                                <input class="form-control" id="revisi" name="revisi" type="text" value="AA" disabled />
                            </div>
                            <div class="col-md-4">
                                <label for="versi" class="control-label">Versi</label>
                                <input class="form-control" id="versi" name="versi" type="text" disabled />
                            </div>
                            <div class="col-md-4">
                                <label for="kode_formula" class="control-label">Kode Formula</label>
                                <input class="form-control" id="kode_formula" name="kode_formula" type="text" required />  
                            </div>
                        </div> 
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                      <button type="submit" class="btn btn-primary"><i fa fa-plus></i>Add</button>
                    <?php echo e(csrf_field()); ?>

                    </div>
                    </form>
                  </div>
                </div>
              </div>


            </div>
          </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('devwb.tempwb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>