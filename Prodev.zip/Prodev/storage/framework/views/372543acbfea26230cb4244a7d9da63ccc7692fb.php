<?php $__env->startSection('title', 'Approved User'); ?>

<?php $__env->startSection('judulnya','Approved User'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="form-panel">

<table class="table table-striped table-advance table-hover">

<tr>

    <th>Nama</th>

    <th>Username</th>

    <th>Email</th>

    <th>Departement</th>

    <th>Level</th>

    <th>Status</th>

    <th>Action</th>

</tr>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($user->status =='active' || $user->status =='nonactive'): ?>

<tr>

<td><?php echo e($user->name); ?></td>

<td><?php echo e($user->username); ?></td>

<td><?php echo e($user->email); ?></td>

<td><?php echo e($user->departement->dept); ?></td>

<td><?php echo e($user->role->namaRule); ?></td>

<td><?php echo e($user->status); ?></td>

<td>

    <?php echo e(csrf_field()); ?>

    <a class="btn btn-info" href="<?php echo e(route('usermanagement.show',$user->id)); ?>">Show</a>
    <?php if($user->status == 'active'): ?>
    <a class="btn btn-danger" href="<?php echo e(route('usermanagement.update',$user->id)); ?>">NonActive</a>
    <?php elseif($user->status == 'nonactive'): ?>
    <a class="btn btn-primary" href="">Active</a>
    <?php endif; ?>

</td>

</tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>