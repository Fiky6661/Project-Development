<?php $__env->startSection('title', 'Formula'); ?>

<?php $__env->startSection('judulnya', 'FORMULA LIST'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12"> 
    <div class="showback" style="border-radius:3px;">
      <table class="table table-hover table-bordered">
        <thead>
          
        <tr>
            <th class="text-center">No</th>
            <th class="text-center">Nama Pengirim</th>
            <th class="text-center">Departement</th>
            <th class="text-center">Nama Produk</th>
            <th class="text-center">Project</th>
            <th class="text-center">Tanggal Masuk</th>
            <th class="text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="text-center"><?php echo e($formula->id); ?></td>
            <td class="text-center"><?php echo e($formula->workbook->user->name); ?></td>
            <td class="text-center"><?php echo e($formula->workbook->user->departement->dept); ?></td>
            <td class="text-center"><?php echo e($formula->nama_produk); ?></td>
            <td class="text-center"><?php echo e($formula->workbook->nama_project); ?></td>
            <td class="text-center"><?php echo e($formula->updated_at); ?></td>
              <div class="btn-group">
              <td class="text-center"><a href="<?php echo e(route('myFeasibility',$formula->id)); ?>" type="submit" data-toggle="tooltip" title="Lihat" class="btn btn-primary fa fa-folder-open"></a>
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('feasibility.tempfeasibility', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>