<?php $__env->startSection('title','Feasibility|Inputor'); ?>

<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
	<div class="panel-heading">
	<h2>* Data SDM Mesin</h2>
	</div>
	<div class="panel-body">
    <table class="table table-hover table-bordered">
      <thead>
        <tr>
        <th class="text-center">No</th>
          <th class="text-center">mesin</th>
          <th class="text-center">Runtime</th>
          <th class="text-center">standar SDM</th>
          <th class="text-center">SDM</th>
          <th class="text-center">Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php $no = 0;?>
        <?php $__currentLoopData = $dataM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(url('/updatesdmmesin')); ?>/<?php echo e($dM->id_mesin); ?>" method="post">
        <?php echo csrf_field(); ?>

    <tr>
    <div class="col-md-1 col-sm-1 col-xs-12">
        <input type="hidden" name="finance" maxlength="45" required="required" value="<?php echo e($fe->id_feasibility); ?>" class="form-control col-md-7 col-xs-12">
    </div>
    <?php $no++ ;?>
    <td><?php echo e($no); ?></td>
    <td><?php echo e($dM->meesin->Direct_Activity); ?></td>
    <td class="text-center"><?php echo e($dM->runtime); ?> Menit</td>
    <td class="text-center">10 Orang </td>
    <?php if($dM->SDM==NULL): ?>
    <td><input id="SDM" name="SDM" class="date-picker form-control col-md-7 col-xs-12" type="text"></td> 
    <td><button type="submit" class="btn btn-primary">Submit</button></td>
    <?php else: ?>
    <td class="text-center"><?php echo e($dM->SDM); ?> orang</td>
    <td class="text-center"><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal<?php echo e($dM->id_mesin); ?>" ">Edit</button>
    <div class="modal fade" id="exampleModal<?php echo e($dM->id_mesin); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content text-left">
          <div class="modal-header">
            <h3 class="modal-title" id="exampleModalLabel">Edit Data
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button></h3>
          </div>
          <div class="modal-body">
            <form >
            <div class="form-group">
                <label for="recipient-name" class="col-form-label">Runtime Mesin:</label>
                <input id="SDM" value="<?php echo e($dM->SDM); ?>" name="SDM" class="date-picker form-control" type="text">
              </div></div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
                        </div>
                      </div>
                    </div>
                  </div>
    <?php endif; ?>
    </tr>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div> 

<div class="panel panel-default">
	<div class="panel-heading">
	<h2>* Data SDM OH</h2>
	</div>
	<div class="panel-body">
    <table class="table table-hover table-bordered">
    <thead>
      <tr>
      <th class="text-center">No</th>
        <th class="text-center">OH</th>
        <th class="text-center">Runtime</th>
        <th class="text-center">Standar SDM</th>
        <th class="text-center">SDM</th>
        <th class="text-center">Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php $no = 0;?>
      <?php $__currentLoopData = $dataO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dO): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(url('/updatesdmoh')); ?>/<?php echo e($dO->id_oh); ?>" method="post">
          <?php echo csrf_field(); ?>

          <?php $no++ ;?>
          <tr>
            <td><?php echo e($no); ?></td>
          <td><?php echo e($dO->dataoh->direct_activity); ?></td>
          <td class="text-center"><?php echo e($dO->runtime); ?> Menit</td>
          <td class="text-center">10 Orang</td>
          <?php if($dO->SDM==NULL): ?>
          <td><input id="SDM" name="SDM" class="date-picker form-control col-md-7 col-xs-12" type="text"></td> 
          <td><button type="submit" class="btn btn-primary">Submit</button></td>
          <?php else: ?>
          <td class="text-center"><?php echo e($dO->SDM); ?> orang</td>
          <td class="text-center"><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal2<?php echo e($dO->id_oh); ?>" >Edit</button>
          <div class="modal fade" id="exampleModal2<?php echo e($dO->id_oh); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
    <div class="modal-content text-left">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Edit Data
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button></h3>
      </div>
      <div class="modal-body">
        <form>
        <div class="form-group">
                <label for="recipient-name" class="col-form-label">SDM OH:</label>
                <input id="SDM" value="<?php echo e($dO->SDM); ?>"  name="SDM" class="date-picker form-control" type="text">
              </div></div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
      </form>
    </div>
  </div>
</div>
          <?php endif; ?>
        </tr>
      </form>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
<div class="ln_solid"></div>
  <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">    
                      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal2">selesai</button>
                          <div class="modal" id="myModal2">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                  <h4>Yakin Dengan Data tersebut??</h4>
                                </div>
                                <div class="modal-footer">
                                
                                <a href="<?php echo e(route('formula.feasibility')); ?>" class="btn btn-primary" type="submit">selesai</a>
                                </div>
                              </div>
                            </div>
                          </div> 
  </div>
</div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('produksi.tempproduksi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>