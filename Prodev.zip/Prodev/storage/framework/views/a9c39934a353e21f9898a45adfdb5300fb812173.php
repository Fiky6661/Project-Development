<?php $__env->startSection('title', 'feasibility'); ?>

<?php $__env->startSection('judulnya', 'List Feasibility'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12"> 
  
    <div class="showback" style="border-radius:3px;">
    <table>
    
    <tr><h4>Nama Produk : <?php echo e($myFormula->nama_produk); ?></h4></tr>
    <tr><h4>Project : <?php echo e($myFormula->workbook->nama_project); ?></h4></tr>
    <tr><h4>Tanggal masuk : <?php echo e($myFormula->updated_at); ?></h4></tr>
    <tr><h4>Tambah Data : 
    <a class="btn btn-primary btn-sm fa fa-plus" data-toggle="tooltip" data-placement="top" title="tambah Data" href="<?php echo e(route('upFeasibility',$myFormula->id)); ?>"></a></h4>
    </tr>
    
  </table>
      <table class="table table-hover table-bordered ">
        <thead>
        
        <tr>
            <th class="text-center">Feasibility</th>
            <th class="text-center">Status Evaluator</th>
            <th class="text-center">Status Produksi</th>
            <th class="text-center">Status Kemas</th>
            <th class="text-center">Status Lab</th>
            <th class="text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $dataF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dF): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="text-center"><?php echo e($dF->kemungkinan); ?></td>
            <td class="text-center"><?php echo e($dF->status_mesin); ?></td>
            <td class="text-center"><?php echo e($dF->status_sdm); ?></td>
            <td class="text-center"><?php echo e($dF->status_kemas); ?></td>
            <td class="text-center"><?php echo e($dF->status_lab); ?></td>
            <td class="text-center">

            <?php if(auth()->user()->role->namaRule === 'evaluator'): ?>
            <a href="<?php echo e(route('datamesin',$dF->id_feasibility)); ?>" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            <?php elseif(auth()->user()->role->namaRule === 'kemas'): ?>
            <a href="<?php echo e(route('konsepkemas',$dF->id_feasibility)); ?>" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            <?php elseif(auth()->user()->role->namaRule === 'lab'): ?>
            <a href="<?php echo e(route('datalab',$dF->id_feasibility)); ?>" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            <?php elseif(auth()->user()->role->namaRule === 'produksi'): ?>
            <a href="<?php echo e(route('produksi',$dF->id_feasibility)); ?>" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            <?php elseif(auth()->user()->role->namaRule === 'finance'): ?>
            <a href="<?php echo e(route('finance',$dF->id_feasibility)); ?>" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            <?php endif; ?>

            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('feasibility.tempfeasibility', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>