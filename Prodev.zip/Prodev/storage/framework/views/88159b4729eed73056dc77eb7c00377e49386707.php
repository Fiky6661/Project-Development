<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>PRODEV - Project Development</title>

  <!-- Favicons -->
  <link href="<?php echo e(asset('img/pro.png')); ?>" rel="icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">

</head>

<body>
  <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
  <div id="login-page">
    <div class="container">
      <form class="form-login" method="post" action="<?php echo e(route('add')); ?>">
        <h2 class="form-login-heading">Register Now</h2>
        <div class="login-wrap">
                    <input class="form-control" id="name" name="name" placeholder="nama" value="<?php echo e(old('name')); ?>" type="text" minlength="2" autofocus required/>
                    <br>
                    <input class="form-control " id="username" name="username" placeholder="username" value="<?php echo e(old('username')); ?>" type="text" minlength="6" maxlength="12" required/>
                    <br>
                    <input class="form-control " id="password" name="password" placeholder="password" type="password" minlength="6" maxlength="12" required/>
                    <br>
                    <input class="form-control " id="password_confirmation" name="password_confirmation" placeholder="confirm_password" type="password" required/>
                    <br>
                    <input class="form-control " id="email" name="email" placeholder="E-mail" value="<?php echo e(old('email')); ?>" type="email" required/>
                    <br>
                    <select id="departement" name="departement" class="form-control" >
                    <option disabled selected>Departement</option>
                    <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($dept->id); ?>" <?php echo e(old('departement') == $dept->id ? 'selected' : ''); ?>><?php echo e($dept->dept); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <br>
                    <select class="form-control" id="role" name="role">
                    <option disabled selected>Levels</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e(old('role') == $role->id ? 'selected' : ''); ?>><?php echo e($role->namaRule); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <br>
          <button class="btn btn-theme btn-block" type="submit"><i class="fa fa-lock"></i> SIGN IN</button>
          <?php echo e(csrf_field()); ?>

          <?php echo $__env->make('formerrors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </form>
          <hr>
          <div class="registration">
            Already Have account ?<br/>
            <a href="<?php echo e(route('signin')); ?>">
              login
              </a>
          </div>
        </div>
    </div>
  </div>

  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="lib/jquery.backstretch.min.js"></script>
  <script>
    $.backstretch("img/awal.jpg", {
      speed: 1000
    });
  </script>
</body>

</html>
