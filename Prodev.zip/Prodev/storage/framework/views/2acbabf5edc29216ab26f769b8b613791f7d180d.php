<?php $__env->startSection("content"); ?>
<div class="row">
	<div class="col-md-14">
		<div class="showback">
			<div class="row">
			  <div class="col-md-6"><h4><i class="fa fa-cube"></i> Data Bahan Baku</h4> </div>
			  <div class="col-md-6 text-right"><h5><i class="fa fa-home"></i> Data Bahan Baku</a></h5></div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="showback" style="border-radius:3px;">
			<table class="table table-hover table-bordered" id="Table" style="overflow-x: scroll;">
				<thead>
					<tr>
						<th class="text-center" style="width: 5%;">No</th>
						<th class="text-center">Ingredient</th>
						<th class="text-center">Lemak</th>
						<th class="text-center">SFA</th>
						<th class="text-center">Karbohidrat</th>
						<th class="text-center">Gula</th>
						<th class="text-center">Laktosa</th>
						<th class="text-center">Sukrosa</th>
						<th class="text-center">Serat</th>
						<th class="text-center">Serat Larut</th>
						<th class="text-center">Protein</th>
						<th class="text-center">Kalori</th>
						<th class="text-center">Na (mg)</th>
						<th class="text-center">K (mg)</th>
						<th class="text-center">Ca (mg)</th>
						<th class="text-center">Mg (mg)</th>
						<th class="text-center">P (mg)</th>
						<th class="text-center">Beta Glucan</th>
						<th class="text-center">Cr(mcg)</th>
						<th class="text-center">Vit C (mg)</th>
						<th class="text-center">Vit E (mg)</th>
						<th class="text-center">Vit D (mg)</th>
						<th class="text-center">Carnitin (mg)</th>
						<th class="text-center">CLA (mg)</th>
						<th class="text-center">Sterol Ester (mg)</th>
						<th class="text-center">Chondroitin (mg)</th>
						<th class="text-center">Omega 3</th>
						<th class="text-center">DHA</th>
						<th class="text-center">EPA</th>
						<th class="text-center">Creatine</th>
						<th class="text-center">Lysine</th>
						<th class="text-center">Glucosamine (mg)</th>
						<th class="text-center">Kolin </th>
						<th class="text-center">MUFA</th>
						<th class="text-center">Linoleic Acid (Omega 6)</th>
						<th class="text-center">Linolenic Acid</th>
						<th class="text-center">Sorbitol</th>
						<th class="text-center">Maltitol</th>
						<th class="text-center">Kafein</th>
						<th class="text-center">Kolestrol</th>
					</tr>
				</thead>
				<?php $__currentLoopData = $tampil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
				<tbody>
				<tr>
					<td class="text-center"><?php echo e($loop->iteration); ?></td>
					<td class="text-left"><?php echo e($i->get_bahan->nama_sederhana); ?></td>
					<td class="text-center"><?php echo e($i->Lemak); ?> %</td>
					<td class="text-center"><?php echo e($i->SFA); ?> %</td>
					<td class="text-center"><?php echo e($i->karbohidrat); ?> %</td>
					<td class="text-center"><?php echo e($i->gula_total); ?> %</td>
					<td class="text-center"><?php echo e($i->laktosa); ?> %</td>
					<td class="text-center"><?php echo e($i->sukrosa); ?> %</td>
					<td class="text-center"><?php echo e($i->serat); ?> %</td>
					<td class="text-center"><?php echo e($i->serat_larut); ?> %</td>
					<td class="text-center"><?php echo e($i->protein); ?> %</td>
					<td class="text-center"><?php echo e($i->na); ?> %</td>
					<td class="text-center"><?php echo e($i->k); ?> %</td>
					<td class="text-center"><?php echo e($i->ca); ?> %</td>
					<td class="text-center"><?php echo e($i->mg); ?> %</td>
					<td class="text-center"><?php echo e($i->p); ?> %</td>
					<td class="text-center"><?php echo e($i->beta_glucan); ?> %</td>
					<td class="text-center"><?php echo e($i->cr); ?> %</td>
					<td class="text-center"><?php echo e($i->vit_c); ?> %</td>
					<td class="text-center"><?php echo e($i->vit_e); ?> %</td>
					<td class="text-center"><?php echo e($i->vit_d); ?> %</td>
					<td class="text-center"><?php echo e($i->carnitin); ?> %</td>
					<td class="text-center"><?php echo e($i->cla); ?> %</td>
					<td class="text-center"><?php echo e($i->sterol_ester); ?> %</td>
					<td class="text-center"><?php echo e($i->chondroitin); ?> %</td>
					<td class="text-center"><?php echo e($i->omega_3); ?> %</td>
					<td class="text-center"><?php echo e($i->dha); ?> %</td>
					<td class="text-center"><?php echo e($i->epa); ?> %</td>
					<td class="text-center"><?php echo e($i->creatine); ?> %</td>
					<td class="text-center"><?php echo e($i->lysine); ?> %</td>
					<td class="text-center"><?php echo e($i->glucosamine); ?> %</td>
					<td class="text-center"><?php echo e($i->kolin); ?> %</td>
					<td class="text-center"><?php echo e($i->mufa); ?> %</td>
					<td class="text-center"><?php echo e($i->linoleic_acido6); ?> %</td>
					<td class="text-center"><?php echo e($i->linoleic_acid); ?> %</td>
					<td class="text-center"><?php echo e($i->oleic_acid); ?> %</td>
					<td class="text-center"><?php echo e($i->sorbitol); ?> %</td>
					<td class="text-center"><?php echo e($i->maltitol); ?> %</td>
					<td class="text-center"><?php echo e($i->kafein); ?> %</td>
					<td class="text-center"><?php echo e($i->kolestrol); ?> %</td>		
				</tr>
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>