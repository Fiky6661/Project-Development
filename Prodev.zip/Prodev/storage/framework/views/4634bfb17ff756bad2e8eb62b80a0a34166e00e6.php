<?php $__env->startSection('title','Feasibility|inputor'); ?>

<?php $__env->startSection('menu'); ?>



<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <h2>Form mesin</h2>
          <div class="x_content">
            <ul class="nav nav-tabs nav-justified">
              <li class="active">
                <a data-toggle="tab" href="#DM">Data mesin</a>
              </li>
              <li>
                <a data-toggle="tab" href="#RM">Rate mesin</a>
              </li>
              <li>
                <a data-toggle="tab" href="#DO">Data OH</a>
              </li>
              <li>
                <a data-toggle="tab" href="#RO">Rate OH</a>
              </li>
            </ul>
          </div>
          <!-- /panel-heading -->
          <div class="panel-body">
            <div class="tab-content">
              <div id="DM" class="tab-pane active">
                <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(route('mss')); ?>" method="post">
                  <div class="row">
                    <div class="col-lg-12 detailed">
                      <h4 class="mb">Data aktifitas Mesin</h4>
                        <table class="table table-bordered" id="sampleTable">
                          <thead>
                            <tr>
                              <th></th>
                              <th>workcenter</th>
                              <th>gedung</th>
                              <th class="hidden-phone">kategori</th>
                              <th class="hidden-phone">Activity</th>
                              <th class="hidden-phone">nama kategori</th>
                            </tr>
                          </thead>
                            <?php $__currentLoopData = $mesins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><input type="checkbox" id="pmesin" name="pmesin[]" value="<?php echo e($mesin->id_data_mesin); ?>"></td>
                              <td><?php echo e($mesin->workcenter); ?></td>
                              <td><?php echo e($mesin->gedung); ?></td>
                              <td><?php echo e($mesin->Direct_Activity); ?></td>
                              <td><?php echo e($mesin->kategori); ?></td>
                              <td><?php echo e($mesin->nama_kategori); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">                        
                        <button type="submit" class="btn btn-success">Submit</button>
			                    <?php echo e(csrf_field()); ?>

                      </div>
                    </div>
                  </div>
                </form>
              </div>
                  
              <div id="DO" class="tab-pane">
                <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(route('ohh')); ?>" method="POST">
                  <div class="row">
                    <div class="col-lg-12  detailed">
                      <h4 class="mb">Data aktifitas OH</h4>
                        <table class="table table-bordered" id="Table">
                          <thead>
                            <tr>
                              <th></th>
                              <th>workcenter</th>
                              <th>gedung</th>
                              <th class="hidden-phone">Activity</th>
                              <th class="hidden-phone">kategori</th>
                              <th class="hidden-phone">Driver</th>
                            </tr>
                          </thead>
                            <?php $__currentLoopData = $aktifitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><input type="checkbox" id="oh" name="oh[]" value="<?php echo e($ak->id_aktifitasOH); ?>"></td>
                              <td><?php echo e($ak->workcenter); ?></td>
                              <td><?php echo e($ak->gedung); ?></td>
                              <td><?php echo e($ak->direct_activity); ?></td>
                              <td><?php echo e($ak->kategori); ?></td>
                              <td><?php echo e($ak->driver); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">                        
                        <button type="submit" class="btn btn-success">Submit</button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
                    
              <!-- /tab-pane -->
              <div id="RM" class="tab-pane">
              <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="/mss" method="post">
                <div class="row">
                  <div class="col-lg-12 detailed">
                    <h4 class="mb">Rate Mesin</h4>
                      <table class="table table-hover table-bordered">
                        <thead>
                          <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">mesin</th>
                            <th class="text-center">Standar SDM</th>
                            <th class="text-center">Runtime</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $dataM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($dM->id_mesin); ?></td>
                              <td><?php echo e($dM->meesin->Direct_Activity); ?></td>
                              <td class="text-center">10</td>
                              <td><input name="runtimeoh" class="date-picker form-control col-md-7 col-xs-12" type="text"></td> 
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">                      
                      <button type="submit" class="btn btn-success">Submit</button>
			                    <?php echo e(csrf_field()); ?>

                      </div>
                  </div>
                </div>
              </form>
              </div>

              <!-- /tab-pane -->
              <div id="RO" class="tab-pane">
              <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="/ohh" method="post">
                <div class="row">
                  <div class="col-lg-12 detailed">
                    <h4 class="mb">Rate OH</h4>
                    <table class="table table-hover table-bordered">
                        <thead>
                          <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">OH</th>
                            <th class="text-center">Standar SDM</th>
                            <th class="text-center">Runtime</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $dataO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dO): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($dO->id_oh); ?></td>
                              <td><?php echo e($dO->dataoh->direct_activity); ?></td>
                              <td class="text-center">10</td>
                              <td><input name="runtimeoh" class="date-picker form-control col-md-7 col-xs-12" type="text"></td> 
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal2">Submit</button>
                            <div class="modal" id="myModal2">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <div class="modal-body">
                                    <h4>Yakin Dengan Data Yang Anda Masukan??</h4>
                                  </div>
                                  <div class="modal-footer">
                                  <button type="submit" class="btn btn-success">Submit</button>
			                              <?php echo e(csrf_field()); ?>

                                  </div>
                                </div>
                              </div>
                              </form>
                            </div>
                    </div>
                  </div>
                </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div> 
    </div>
  </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inputor.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>