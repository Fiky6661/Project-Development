<?php $__env->startSection('title', 'Data Kategori'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6" id="add">
            <div class="form-panel" >
            <h4><i class="fa fa-edit"></i> Edit Kategori</h4>
            <form method="POST" action="<?php echo e(route('kategori.update',$kategori->id)); ?>">
            <label for="" class="control-label">Kategori</label>
            <input class="form-control" id="kategori" name="kategori" placeholder="Kategori" value="<?php echo e($kategori->kategori); ?>" required />
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-edit"></i> Simpan Perubahan</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>