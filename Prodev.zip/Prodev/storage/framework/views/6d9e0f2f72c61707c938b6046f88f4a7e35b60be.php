<?php $__env->startSection('title', 'Data Maklon'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
            <?php if(session('status')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('status')); ?>

            </div>
            </div>
            <?php elseif(session('error')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('error')); ?>

            </div>
            </div>
            <?php endif; ?>
</div>

<!-- Maklon -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
    <h4><i class="fa fa-angle-double-right"></i>List Maklon</h4>
    <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Maklon </a>
        <div class="form-panel">
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Maklon</th>
                            <th>Keterangan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $maklons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maklon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($maklon->id); ?></td>
                            <td><?php echo e($maklon->maklon); ?></td>
                            <td><?php echo e($maklon->keterangan); ?></td>
                            <td>
                                <?php echo Form::open(['method' => 'Delete', 'route' => ['maklon.destroy', $maklon->id]]); ?>

                                <a class="btn btn-primary" href="<?php echo e(route('maklon.edit',$maklon->id)); ?>" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <button class="btn btn-danger" onclick="return confirm('Hapus Maklon ?')"><i class="fa fa-trash-o"></i> Delete</button>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
            <div class="form-panel" >
            <h4><i class="fa fa-plus"></i> Tambah Maklon</h4>
            <form method="POST" action="<?php echo e(route('maklon.store')); ?>">
            <label for="" class="control-label">Maklon</label>
            <input class="form-control" id="maklon" name="maklon" placeholder="Maklon" value="<?php echo e(old('maklon')); ?>" required />
            <label for="" class="control-label">Keterangan</label>
            <input class="form-control" id="keterangan" name="keterangan" placeholder="Keterangan" value="<?php echo e(old('keterangan')); ?>" required />
            <?php echo e(csrf_field()); ?>

            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">

$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>