<?php $__env->startSection('content'); ?>
<div class="row" >
  <div class="col-md-14">
    <div class="showback">
      <div class="row">
        <div class="col-md-6"><h4><i class="fa fa-book"></i> Data Pengajuan Nutfact</h4> </div>
        <div class="col-md-6 text-right"><h5><i class="fa fa-home"></i> / <a href="<?php echo e(url('/datapn')); ?>">Data Pengajuan Nutfact</a></h5></div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12"> 
    <div class="panel" style="border-radius:3px;">
      <div class="panel-body">
      <?php if(Auth::user()->name =="Fiky Taufik"): ?>
      <table class="table table-hover table-striped" id="sampleTable">
          <thead>
          <tr>
            <th class="text-center">No</th>
            <th class="text-center">Formula</th>
            <th class="text-center">Workbook</th>
            <th class="text-center">Tanggal Masuk</th>
            <th class="text-center">Status</th>
            <th class="text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $tampilkan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="text-center"><?php echo e($loop->iteration); ?></td>
            <td class="text-center"><?php echo e($data->nama_produk); ?></td>
            <td class="text-center"><?php echo e($data->get_wb->nama_project); ?></td>
            <td class="text-center"><?php echo e($data->created_at); ?></td>
            <td class="text-center"><!-- <?php if($data->status=="proses_f"): ?><i class="fa fa-check"></i><?php endif; ?> --></td>
            <td class="text-center">
              <div class="btn-group">
                <button class="btn btn-success" data-toggle="tooltip" data-placement="top" title="Selesai" disabled><i class="fa fa-check"></i></button>
                <button class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Kirim" disabled><i class="fa fa-rocket"></i></button>
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
        <?php else: ?>
        <table class="table table-hover table-striped" id="sampleTable">
          <thead>
          <tr>
            <th class="text-center">No</th>
            <th class="text-center">Formula</th>
            <th class="text-center">Workbook</th>
            <th class="text-center">Tanggal Masuk</th>
            <th class="text-center">Hasil Analisa</th>
            <th class="text-center">Perhitungan HAK</th>
            <th class="text-center">Perhitungan AKG</th>
            <th class="text-center">Perhitungan BTP CO</th>
            <th class="text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $tampilkan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="text-center"><?php echo e($loop->iteration); ?></td>
            <td class="text-center"><?php echo e($data->nama_produk); ?></td>
            <td class="text-center"><?php echo e($data->get_wb->nama_project); ?></td>
            <td class="text-center"><?php echo e($data->created_at); ?></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center">
              <div class="btn-group">
                <a href="<?php echo e(url('datanutri/'.$data->id)); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <?php endif; ?>
      </table>
    </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>