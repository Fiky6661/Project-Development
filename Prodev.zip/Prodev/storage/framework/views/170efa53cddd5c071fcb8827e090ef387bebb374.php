<!DOCTYPE html>
<html lang="en">

  <head>
    <title>PRODEV - Project Development</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/creative.min.css" rel="stylesheet">
    <!-- Favicons -->
    <link href="img/favicon.ico" rel="icon">

  </head>
  <body>
    <header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <img class="img-fluid mb-5 d-block mx-auto" src="img/proo.png" alt="">
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <p><strong><h2>Welcome To Product Development</h2></strong></p>
            <?php if( auth()->check() ): ?>
            <a href="logout" class="btnn">LOGOUT</a>
            <?php else: ?>
            <a href="login" class="btnn">LOGIN</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </header>
  </body>
</html>
