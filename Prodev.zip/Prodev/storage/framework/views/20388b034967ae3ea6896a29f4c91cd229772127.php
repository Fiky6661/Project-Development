<?php $__env->startSection('title', 'Edit SubBrand'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6" id="add">
            <div class="form-panel" >
            <h4><i class="fa fa-edit"></i> Edit Subbrand</h4>
            <form method="POST" action="<?php echo e(route('subbrand.update',$subbrand->id)); ?>">
            <label for="" class="control-label">Subbrand</label>
            <input class="form-control" id="subbrand" name="subbrand" value="<?php echo e($subbrand->subbrand); ?>" required />
            <br>
            <label for="" class="control-label">Brand</label>
            <br>
            <select id="brand" name="brand" class="form-control" style="width:500px;">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($brand->id); ?>" <?php echo e($subbrand->brand_id == $brand->id ? 'selected' : ''); ?>><?php echo e($brand->brand); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <label for="" class="control-label">Manager</label>
            <br>
                <select id="manager" name="manager" class="form-control" style="width:500px;">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($user->id); ?>" <?php echo e($subbrand->user_id == $user->id ? 'selected' : ''); ?>><?php echo e($user->role->namaRule); ?> - <?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <br>
            <br>
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>


            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="<?php echo e(route('subbrand.index')); ?>"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
$('#manager').select2({
    placeholder: "Pilih User Sebagai Manager",
    allowClear: true
});
$('#brand').select2({
    placeholder: "Pilih Brand",
    allowClear: true
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>