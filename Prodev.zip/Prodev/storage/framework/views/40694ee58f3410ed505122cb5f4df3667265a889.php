<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
		<div class="panel panel-primary">
			<div class="panel-heading">
				HASIL ANALISA
			</div>
			<div class="panel-body">
				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="col-md-5">
								<label class="col-md-12 control-label pull-right" style="margin-top: 5px;">Serving Size&nbsp:</label>
							</div>
	                        <div class="col-md-3">
	                            <input type="text" class="form-control pull-left" id="ss" value="15" disabled />
	                        </div>
	                        <div class="col-md-1 pull-left" style="margin-top: 5px;">gram</div>
	                    </div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
	                        <label class="col-md-6 control-label" style="margin-top: 5px;">Serving Size (liquid) :</label>
	                        <div class="col-md-3">
	                            <input type="text" class="form-control" id="ssl" disabled />
	                        </div>
	                        <div class="col-md-1" style="margin-top: 5px;">ml</div>
	                    </div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
	                        <label class="col-md-4 control-label" style="margin-top: 5px;">Berat Jenis :</label>
	                        <div class="col-md-3">
	                            <input type="text" class="form-control" id="bj" value="3" disabled />
	                        </div>
	                        <div class="col-md-1" style="margin-top: 5px;">gr/ml</div>
	                    </div>
					</div>
				</div><br><br>
				<div class="row">
					<div class="col-md-12">
						<table class="table table-hover">
							<thead>
								<tr>
									<th class="text-center">Check</th>
									<th class="text-center">No</th>
									<th class="text-center">Parameter</th>
									<th class="text-center">Hasil Analisa</th>
									<th class="text-center">Unit</th>
									<th class="text-center">AKG</th>
								</tr>
							</thead>
							<form action="<?php echo e(url('test')); ?>" method="post" enctype="multipart/form-data">
			                <?php echo e(csrf_field()); ?>

							<tbody>
								<!-- <tr style="background-color: #20c997;color: white;">
									<td class="text-center" style="width: 5%;">
										<i class="fa fa-check"></i>
									</td>
									<td class="text-center" style="width: 8%;">1</td>
									<td class="text-center" colspan="6">Proksimat</td>
								</tr> -->
								<?php $__currentLoopData = $tampilkan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td class="text-center" style="width: 5%;">
										<i class="fa fa-check"></i>
									</td>
									<td class="text-center text-danger" style="width: 8%;"><strong>WAJIB</strong></td>
									<td class="text-center"><?php echo e($data->parameter); ?></td>
									
									<td class="text-center" style="width: 15%;">
										<div class="form-group"><input type="number" pattern="[0-9.]+" name="keterangan[]" class="form-control" autofocus="on" id="ha" autocomplete="off" onfocus="mulaiHitung();" onblur="stopHitung();" value="" required></div>
									</td>
									<td class="text-center">%</td>
									<td  class="text-center">
										<span id="akg">325</span>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
						<hr style="border-color: #d4d7db;">
						<button type="submit" class="btn btn-block btn-lg btn-success" name="simpan">Simpan</button>
					</div>
				</div>
			</div>
		</div>
	</div>
<script type="text/javascript">
	function mulaiHitung(){
	otomatis = setInterval("hitung()",1);
	}

	function hitung(){
		var ss   = document.getElementById('ss').value;
		var ssl  = document.getElementById('ssl').value;
		var bj   = document.getElementById('bj').value;
		var ha   = document.getElementById('ha').value;
		var ps   = document.getElementById('ps').value;
		var akg  = document.getElementById('akg').innerHTML;

		var hitung  =(ss/bj);
		var hitung1 = (ss * 1) / 100;
		var hitung2 = (hitung1 * ha);
		var hitung3 = (ha / akg * 100);
		hitung2     = hitung2.toFixed(2);
		hitung3		= hitung3.toFixed(1);
		document.getElementById('ssl').value = hitung;
		document.getElementById('ps').value = hitung2;
		document.getElementById('akgg').value = hitung3;
	}

	function stopHitung(){
		clearInterval(otomatis);
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>