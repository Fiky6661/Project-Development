<?php $__env->startSection('title', 'Edit Formula'); ?>

<?php $__env->startSection('judul', 'Edit Formula'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12"></div>
<div class="col-lg-8 col-md-8 col-sm-12">
<div class="tabbable">
  <ul class="nav nav-tabs wizard">
    <li class="active"><a href="<?php echo e(route('step1',$formula->id)); ?>" ><span class="nmbr">1</span>Informasi Formula</a></li>
    <li><a href="<?php echo e(route('step2',$formula->id)); ?>"><span class="nmbr">2</span>Penyusunan</a></li>
    <li><a href="<?php echo e(route('step3',$formula->id)); ?>"><span class="nmbr">3</span>Premixs</a></li>
</ul>
</div>
</div>
</div>

<div class="row">
<div class="col-md-6">
    <div class="form-panel">
                        <h3>INFORMASI FORMULA</h3>
                        <form method="POST" action="<?php echo e(route('step1update',$formula->id)); ?>">
                        <label for="" class="control-label">Jenis Formula</label>
                        <div class="row">
                            <div class="col-md-6">
                                <select class="form-control" id="jenis" name="jenis">
                                <option value="baru"<?php echo e(( "baru" == $formula->jenis ) ? ' selected' : ''); ?> >Baru</option>
                                <option value="revisi"<?php echo e(( "revisi" == $formula->jenis ) ? ' selected' : ''); ?> >Revisi</option>
                                </select>
                            </div>
                        </div>

                        <label for="nama_produk" class="control-label">Nama Produk</label>
                        <input class="form-control" id="nama_produk" name="nama_produk" minlength="2" type="text" value="<?php echo e(old('nama_produk',$formula->nama_produk)); ?>" required />
                    
                        <div class="row">
                            <div class="col-md-4">
                                <label for="revisi" class="control-label">Revisi</label>
                                <input class="form-control" id="revisi" name="revisi" type="text" value="<?php echo e($formula->revisi); ?>" />
                            </div>
                            <div class="col-md-4">
                                <label for="versi" class="control-label">Versi</label>
                                <input class="form-control" id="versi" name="versi" type="text" value="<?php echo e($formula->versi); ?>" disabled />
                            </div>
                            <div class="col-md-4">
                                <label for="kode_formula" class="control-label">Kode Formula</label>
                                <input class="form-control" id="kode_formula" name="kode_formula" type="text" value="<?php echo e(old('kode_formula',$formula->kode_formula)); ?>" required />  
                            </div>
                        </div>  

                        <div class="row">
                            <div class="col-md-6">
                                <label for="" class="control-label">Brand</label>
                                <select class="form-control" id="subbrand" name="subbrand">
                                <?php $__currentLoopData = $subbrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subbrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subbrand->id); ?>"<?php echo e(( $subbrand->id == $formula->subbrand_id ) ? ' selected' : ''); ?> ><?php echo e($subbrand->subbrand); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="" class="control-label">Gudang</label>
                                    <select class="form-control" id="gudang" name="gudang">
                                    <?php $__currentLoopData = $gudangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gudang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gudang->id); ?>"<?php echo e(( $gudang->id == $formula->gudang_id ) ? ' selected' : ''); ?> ><?php echo e($gudang->gudang); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="" class="control-label">Produksi</label>
                                <select class="form-control" id="produksi" name="produksi" onchange="profunc()">
                                <?php $__currentLoopData = $produksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($produksi->id); ?>"<?php echo e(( $produksi->id == $formula->produksi_id ) ? ' selected' : ''); ?> ><?php echo e($produksi->produksi); ?>-<?php echo e($produksi->keterangan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6" id="dm">
                                <label for="" class="control-label">Maklon</label>
                                    <select class="form-control" id="maklon" name="maklon">
                                    <?php $__currentLoopData = $maklons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maklon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($maklon->id); ?>"<?php echo e(( $maklon->id == $formula->maklon_id ) ? ' selected' : ''); ?> ><?php echo e($maklon->maklon); ?>-<?php echo e($maklon->keterangan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                            </div>
                        </div>
    </div>
</div>
                    
                <!-- Nyebrang -->
<div class="col-md-6">
                    <div class="form-panel">

                        <label for="revisi" class="control-label">Main Item</label>
                        <input class="form-control" id="main_item" name="main_item" type="text" value="<?php echo e(old('main_item',$formula->main_item)); ?>" required />

                        <label for="revisi" class="control-label">Main Item Eks</label>
                        <input class="form-control" id="main_item_eks" name="main_item_eks" type="text" value="<?php echo e(old('main_item_eks',$formula->main_item_eks)); ?>" required />

                        <div class="row">
                            <div class="col-md-6">
                                <label for="bj" class="control-label">Berat Jenis</label>
                                <input class="form-control" id="bj" name="bj" type="number" step=any value="<?php echo e(old('bj',$formula->bj)); ?>" required />
                            </div>
                            <div class="col-md-6">
                                <label for="batch" class="control-label">Batch</label>
                                <input class="form-control" id="batch" name="batch" type="number" step=any value="<?php echo e(old('batch',$formula->batch)); ?>" required />
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="serving" class="control-label">Serving</label>
                                <input class="form-control" id="serving" name="serving" type="number" step=any value="<?php echo e(old('serving',$formula->serving)); ?>" required />
                            </div>
                            <div class="col-md-6">
                                <label for="liter" class="control-label">Liter</label>
                                <input class="form-control" id="liter" name="liter" type="number" step=any value="<?php echo e(old('liter',$formula->liter)); ?>" required />
                            </div>
                        </div>
                        
                        <label for="nama_produk" class="control-label">Keterangan</label>
                        <br>
                        <textarea style="min-width: 100%" name="keterangan" id="keterangan"><?php echo e(old('keterangan',$formula->keterangan)); ?></textarea>                
                        <br>
                        <br>
                        <button type="submit" class="btn btn-primary next-step">Save and continue</button>
                        <a href="<?php echo e(route('showworkbook',$formula->workbook_id)); ?>" type="button" class="btn btn-danger next-step">Batal</a>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo e(method_field('PATCH')); ?>

                        <?php echo $__env->make('formerrors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </form>
                    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
$(document).ready(function(){
    var produksi = document.getElementById("produksi");
    if(produksi.value == "1") {
        document.getElementById("dm").style.visibility = "visible";
        $('#maklon').removeAttr('disabled');        
    } else {
       document.getElementById("dm").style.visibility = "hidden";
       document.getElementById("maklon").value = "0";
    }
  });
function profunc() {
    var produksi = document.getElementById("produksi");
    if(produksi.value == "1") {
        document.getElementById("dm").style.visibility = "visible";
        $('#maklon').removeAttr('disabled');        
    } else {
       document.getElementById("dm").style.visibility = "hidden";
       document.getElementById("maklon").value = "0";
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('formula.tempformula', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>