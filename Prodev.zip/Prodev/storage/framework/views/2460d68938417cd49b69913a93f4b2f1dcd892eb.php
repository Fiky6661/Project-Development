<?php $__env->startSection('title', 'feasibility|Finance'); ?>

<?php $__env->startSection('judulnya', 'List Feasibility'); ?>

<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="col-md-12 col-sm-12 col-xs-12 content-panel">
  <div class="row">
<div class="panel-body">
            <div class="tab-content">
              <div id="DM" class="tab-pane active">

                  <div class="row">
                    <div class="col-lg-12 detailed">
                      <h4 class="mb">Data aktifitas Mesin</h4>
                      <p><button class="btn btn-primary fa fa-plus" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"> Tambah Data Mesin</button></p>
<div class="collapse" id="collapseExample">
<div class="panel panel-default">
	<div class="panel-heading">
	<h2>* Tambah Data</h2>
	</div>
	<div class="panel-body">
        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(route('Dm')); ?>" method="post">
				  <div class="form-group">
            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">Workcenter</label>
              <div class="col-md-5 col-sm-5 col-xs-12">
                <input type="text" name="workcenter" maxlength="45" required class="form-control col-md-7 col-xs-12">
              </div>
              <label class="control-label col-md-1 col-sm-1 col-xs-12" for="last-name">Gedung</label>
              <div class="col-md-4 col-sm-4 col-xs-12">
                <input type="text" name="gedung" maxlength="100" name="last-name" required class="form-control col-md-7 col-xs-12">
              </div>
          </div>
          <div class="form-group">
          <label class="control-label col-md-2 col-sm-2 col-xs-12" for="last-name">Kategori</label>
          <div class="col-md-4 col-sm-4 col-xs-12">
              <select class="form-control" name="kategori" id="kategori">
              <option value="0" disable="true" selected="true">--><--</option>
              <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value->id); ?>"><?php echo e($value->kategori); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
              </div>
            <label class="control-label col-md-1 col-sm-1 col-xs-12" for="last-name">Aktifitas</label>
              <div class="col-md-5 col-sm-5 col-xs-12">
                <input type="text" name="aktifitas" maxlength="8" name="last-name" required class="form-control col-md-7 col-xs-12">
              </div>
          </div>
          <div class="form-group">
              <label class="control-label col-md-2 col-sm-2 col-xs-12" for="last-name">Nama Kategori</label>
              <div class="col-md-10 col-sm-10 col-xs-12">
                <input type="text" name="Nkategori" maxlength="8" name="last-name" required class="form-control col-md-7 col-xs-12">
              </div>
          </div>
          <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
                <button class="btn btn-warning" type="reset">Reset</button>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal2">Submit</button>
                  <!-- The Modal -->
                  <div class="modal" id="myModal2">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                          <h4>Yakin Dengan Data Yang Anda Masukan??</h4>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-success">Submit</button>
			                    <?php echo e(csrf_field()); ?>

                        </div>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
        </form>
      </div>
    </div>
</div>
                        <table class="Table">
                          <thead>
                            <tr>
                              <th>No</th>
                              <th>workcenter</th>
                              <th>gedung</th>
                              <th class="hidden-phone">kategori</th>
                              <th class="hidden-phone">Activity</th>
                              <th class="hidden-phone">nama kategori</th>
                            </tr>
                          </thead>
                            <div class="col-md-1 col-sm-1 col-xs-12">
                              <input type="hidden" name="finance" maxlength="45" required="required" value="<?php echo e($fe->id_feasibility); ?>" class="form-control col-md-7 col-xs-12">
                            </div>
                            <?php $__currentLoopData = $mesins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td class="text-center"><?php echo e($mesin->id_data_mesin); ?></td>
                              <td><?php echo e($mesin->workcenter); ?></td>
                              <td><?php echo e($mesin->gedung); ?></td>
                              <td><?php echo e($mesin->Direct_Activity); ?></td>
                              <td><?php echo e($mesin->kategori); ?></td>
                              <td><?php echo e($mesin->nama_kategori); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                  </div>
                </form>
              </div>
              </div>
              </div>
<!-- /page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('finance.tempfinance', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>