<?php $__env->startSection('title', 'Edit SubKategori'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6" id="add">
            <div class="form-panel" >
            <h4><i class="fa fa-edit"></i> Edit SubKategori</h4>
            <form method="POST" action="<?php echo e(route('subkategori.update',$subkategori->id)); ?>">
            <label for="" class="control-label">SubKategori</label>
            <input class="form-control" id="subkategori" name="subkategori" placeholder="SubKategori" value="<?php echo e($subkategori->subkategori); ?>" required />
            <label for="" class="control-label">Pembulatan</label>
            <input type="number" step=any class="form-control" id="pembulatan" name="pembulatan" placeholder="Harga" required value="<?php echo e($subkategori->pembulatan); ?>"/>
            <label for="" class="control-label">Kategori</label>
            <br>
            <select id="kategori" name="kategori" class="form-control" style="width:500px;">
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <option value="<?php echo e($kategori->id); ?>" <?php echo e($subkategori->kategori_id == $kategori->id ? 'selected' : ''); ?>><?php echo e($kategori->kategori); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-edit"></i> Simpan Perubahan</button>
            <a type="button" class="btn btn-danger" id="xx" href="<?php echo e(route('subkategori.index')); ?>"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
$('#kategori').select2();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>