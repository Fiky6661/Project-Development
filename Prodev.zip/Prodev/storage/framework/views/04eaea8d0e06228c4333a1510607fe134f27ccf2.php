<?php $__env->startSection('title', 'Edit DataBrand'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-6" id="add">
        <div class="form-panel" >
        <h4><i class="fa fa-edit"></i> Edit Brand</h4>
        <form method="POST" action="<?php echo e(route('brand.update',$brand->id)); ?>">
        <label for="nama_produk" class="control-label">Brand</label>
        <input class="form-control" id="brand" name=brand placeholder="Brand" value="<?php echo e($brand->brand); ?>" required />
        <?php echo e(csrf_field()); ?>

        <br>
        <br>
        <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
        <a type="button" class="btn btn-danger" id="xx" href="<?php echo e(route('brand.index')); ?>"><i class="fa fa-times"></i> BATAL</a>
        </form>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>