<?php $__env->startSection('title', 'Edit Satuan'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6" id="add">
            <div class="form-panel" >
            <h4><i class="fa fa-edit"></i> Edit Satuan</h4>
            <form method="POST" action="<?php echo e(route('satuan.update', $satuan->id)); ?>">
            <label for="" class="control-label">Satuan</label>
            <input class="form-control" id="satuan" name="satuan" placeholder="Satuan" value="<?php echo e($satuan->satuan); ?>" required />
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="<?php echo e(route('satuan.index')); ?>"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>