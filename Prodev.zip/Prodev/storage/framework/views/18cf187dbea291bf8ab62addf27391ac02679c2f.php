<?php $__env->startSection("content"); ?>
<div class="row">
	<div class="col-md-14">
		<div class="showback">
			<div class="row">
			  <div class="col-md-6"><h4><i class="fa fa-cube"></i> Data Bahan Baku</h4> </div>
			  <div class="col-md-6 text-right"><h5><i class="fa fa-home"></i> Data Bahan Baku</a></h5></div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="showback" style="border-radius:3px;">
			<table class="table table-hover table-bordered" id="Table">
				<thead>
					<tr>
						<th class="text-center" style="width: 5%;">No</th>
						<th class="text-center">Ingredient</th>
						<th class="text-center">parameter</th>
					</tr>
				</thead>
				<?php $__currentLoopData = $tampil1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-center"></td>
					<td class="text-center"></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tfoot>
					<tr>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>