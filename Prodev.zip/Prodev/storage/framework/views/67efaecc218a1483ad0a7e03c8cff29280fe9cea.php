<?php $__env->startSection('title', 'detailuser'); ?>

<?php $__env->startSection('judulnya','Detail User'); ?>

<?php $__env->startSection('content'); ?>
            <div class="row content-panel">
              <div class="col-md-6 profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                  <h4><?php echo e($users->email); ?></h4>
                  <h6>E-mail</h6>
                  <h4><?php echo e($users->username); ?></h4>
                  <h6>Username</h6>
                  <h4><?php echo e($users->departement->dept); ?></h4>
                  <h6>Departement</h6>
                  <h4><?php echo e($users->level); ?></h4>
                  <h6>Level</h6>
                </div>
              </div>
              <!-- /col-md-4 -->
              <div class="col-md-6 profile-text">
                <h3><?php echo e($users->name); ?></h3>
                <h6><?php echo e($users->status); ?></h6>
                <br>
                <p><button class="btn btn-theme"><i class="fa fa-arrow-left"></i><a href="<?php echo e(route('usermanagement.index')); ?>">Kembali</a></button></p>
              </div>
            </div>
            <!-- /row -->
          </div>
          <!-- /col-lg-12 -->
          <div class="col-lg-12 mt">
            <div class="row content-panel">
              <div class="panel-heading">
                <ul class="nav nav-tabs nav-justified">
                  <li class="active">
                    <a data-toggle="tab" href="#akses">Hak Akses</a>
                  </li>
                  <li>
                    <a data-toggle="tab" href="#edit">Edit Profile</a>
                  </li>
                </ul>
              </div>
              <!-- /panel-heading -->
              <div class="panel-body">
                <div class="tab-content">
                  <div id="akses" class="tab-pane active">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="detailed mt">
                          <h4>Hak Akses</h4>
                          <div class="grey-style">
                            
                          </div>
                        </div>
                      </div>
                      <!-- nyebrang -->
                      <div class="col-md-6">
                        <div class="detailed mt">
                          <h4>Rubah Hak Akses</h4>
                          <h5>Akses Admin</h5>
                          <div class="form-group">
                          <div class="checkbox">
                            <label>
                                <input type="checkbox" value="">
                                Approval
                            </label>
                            </br>
                            <label>
                                <input type="checkbox" value="">
                                List User
                            </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /tab-pane -->
                  <div id="edit" class="tab-pane">
                    <div class="row">
                      <div class="col-lg-8 col-lg-offset-2 detailed">
                        <h4 class="mb">Edit User Information</h4>
                        <div class="form">
                <form class="cmxform form-horizontal style-form" method="POST" action="">
                <input class="form-control" id="name" name="name" placeholder="nama" value="<?php echo e(old('name')); ?>" type="text" minlength="2" autofocus required/>
                    <br>
                    <input class="form-control " id="username" name="username" placeholder="username" value="<?php echo e(old('username')); ?>" type="text" minlength="6" maxlength="12" required/>
                    <br>
                    <input class="form-control " id="password" name="password" placeholder="password" type="password" minlength="6" maxlength="12" required/>
                    <br>
                    <input class="form-control " id="password_confirmation" name="password_confirmation" placeholder="confirm_password" type="password" required/>
                    <br>
                    <input class="form-control " id="email" name="email" placeholder="E-mail only @nutrifood.co.id" value="<?php echo e(old('email')); ?>" type="email" required/>
                    <br>
                    <select id="departement" name="departement" class="form-control" >
                    
                    
                   
                    </select>
                    <br>
                    <select class="form-control" id="level" name="level">
                      <option name="admin" value="admin">ADMIN</option>
                      <option name="pv" value="pv">PV</option>
                      <option name="development" value="development">DEVELOPMENT</option>
                      <option name="produksi" value="produksi">PRODUKSI</option>
                      <option name="kemas" value="kemas">KEMAS</option>
                      <option name="inputor" value="inputor" >INPUTOR</option>
                      <option name="superadmin" value="superadmin">SUPER ADMIN</option>
                    </select>

                    <br>
          <button class="btn btn-theme btn-block" type="submit"><i class="fa fa-edit"></i> EDIT</button>
          <?php echo e(csrf_field()); ?>

          <?php echo $__env->make('formerrors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </form>
              </div>
                        
                     </div>
                      <!-- /col-lg-8 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->
                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>
          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>