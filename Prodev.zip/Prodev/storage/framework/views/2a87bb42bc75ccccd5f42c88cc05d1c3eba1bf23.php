<?php $__env->startSection('title', 'Edit Departement'); ?>

<?php $__env->startSection('judulnya',' Edit Departement'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">

<div class="col-md-12">
<div class="col-md-6">
<div class="form-panel" >
        <form method="POST" action="<?php echo e(route('storeupdatedept',$dept->id)); ?>">
        <label for="nama_produk" class="control-label">Departement</label>
        <input class="form-control" id="dept" name="dept" value="<?php echo e($dept->dept); ?>" required />
        <label for="nama_produk" class="control-label">Keterangan</label>
        <input class="form-control" id="nama_dept" name="nama_dept" value="<?php echo e($dept->nama_dept); ?>" required />
        <label for="nama_produk" class="control-label">Manager</label>
            <select id="manager" name="manager" class="form-control">
            <option selected disabled>Pilih User Sebagai Manager<option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <option value="<?php echo e($user->id); ?>" <?php echo e(( $user->id == $dept->manager_id ) ? ' selected' : ''); ?>><?php echo e($user->role->namaRule); ?> - <?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <br>
        <br>
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PATCH')); ?>

        <button class="btn btn-primary" type="submit"><i class="fa fa-edit"></i> Simpan Perubahan</button>
        <a type="button" class="btn btn-danger" href="<?php echo e(route('dept')); ?>"><i class="fa fa-times"></i> BATAL</a>
        </form>
        </div>
</div>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
$('#manager').select2();
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>