<?php $__env->startSection('title','Feasibility|Inputor'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="form-panel">

      <div id="RM" class="tab-pane">
              <div class="row">
                <div class="col-lg-12 detailed">
                  <h4 class="mb">Runtime Mesin</h4>
                    <table class="table table-hover table-bordered">
                    <thead>
                      <tr>
                        <th class="text-center">mesin</th>
                        <th class="text-center">Standar SDM</th>
                        <th class="text-center">Runtime</th>
                        <th class="text-center">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $Mdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(url('/updatemss')); ?>/<?php echo e($dM->id_mesin); ?>" method="post">
                      <?php echo csrf_field(); ?>

                      <tr>
                        <td><?php echo e($dM->meesin->Direct_Activity); ?></td>
                        <td class="text-center">10 Orang</td>
                        <?php if($dM->runtime==NULL): ?>
                        <td><input id="runtime" name="runtime" class="date-picker form-control col-md-7 col-xs-12" type="text" required></td> 
                        <td><button type="submit" class="btn btn-primary">Submit</button></td>
                        <?php else: ?>
                        <td class="text-center"><?php echo e($dM->runtime); ?> Menit</td>
                        <td class="text-center"><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal<?php echo e($dM->id_mesin); ?>" ">Edit</button>
                  <div class="modal fade" id="exampleModal<?php echo e($dM->id_mesin); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content text-left ">
                        <div class="modal-header">
                          <h3 class="modal-title" id="exampleModalLabel">Edit Data
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button><h3>
                        </div>
                        <div class="modal-body">
                        <form >
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Runtime Mesin:</label>
                <input id="runtime" value="<?php echo e($dM->runtime); ?>" name="runtime" class="date-picker form-control" type="text">
              </div></div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
                        </div>
                      </div>
                    </div>
                  </div>
                  <a href="<?php echo e(route('mesin.destroy', $dM->id_mesin)); ?>" class="btn btn-danger btn-sm">Hapus</a>
                      </td>
                    <?php endif; ?>
                    </tr>
                      </form>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mesin.tempmesin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>