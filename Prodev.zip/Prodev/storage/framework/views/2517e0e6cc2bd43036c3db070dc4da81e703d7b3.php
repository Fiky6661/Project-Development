<?php $__env->startSection('title', 'Data Brand'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
            <?php if(session('status')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('status')); ?>

            </div>
            </div>
            <?php elseif(session('error')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('error')); ?>

            </div>
            </div>
            <?php endif; ?>
</div>

<!-- BRAND -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <h4><i class="fa fa-angle-double-right"></i>List Brand</h4>
        <div class="form-panel">
        <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Brand</a>
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Brand</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($brand->id); ?></td>
                            <td><?php echo e($brand->brand); ?></td>
                            <td><?php echo e($brand->created_at); ?></td>
                            <td><?php echo e($brand->updated_at); ?></td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(route('brand.edit',$brand->id)); ?>" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"> Edit</i></a>
                                <a class="btn btn-danger" onclick="return confirm('Hapus Bahan Baku ?')" href="<?php echo e(route('brand.destroy',$brand->id)); ?>"><i class="fa fa-trash-o"></i> Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
    </div>
    
</div>

<div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
        <div class="form-panel" >
        <h4><i class="fa fa-plus"></i> Tambah Brand</h4>
        <form method="POST" action="<?php echo e(route('brand.store')); ?>">
        <label for="nama_produk" class="control-label">Brand</label>
        <input class="form-control" id="brand" name=brand placeholder="Brand" required />
        <?php echo e(csrf_field()); ?>

        <br>
        <br>
        <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
        <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
        </form>
        </div>
</div>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>