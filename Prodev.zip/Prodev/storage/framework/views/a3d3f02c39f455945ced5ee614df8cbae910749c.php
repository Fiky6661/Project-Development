<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3>Edit Parameter</h3>
				</div>
				<div class="panel-body">
					<form action="<?php echo e(('')); ?>" method="post" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<?php $__currentLoopData = $edit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="form-group">
							<input type="text" name="parameter" placeholder="Parameter" class="form-control" value="<?php echo e($data->parameter); ?>">
						</div>
						<div class="form-group">
							<select class="form-control" name="kategori">
								<option value="<?php echo e($data->id_kategori); ?>"><?php echo e($data->get_kategori->kategori); ?></option>
							</select>
						</div>
						<div class="form-group">
							<select name="akg" class="form-control">
								<option disabled selected>AKG</option>
								<?php $__currentLoopData = $akg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($field->id_akg); ?>" selected><?php echo e($field->zat_gizi); ?></option>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="form-group">
							<input type="text" name="satuan" class="form-control" placeholder="Satuan" value="<?php echo e($data->satuan); ?>">
						</div>
						<div class="form-group">
							<input type="text" name="keterangan" class="form-control" placeholder="Keterangan" value="<?php echo e($data->keterangan); ?>">
						</div>
						<button class="btn btn-warning" type="submit">Update</button>
						<a href="<?php echo e(url('datap')); ?>" class="btn btn-danger" type="submit">Batal</a>	
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>