<!DOCTYPE html>
<html lang="en">

<head>
  <title>PRODEV - <?php echo $__env->yieldContent('title'); ?></title>

<link href="<?php echo e(asset('img/favicon.ico')); ?>" rel="icon">
<link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/advanced-datatable/css/jquery.dataTables.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('lib/advanced-datatable/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('lib/advanced-datatable/css/dataTables.bootstrap.css')); ?>" />
<link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
<link href="<?php echo e(asset('css/dataTables.min.css')); ?>">
<link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('css/custom.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
<!-- Custom Sheila -->
<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"> 
<link href="<?php echo e(asset('css/sheila.css')); ?>" rel="stylesheet"> 

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        </div>
      </div>
      <!--logo start-->
      <a href="#" class="logo"><img src="<?php echo e(asset('img/pro.png')); ?>"><b>PROD<span>EV</span></b></a>
      <!--logo end-->

      <div class="top-menu">
        <br>
        <ul class="nav pull-right top-menu">
        <?php if( auth()->check() ): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('MyProfile')); ?>"><i class="fa fa-user"></i> Hello,<?php echo e(Auth::user()->name); ?></a></li>
        <?php endif; ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('myworkbooks')); ?>"><i class="fa fa-book"></i> Workbook</a></li>
        <li><a class="btn btn-lg" href=""><i class="fa fa-bar-chart-o"></i> Nutfact</a></li>
        <li><a class="btn btn-lg" href="<?php echo e(route('signout')); ?>"><i class="fa fa-sign-out"></i> Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->    
      <section class="wrapper site-min-height">
      <div class="row" >
      <div class="col-md-14">
      <div class="showback">
      <div class="row">
        <div class="col-md-10"><h4><i class="fa fa-book"></i> <?php echo $__env->yieldContent('judulnya'); ?></h4> </div>
        <div class="col-md-2"><h4><i class="fa fa-user"></i> <?php echo e(Auth::user()->role->namaRule); ?></h4> </div>
      </div>
    </div>
  </div>
</div>
        <div class="row mt">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
      </section>
    <!--main content end-->
      
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>2018</strong>. All Rights Reserved
        </p>
        <div class="credits">
          Created with Love
        </div>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
   <!-- sheila script -->
  <script src="<?php echo e(asset('js/sheila.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
  <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.dataTables.js')); ?>"></script>
  <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/dataTables.bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery-ui-1.9.2.custom.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery-ui-1.9.2.custom.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.ui.touch-punch.min.js')); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
	<script src="<?php echo e(asset('lib/bootstrap/bootstrap.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/dataTables.bootstrap4.min.css')); ?>"></script>
  <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>

  <?php echo $__env->yieldContent('s'); ?>

  <script type="text/javascript">$('#Table').DataTable({
      "language": {
        "search": "Cari :",
        "lengthMenu": "Tampilkan _MENU_ data",
        "zeroRecords": "Tidak ada data",
        "emptyTable": "Tidak ada data",
        "info": "Menampilkan data _START_  - _END_  dari _TOTAL_ data",
        "infoEmpty": "Tidak ada data",
        "paginate": {
          "first": "Awal",
          "last": "Akhir",
          "next": ">",
          "previous": "<"
        }
      }
    });</script>



</body>

</html>
