<?php $__env->startSection('title', 'Edit Formula'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<section>
        <div class="wizard">
            <div class="wizard-inner">
                <div class="connecting-line"></div>
                <ul class="nav nav-tabs" role="tablist">

                    <li role="presentation" class="active">
                        <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="FORMULA INFORMATION">
                            <span class="round-tab">
                                <i class="fa fa-pencil"></i>
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="BAHAN BAKU">
                            <span class="round-tab">
                                <i class="fa fa-tasks"></i>
                            </span>
                        </a>
                    </li>
                    <li role="presentation" class="disabled">
                        <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="PREMIX">
                            <span class="round-tab">
                                <i class="fa fa-cog"></i>
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#complete" data-toggle="tab" aria-controls="complete" role="tab" title="Complete">
                            <span class="round-tab">
                                <i class="fa fa-magic"></i>
                            </span>
                        </a>
                    </li>
                </ul>
            </div>

            <form role="form">
                <div class="tab-content">
                    <div class="tab-pane active" role="tabpanel" id="step1">

                    <div class="row">
                    <div class="col-md-6">
                        
                        <div class="form-panel">
                        <h3>INFORMASI FORMULA</h3>
                        <form class="form-login" method="POST" action="">


                        <label for="jenis" class="control-label">Jenis Formula</label>
                        <div class="row">
                            <div class="col-md-6">
                                <select class="form-control" id="jenis" name="jenis">
                                <option id="baru" value="baru">Baru</option>
                                <option id="rev" value="revisi">Revisi</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#temp">Pilih Template</button>
                            </div>
                        </div>

                        <label for="nama_produk" class="control-label">Nama Produk</label>
                        <input class="form-control" id="nama_produk" name="nama_produk" minlength="2" type="text" required />
                    
                        <div class="row">
                            <div class="col-md-4">
                                <label for="revisi" class="control-label">Revisi</label>
                                <input class="form-control" id="revisi" name="revisi" type="text" value="AA" disabled />
                            </div>
                            <div class="col-md-4">
                                <label for="versi" class="control-label">Versi</label>
                                <input class="form-control" id="versi" name="versi" type="text" disabled />
                            </div>
                            <div class="col-md-4">
                                <label for="kode_formula" class="control-label">Kode Formula</label>
                                <input class="form-control" id="kode_formula" name="kode_formula" type="text" required />  
                            </div>
                        </div>  

                        <div class="row">
                            <div class="col-md-6">
                                <label for="" class="control-label">Brand</label>
                                <select class="form-control" id="produksi" name="produksi">
                                
                                <option>subbrand</option>
                                
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="" class="control-label">Gudang</label>
                                    <select class="form-control" id="gudang" name="gudang">
                                    
                                    <option>gudang</option>
                                    
                                    </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="" class="control-label">Produksi</label>
                                <select class="form-control" id="produksi" name="produksi">
                                <option>Produksi</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="" class="control-label">Maklon</label>
                                    <select class="form-control" id="maklon" name="maklon">
                                    <option>Maklon</option>
                                    </select>
                            </div>
                        </div>

                    </div>
                    </div>
                    
                <!-- Nyebrang -->
                <div class="col-md-6">
                    <div class="form-panel">

                        <label for="revisi" class="control-label">Main Item</label>
                        <input class="form-control" id="main_item" name="main_item" type="text" required />

                        <label for="revisi" class="control-label">Main Item Eks</label>
                        <input class="form-control" id="main_item_eks" name="main_item_eks" type="text" required />

                        <div class="row">
                            <div class="col-md-6">
                                <label for="bj" class="control-label">Berat Jenis</label>
                                <input class="form-control" id="bj" name="bj" type="text" required />
                            </div>
                            <div class="col-md-6">
                                <label for="batch" class="control-label">Batch</label>
                                <input class="form-control" id="batch" name="batch" type="text" required />
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="serving" class="control-label">Serving</label>
                                <input class="form-control" id="serving" name="serving" type="text" required />
                            </div>
                            <div class="col-md-6">
                                <label for="liter" class="control-label">Liter</label>
                                <input class="form-control" id="liter" name="liter" type="text" required />
                            </div>
                        </div>

                        <br>
                        <button type="button" class="btn btn-primary next-step">Save and continue</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!--------------------------------------------------------------------------------------->
        <div class="tab-pane" role="tabpanel" id="step2">
                        
            <div class="row">
                    <div class="col-md-12">
                        
                        <div class="form-panel">
                        <h3>BAHAN BAKU</h3>
                        
                        <form name="add_name" id="add_name">
                        <table class="table table-striped table-advance table-hover" id="dynamic_field">
                        <tr>
                        <th>No</th>

                        <th>Kode Komputer</th>

                        <th>Nama Sederhana</th>

                        <th>Kode Oracle</th>

                        <th>Prioritas</th>

                        <th>Per Saving</th>

                        <th>Nama Bahan</th>

                        <th>Per Batch</th>

                        <th>Alternatif</th>

                        <th>Tambah Bahan Baku</th>

                        </tr>
                        <tr>
                        <td>1</td>
                        <td><input type="text" name="kk[]" placeholder="Kode_Komputer" class="form-control" /></td>
                        <td><input type="text" name="ns[]" placeholder="Nama_Sederhana" class="form-control" /></td>
                        <td><input type="text" name="ko[]" placeholder="Kode_Oracle" class="form-control" /></td>
                        <td><input type="text" name="pri[]" placeholder="Prioritas" class="form-control" /></td>
                        <td><input type="text" name="ps[]" placeholder="per_saving" class="form-control" /></td>
                        <td><input type="text" name="nb[]" placeholder="Nama_bahan" class="form-control" /></td>
                        <td><input type="text" name="pb[]" placeholder="per_batch" class="form-control" /></td>
                        <td><input type="text" name="alt[]" placeholder="Alternatif" class="form-control" /></td>
                          
                        <td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>  
                        </tr>
                    </table>

                            <button type="button" class="btn btn-default prev-step">Previous</button>
                            <button type="button" class="btn btn-primary next-step">Save and continue</button>

                            </form>
                
                        </div>
                    </div>
            </div>
        </div>

        <!--------------------------------------------------------------------------------------->
        <div class="tab-pane" role="tabpanel" id="step3">
                        
                        <div class="row">
                            <div class="col-md-12">
                        
                            <div class="form-panel">
                            <h3>PREMIX</h3>

                        <form name="add_name" id="add_name">
                        <table class="table table-striped table-advance table-hover" id="dynamic_field">
                        <tr>
                        <th rowspan="2">No</th>
                        <th rowspan="2">Nama Sederhana</th>
                        <th rowspan="2">Per Saving</th>
                        <th rowspan="2">Per Batch</th>
                        <th colspan="4">Premix</th>
                        </tr>

                        <tr>
                        <th>ke-1</th>
                        <th>ke-2</th>
                        <th>ke-3</th>
                        <th>ke-4</th>
                        </tr>

                        <td>1</td>
                        <td><input type="text" name="ns[]" placeholder="Nama_Sederhana" class="form-control" /></td>
                        <td><input type="text" name="ps[]" placeholder="per_saving" class="form-control" /></td>
                        <td><input type="text" name="pb[]" placeholder="per_batch" class="form-control" /></td>
                        <td><input type="text" name="ns[]" placeholder="1" class="form-control" /></td>
                        <td><input type="text" name="ps[]" placeholder="2" class="form-control" /></td>
                        <td><input type="text" name="pb[]" placeholder="3" class="form-control" /></td>
                        <td><input type="text" name="pb[]" placeholder="4" class="form-control" /></td>
                          
                        </tr>
                    </table>

                            <button type="button" class="btn btn-default prev-step">Previous</button>
                            <button type="button" class="btn btn-primary next-step">Save and continue</button>

                            </form>
                        </div>
                    </div>
            </div>
        </div>

        <!--------------------------------------------------------------------------------------->
        <div class="tab-pane" role="tabpanel" id="complete">
                        <div class="row">
                            <div class="col-md-12">
                        
                            <div class="form-panel">
                            <h3>SELESAI</h3>


                        
                            <button type="button" class="btn btn-default prev-step">Previous</button>
                            <button type="button" class="btn btn-primary next-step">Save and continue</button>
                
                        </div>
                    </div>
            </div>  
        </div>
        <!--------------------------------------------------------------------------------------->
                </div>
            </form>
        </div>
    </section>
   </div>
</div>

<div class="modal fade" id="temp" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">PILIH TEMPLATE</h4>
                    </div>
                    <div class="modal-body">
                    <label for="" class="control-label">Departement</label>
                        <select id="departement" name="departement" class="form-control" >
                        <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dept->id_dept); ?>"><?php echo e($dept->dept); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <label for="" class="control-label">User</label>
                        <select id="usetemp" name="usetemp" class="form-control" >
                        <option value="1">Sheila</option>
                        <option value="2">Snowy</option>
                        </select>
                    <label for="" class="control-label">Workbook</label>
                        <select id="usetemp" name="usetemp" class="form-control" >
                        <option value="1">HILO COKLAT</option>
                        <option value="2">HILO NANAS</option>
                        </select>
                    <label for="" class="control-label">Versi Formula</label>
                        <select id="usetemp" name="usetemp" class="form-control" >
                        <option value="1">Versi 1 HILO NANAS MANIS</option>
                        <option value="2">Versi 2 HILO NANAS SEGAR</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary">Masukan Template</button>
                    </div>
                  </div>
                </div>
              </div>

<script src="js/formula/bb.js"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('devwb.tempwb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>