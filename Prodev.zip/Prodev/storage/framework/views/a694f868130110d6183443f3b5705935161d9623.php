<!DOCTYPE html>
<html lang="en">

<head>
  <title>PRODEV - My Profile</title>

  <link href="<?php echo e(asset('img/pro.png')); ?>" rel="icon">
<link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
<link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/advanced-datatable/css/jquery.dataTables.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('lib/advanced-datatable/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('lib/advanced-datatable/css/dataTables.bootstrap.css')); ?>" />
<link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
<link href="<?php echo e(asset('css/dataTables.min.css')); ?>">
<link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('css/custom.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
  

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        </div>
      </div>
      <!--logo start-->
      <a href="#" class="logo"><img src="<?php echo e(asset('img/pro.png')); ?>"><b>PROD<span>EV</span></b></a>
      <!--logo end-->

      <div class="top-menu">
        <br>
        <ul class="nav pull-right top-menu">
        <?php if( auth()->check() ): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('MyProfile')); ?>"><i class="fa fa-user"></i> Hello,<?php echo e(Auth::user()->name); ?></a></li>
        <?php endif; ?>

        <?php if(auth()->user()->role->namaRule === 'admin'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('usermanagement')); ?>"><i class="fa fa-group"></i>List User</a></li>
        <?php elseif(auth()->user()->role->namaRule === 'pv'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('approvedformula')); ?>"><i class="fa fa-book"></i>Formula List</a></li>
        <?php elseif(auth()->user()->role->namaRule === 'development'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('myworkbooks')); ?>"><i class="fa fa-book"></i> Workbook</a></li>
        <li><a class="btn btn-lg" href=""><i class="fa fa-bar-chart-o"></i> Nutfact</a></li>
        <?php elseif(auth()->user()->role->namaRule === 'kemas'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('list-kemas')); ?>"><i class="fa fa-clipboard"></i> List Pengajuan</a></li>
        <?php elseif(auth()->user()->role->namaRule === 'evaluator'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('list-inputor')); ?>"><i class="fa fa-clipboard"></i> List Pengajuan</a></li>
        <?php elseif(auth()->user()->role->namaRule === 'produksi'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('list-produksi')); ?>"><i class="fa fa-clipboard"></i> List Pengajuan</a></li>
        <?php elseif(auth()->user()->role->namaRule === 'lab'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('list-lab')); ?>"><i class="fa fa-clipboard"></i> List Pengajuan</a></li>
        <?php elseif(auth()->user()->role->namaRule === 'finance'): ?>
        <li><a class="btn btn-lg" href="<?php echo e(route('list-finance')); ?>"><i class="fa fa-clipboard"></i> List Pengajuan</a></li>
        <?php endif; ?>

        <li><a class="btn btn-lg" href="<?php echo e(route('signout')); ?>"><i class="fa fa-sign-out"></i> Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
      <section class="wrapper site-min-height">
      <?php if(session('status')): ?>
<div class="col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('status')); ?>

        </div>
</div>
<?php endif; ?>
  <div class="col-lg-12 mt">
    <div class="row content-panel">
      <!-- /panel-heading -->
      <div class="panel-body">
        <div class="tab-content">
          <div id="overview" class="tab-pane active">
            <div class="row">
              <div class="col-md-5 profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                  <h3><?php echo e($users->name); ?></h3>
                  <p>Last update : <?php echo e($users->updated_at); ?></p>
                    <div class="profile-pic">
                      <p><img src="<?php echo e(asset('img/proo.png')); ?>" class="img-circle"></p>
                      <p><button class="btn btn-theme"><i class="fa fa-check"></i><?php echo e($users->status); ?></button></p>
                    </div>
                </div>
                <div class="right-divider hidden-sm hidden-xs">
                  <h4><?php echo e($users->email); ?></h4>
                  <p>E-mail</p>
                  <h4><?php echo e($users->username); ?></h4>
                  <p>Username</p>
                  <h4><?php echo e($users->departement->dept); ?></h4>
                  <p>Departement</p>
                  <h4><?php echo e($users->role->namaRule); ?></h4>
                  <p>Level</p>
                </div>
              </div>
              <!-- /col-md-4 -->
              <div class="col-md-7 centered">
                <div class="row">
                  <div class="col-lg-8 col-lg-offset-2 detailed">
                    <h4 class="mb">Edit Your Profile</h4>
                      <div class="form">
                        <form class="cmxform form-horizontal style-form" method="POST" action="<?php echo e(route('updateprof')); ?>">
                          <br>
                          <input class="form-control" id="name" name="name" placeholder="nama" value="<?php echo e($users->name); ?>" type="text" minlength="2" autofocus required/>
                          <br>
                          <input class="form-control" id="username" name="username" placeholder="username" value="<?php echo e($users->username); ?>" type="text" minlength="6" maxlength="12" required/>
                          <br>
                          <input class="form-control" id="password" name="password" placeholder="password" type="password" minlength="6" maxlength="12" required/>
                          <br>
                          <input class="form-control" id="password_confirmation" name="password_confirmation" placeholder="confirm_password" type="password" required/>
                          <br>
                          <input class="form-control" id="email" name="email" placeholder="E-mail" value="<?php echo e($users->email); ?>" type="email" required/>
                          <br>
                          <button class="btn btn-theme btn-block" type="submit"><i class="fa fa-edit"></i> Simpan Perubahan</button>
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo $__env->make('formerrors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </form>
                      </div>   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>2018</strong>. All Rights Reserved
        </p>
        <div class="credits">
          Created with Love
        </div>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
   <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
  <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.dataTables.js')); ?>"></script>
  <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/dataTables.bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery-ui-1.9.2.custom.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery-ui-1.9.2.custom.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.ui.touch-punch.min.js')); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
	<script src="<?php echo e(asset('lib/bootstrap/bootstrap.min.js')); ?>" type="text/javascript"></script>