<?php $__env->startSection('title', 'Data SubBrand'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
            <?php if(session('status')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('status')); ?>

            </div>
            </div>
            <?php elseif(session('error')): ?>
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('error')); ?>

            </div>
            </div>
            <?php endif; ?>
</div>

<!-- Subbrand -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
    <h4><i class="fa fa-angle-double-right"></i>List SubBrand</h4>
    <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Subbrand</a>
        <div class="form-panel">
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Subbrand</th>
                            <th>Brand</th>
                            <th>Manager</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $subbrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subbrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($subbrand->id); ?></td>
                            <td><?php echo e($subbrand->subbrand); ?></td>
                            <td><?php echo e($subbrand->brand->brand); ?></td>
                            <td><?php echo e($subbrand->user->name); ?></td>
                            <td>
                                <?php echo Form::open(['method' => 'Delete', 'route' => ['subbrand.destroy', $subbrand->id]]); ?>

                                <a class="btn btn-primary" href="<?php echo e(route('subbrand.edit',$subbrand->id)); ?>" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <button class="btn btn-danger" onclick="return confirm('Hapus Subbrand ?')"><i class="fa fa-trash-o"></i> Delete</button>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
            <div class="form-panel" >
            <h4><i class="fa fa-plus"></i> Tambah Subbrand</h4>
            <form method="POST" action="<?php echo e(route('subbrand.store')); ?>">
            <label for="" class="control-label">Subbrand</label>
            <input class="form-control" id="subbrand" name="subbrand" placeholder="Subbrand" value="<?php echo e(old('subbrand')); ?>" required />
            <br>
            <label for="" class="control-label">Brand</label>
            <br>
            <select id="brand" name="brand" class="form-control" style="width:500px;">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($brand->id); ?>" <?php echo e(old('brand_id') == $brand->id ? 'selected' : ''); ?>><?php echo e($brand->brand); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <label for="" class="control-label">Manager</label>
            <br>
                <select id="manager" name="manager" class="form-control" style="width:500px;">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('manager') == $user->id ? 'selected' : ''); ?>><?php echo e($user->role->namaRule); ?> - <?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <br>
            <br>
            <?php echo e(csrf_field()); ?>

            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('s'); ?>
<script type="text/javascript">
$('#manager').select2({
    placeholder: "Pilih User Sebagai Manager",
    allowClear: true
});
$('#brand').select2({
    placeholder: "Pilih Brand",
    allowClear: true
});
$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>