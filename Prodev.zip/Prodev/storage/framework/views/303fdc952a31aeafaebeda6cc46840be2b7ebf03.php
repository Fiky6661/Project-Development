<?php $__env->startSection('title', 'Approval Formula'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt">
          <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="showback">
                <h4>FORMULA YANG SEDANG DIPROSES</h4>
                <table class="table table-striped table-advance table-hover" id="Table">

                <tr>

                <th>ID</th>
                <th>User</th>
                <th>Departement</th>
                <th>Kode Formula</th>
                <th>Nama Produk</th>
                <th>Revisi</th>
                <th>Versi</th>
                <th>PV</th>
                <th>Action</th>

                </tr>

              <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>

              <td><?php echo e($formula->id); ?></td>
              <td><?php echo e($formula->workbook->user->name); ?></td>
              <td><?php echo e($formula->workbook->user->departement->dept); ?></td>
              <td><?php echo e($formula->kode_formula); ?></td>
              <td><?php echo e($formula->nama_produk); ?></td>
              <td><?php echo e($formula->revisi); ?></td>
              <td><?php echo e($formula->versi); ?></td>
              <td><?php echo e($formula->vv); ?></td>

              <td>

              <?php echo e(csrf_field()); ?>

              <a class="btn btn-primary" href="">Lihat</a>
              <a class="btn btn-info" href="<?php echo e(route('approveformula',$formula->id)); ?>">Approve</a>
              <a class="btn btn-warning" href="<?php echo e(route('rejectformula',$formula->id)); ?>">Reject</a>
              </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </table>

              </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('pv.tempvv', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>