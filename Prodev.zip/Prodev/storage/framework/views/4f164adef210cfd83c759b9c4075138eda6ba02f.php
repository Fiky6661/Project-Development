<?php $__env->startSection('title', 'Approved Formula'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt">
          <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="showback">
                <h4>FORMULA YANG SUDAH DI APPROVE</h4>
                <table class="table table-striped table-advance table-hover">

                <tr>

                <th>ID</th>
                <th>User</th>
                <th>Kode Formula</th>
                <th>Nama Produk</th>
                <th>Revisi</th>
                <th>Versi</th>
                <th>PV</th>
                <th>Feasibility</th>
                <th>Nutfact</th>
                <th>Status</th>
                <th>Action</th>

                </tr>

              <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($formula->vv !='proses'): ?>

              <tr>

              <td><?php echo e($formula->id); ?></td>
              <td><?php echo e($formula->workbook_id); ?></td>
              <td><?php echo e($formula->kode_formula); ?></td>
              <td><?php echo e($formula->nama_produk); ?></td>
              <td><?php echo e($formula->revisi); ?></td>
              <td><?php echo e($formula->versi); ?></td>
              <td><?php echo e($formula->vv); ?></td>
              <td><?php echo e($formula->status_fisibility); ?></td>
              <td><?php echo e($formula->status_nutfact); ?></td>
              <td><?php echo e($formula->status); ?></td>

              <td>

              <?php echo e(csrf_field()); ?>

              <a class="btn btn-info" href="<?php echo e(route('approvedformula.show',$formula->id)); ?>">Show</a>
              <a class="btn btn-warning" href="<?php echo e(route('approvedformula.edit',$formula->id)); ?>">Reject</a>
              </td>

              </tr>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </table>

              </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pv.tempvv', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>