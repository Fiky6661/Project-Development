<?php $__env->startSection('content'); ?>
<div  class="row">
  <div class="col-md-14">
    <div class="showback">
      <div class="row">
        <div class="col-md-6"><h4><i class="fa fa-search"></i> Pencarian Data Cemaran</h4> </div>
        <div class="col-md-6 text-right"><h5><i class="fa fa-home"></i> / <a href="<?php echo e(url('/pencariandatacemaran')); ?>">Pencemaran Data Cemaran</a></h5></div>
      </div>
    </div>
  </div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="showback" style="border-radius:3px;">
			<a href="<?php echo e(url('/datac')); ?>" class="btn btn-danger"><i class="fa fa-arrow-left"> Kembali</i></a><br><br>
			<table class="js-dynamitable table table-bordered table-hover" id="Table">
				<thead>
					<tr>
		                <th class="text-center" style="width: 7%;">No
		                    <span class="js-sorter-desc glyphicon glyphicon-chevron-down pull-right"></span>
		                    <span class="js-sorter-asc  glyphicon glyphicon-chevron-up pull-right"></span>
		                 </th>
		                <th class="text-center">Jenis Cemaran
		                    <span class="js-sorter-desc glyphicon glyphicon-chevron-down pull-right"></span>
		                    <span class="js-sorter-asc  glyphicon glyphicon-chevron-up pull-right"></span>
		                 </th>
		                <th class="text-center">Cemaran
		                    <span class="js-sorter-desc glyphicon glyphicon-chevron-down pull-right"></span>
		                    <span class="js-sorter-asc  glyphicon glyphicon-chevron-up pull-right"></span>
		                 </th>
		                <th class="text-center">Jenis Makanan
		                    <span class="js-sorter-desc glyphicon glyphicon-chevron-down pull-right"></span>
		                    <span class="js-sorter-asc  glyphicon glyphicon-chevron-up pull-right"></span>
		                </th>
		                <th class="text-center">Batas Maksimum
		                    <span class="js-sorter-desc glyphicon glyphicon-chevron-down pull-right"></span>
		                    <span class="js-sorter-asc  glyphicon glyphicon-chevron-up pull-right"></span>
		                </th>
		            </tr>
		            <tr>
		                <th>
		                    <input  class="js-filter  form-control" type="text" value="">
		                </th>
		                <th>
		                    <select class="js-filter  form-control">
		                        <option value="">Semua</option>
		                        <?php $__currentLoopData = $tampil2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        <option value="<?php echo e($data->cemaran); ?>"><?php echo e($data->cemaran); ?></option>
		                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    </select>
		                </th>
		                <th>
		                	<select class="js-filter  form-control">
		                        <option value="">Semua</option>
		                        <?php $__currentLoopData = $tampil1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        <option value="<?php echo e($data->parameter); ?>"><?php echo e($c->parameter); ?></option>
		                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    </select>
		                </th>
		                <th><input class="js-filter  form-control" type="text" value=""></th>
		                <th><input class="js-filter  form-control" type="text" value=""></th>
		            </tr>
				</thead>
				<?php $__currentLoopData = $tampilkan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tbody>
					<td class="text-center"><?php echo e($loop->iteration); ?></td>
					<td class="text-center"><?php echo e($datas->jenis->cemaran); ?></td>
					<td class="text-center"><?php echo e($datas->para->parameter); ?></td>
					<td class="text-center"><?php echo e($datas->makanan->jenis_makanan); ?></td>
					<td class="text-center"><?php echo e($datas->makanan->batas_max); ?></td>
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
</div>
<script src="asset/lib/jquery-1.11.3.min.js"></script>
<script src="asset/lib/dynamitable.jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.tempadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>