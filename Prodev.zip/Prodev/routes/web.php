 <?php

Route::get('/', function () {
    return redirect('/home');
});

Route::get('/home', function () {
    return view('Welcome');
});

Route::get('/pageAksesKhusus', function(){
    return view('pageAksesKhusus');
});

Route::get('/MyProfile','users\ProfilController@show')->name('MyProfile');
Route::patch('/updateprof','users\ProfilController@update')->name('updateprof');
/** Auth */

Route::get('daftar', 'users\RegistrationController@create');
Route::post('add', [
    'uses'=> 'users\RegistrationController@registrationPost',
    'as' => 'add']);
 
Route::get('signin', 'LoginController@getLogin')->name('signin');
Route::post('postLogin', 'LoginController@postLogin')->name('postLogin');
Route::get('signout', function(){
    Auth::logout();
    return redirect('/home');
})->name('signout');


/****** ADMIN**/

/*User Approval*/
Route::get('/userapproval', 'admin\ApprovalController@index')->name('userapproval');
Route::get('userapproval/{id}/update', [
    'uses'=>'admin\ApprovalController@update',
    'as' =>'ua.update']);
Route::get('userapproval/{id}/destroy', [
    'uses'=>'admin\ApprovalController@destroy',
    'as' =>'ua.destroy']);

/*User Management*/
Route::get('usermanagement','admin\UserListController@index')->name('usermanagement');
Route::get('showuser/{id}','admin\UserListController@show')->name('showuser');
Route::get('userblok/{id}','admin\UserListController@blok')->name('userblok');
Route::get('openblok/{id}','admin\UserListController@open')->name('openblok');
Route::patch('userupdate/{id}','admin\UserListController@update')->name('userupdate');

/*Data Master*/
Route::get('DataDepartement','datamaster\DepartementController@dept')->name('dept');
Route::get('DeleteDepartement/{id}','datamaster\DepartementController@deldept')->name('deldept');
Route::post('AddDepartement','datamaster\DepartementController@adddept')->name('adddept');
Route::get('UpdateDepartement/{id}','datamaster\DepartementController@formupdatedept')->name('updatedept');
Route::patch('storeupdatedept/{id}','datamaster\DepartementController@saveupdateDept')->name('storeupdatedept');

Route::get('DataBahanBaku','datamaster\BahanBakuController@bahan')->name('bahanbaku');
Route::get('DeleteBahanBaku/{id}','datamaster\BahanBakuController@delbahan')->name('delbahan');
Route::get('ActiveBahan/{id}', 'datamaster\BahanBakuController@active')->name('activebahan');
Route::get('NonActiveBahan/{id}','datamaster\BahanBakuController@nonactive')->name('nonactivebahan');
Route::post('AddBahanBaku','datamaster\BahanBakuController@addbahan')->name('addbahan');
Route::get('UpdateBahanBaku/{id}','datamaster\BahanBakuController@formupdatebahan')->name('updatebahan');
Route::patch('storeupdateBahanBaku/{id}','datamaster\BahanBakuController@saveupdateBahan')->name('storeupdatebahan');

Route::get('brand', 'datamaster\BrandController@index')->name('brand.index');
Route::post('brand/store','datamaster\BrandController@store')->name('brand.store');
Route::get('brand/{id}/edit', 'datamaster\BrandController@edit')->name('brand.edit');
Route::post('brand/{id}/update', 'datamaster\BrandController@update')->name('brand.update');
Route::get('brand/{id}/destroy', 'datamaster\BrandController@destroy')->name('brand.destroy');

Route::resource('subbrand', 'datamaster\SubbrandController',['except' => [ 'show','create' ]]);
Route::resource('curren', 'datamaster\CurrensController',['except' => [ 'show','create' ]]);
Route::resource('satuan', 'datamaster\SatuanController',['except' => [ 'show','create' ]]);
Route::resource('gudang', 'datamaster\GudangController',['except' => [ 'show','create' ]]);
Route::resource('maklon', 'datamaster\MaklonController',['except' => [ 'show','create' ]]);
Route::resource('produksi', 'datamaster\ProduksiController',['except' => [ 'show','create' ]]);
Route::resource('kategori', 'datamaster\KategoriController',['except' => [ 'show','create' ]]);
Route::resource('subkategori', 'datamaster\SubkategoriController',['except' => [ 'show','create' ]]);
Route::resource('kelompok', 'datamaster\KelompokController',['except' => [ 'show','create' ]]);
Route::resource('tarkon', 'datamaster\TarkonController',['except' => [ 'show','create' ]]);

/***** PV */

Route::get('approvalformula','pv\FormulaApprovalController@listapproval')->name('approvalformula');
Route::get('approvedformula','pv\FormulaApprovalController@listapproved')->name('approvedformula');
Route::get('approveformula/{id}','pv\FormulaApprovalController@approve')->name('approveformula');
Route::get('rejectformula/{id}','pv\FormulaApprovalController@reject')->name('rejectformula');


/***** Workbook Development**/

Route::get('myworkbooks','devwb\WorkbookController@index')->name('myworkbooks');
Route::get('myworkbooks/{id}/show', ['uses'=>'devwb\WorkbookController@show','as' =>'showworkbook']);
Route::get('myworkbooks/{id}/delete', ['uses'=>'devwb\WorkbookController@destroy','as' =>'deleteworkbook']);
Route::post('newworkbook','devwb\WorkbookController@store')->name('newworkbook');
Route::patch('updateworkbooks/{id}','devwb\WorkbookController@update')->name('updateworkbooks');
Route::patch('alihkan/{id}','devwb\WorkbookController@alihkan')->name('alihkan');
Route::get('endproject/{id}','devwb\WorkbookController@endproject')->name('workbook.selesai');

Route::post('addformula','devwb\FormulaController@new')->name('addformula');
Route::get('upversion/{cf}/{id}','devwb\UpVersionController@upversion')->name('upversion');
Route::get('DetailFormula/{id}','devwb\FormulaController@detail')->name('formula.detail');

Route::get('ajukanvp/{id}','devwb\PengajuanFormulaController@vp')->name('ajukanvp');
Route::get('ajukanfs/{id}','devwb\PengajuanFormulaController@fs')->name('ajukanfs');
Route::get('ajukannf/{id}','devwb\PengajuanFormulaController@vp')->name('ajukannf');

Route::get('formulainformation/{id}','formula\Step1Controller@create')->name('step1');
Route::patch('updateformula/{id}','formula\Step1Controller@update')->name('step1update');

Route::get('penyusunanbahan/{id}','formula\Step2Controller@create')->name('step2');
Route::post('insertbahan/{id}','formula\Step2Controller@insert')->name('step2insert');
Route::post('updatebahan/{id}','formula\Step2Controller@update')->name('step2update');
Route::get('bahan/{id}/{vf}/delete','formula\Step2Controller@destroy')->name('step2destroy');

Route::get('getTemplate/{id}','devwb\TemplateFormulaController@index')->name('getTemplate');
Route::get('InsertTemplate/{ftujuan}/{fasal}','devwb\TemplateFormulaController@template')->name('insertTemplate');

Route::get('MyRamen/{id}','formula\MyRamenController@index')->name('ramen');
Route::post('MyRamenInsert/{id}','formula\MyRamenController@insert')->name('MyRamen.insert');

Route::get('EditDetailPenyusunan/{idf}/{id}','formula\EditFortailController@index')->name('editfortail');
Route::patch('SaveDetailPenyusunan/{idf}/{id}','formula\EditFortailController@update')->name('updatefortail');

Route::get('penyusunanpremix/{id}','formula\Step3Controller@create')->name('step3');

/************************************FEASIBILITY */

// FEASIBILITY
Route::get('PengajuanFormulaFeasibility','feasibility\ListFormulaController@index')->name('formula.feasibility');
Route::get('MyFeasibility/{id}','feasibility\ListFeasibilityController@index')->name('myFeasibility');
Route::get('UpFeasibility/{id}','feasibility\UpFeasibility@index')->name('upFeasibility');

// KEMAS
Route::get('KonsepKemas/{id}','kemas\KonsepController@index')->name('konsepkemas');
Route::post('InsertKonsep','kemas\KonsepController@insert')->name('insertkonsep');

Route::get('UploadKemas/{id}','kemas\KemasController@index')->name('uploadkemas');
Route::post('hasil', 'kemas\KemasController@storeData')->name('hasil');

//EVALUATOR
route::get('datamesin/{id}','mesin\MesinController@index')->name('datamesin');
route::get('inboxmesin/{id}','mesin\Mesincontroller@inbox')->name('inboxmesin');
route::get('runtimemesin/{id}','mesin\MesinController@runtimemesin')->name('runtimemesin');
route::get('runtimeoh/{id}','mesin\MesinController@runtimeoh')->name('runtimeoh');

Route::post('/updatemss/{id_mesin}', 'mesin\MesinController@runM')->name('updatemss');
Route::post('/updateohh/{id_oh}', 'mesin\MesinController@runO')->name('updateohh');
Route::get('deleteoh/{id}', 'mesinn\MesinController@destroyoh')->name('oh.destroyoh');
Route::get('deletedata/{id}', 'mesinn\MesinController@destroy')->name('mesin.destroy');

//PRODUKSI
route::get('produksi/{id}','produksi\ProduksiController@index')->name('produksi');
route::get('inboxproduksi/{id}','produksi\ProduksiController@inbox')->name('inboxproduksi');

//LAB
route::get('datalab/{id}','lab\LabController@index')->name('datalab');
route::post('Insertlab','lab\LabController@create')->name('Insertlab');

//FINANCE
route::get('finance/{id}','finance\FinanceController@index')->name('finance');
route::get('inboxfn/{id}','finance\FinanceController@inboxfn')->name('inboxfn');
route::get('komentar/{id}','finance\FinanceController@komentar')->name('komentar');
route::post('insertkomentar','finance\FinanceController@store')->name('insertkomentar');
route::get('Datamastermesin/{id}','finance\FinanceController@DMmesin')->name('DMmesin');
Route::post('Dm', 'finance\FinanceController@createDMmesin')->name('Dm');

route::get('Datamasteroh/{id}','finance\FinanceController@DMoh')->name('DMoh');
Route::post('Do', 'finance\FinanceController@createDMoh')->name('Do');



/*========================================= ADMIN =============================================*/

Route::get('datanutfact','nutfact\TbParameterFormulaController@datanut');
Route::get('datanutrition','nutfact\TbNutritionController@databb');
Route::get('datac','nutfact\TbTransaksiCemaranController@datac');
Route::get('mencaricemaran','nutfact\TbTransaksiCemaranController@dataclanjut');
Route::get('NutritionFact','devnf\TbHitungHakController@NutfactAdmin');
Route::resource('datap','nutfact\TbParameterController');
Route::get('hapusparameter/{id}','nutfact\TbParameterController@delete');
Route::get('inputp', function(){
    return view('nutfact.inputparameter');
});
Route::get('inputbtp', function(){
    return view('nutfact.inputbtp');
});
Route::get('inputc', function(){
    return view('nutfact.inputcemaran');
});
Route::get('editcemaran/{id}', 'nutfact\TbTransaksiCemaranController@edit');
Route::get('editparameter/{id}', 'nutfact\TbParameterController@edit');
Route::get('editbtp/{id}', 'TbBtpController@edit');
Route::get('mencariparameter','nutfact\TbParameterController@show');
Route::resource('kategoribtp','nutfact\TbKategoriBtpController');
Route::resource('akg','nutfact\TbAkgController');
Route::resource('ingredient','nutfact\TbIngredientController');
Route::resource('databtp','nutfact\TbBtpController');

/*======================================== DEV NF =============================================*/
Route::get('datapn','devnf\NutfactController@datapn');
Route::get('nutfactbayangan/{id}/','devnf\NutfactController@nb');
Route::resource('nutrition/{id}/', 'devnf\NutfactController@nutri');
Route::resource('datanutri/{id}/','devnf\TbAnalisaController');