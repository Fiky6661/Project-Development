@extends('admin.tempadmin')

@section('title', 'Approved User')

@section('judulnya','Approved User')

@section('content')

<div class="row">
    <div class="col-md-12">
        <div class="form-panel">

<table class="table table-striped table-advance table-hover" id="Table">
<thead>
<tr>

    <th>Nama</th>

    <th>Username</th>

    <th>Email</th>

    <th>Departement</th>

    <th>Level</th>

    <th>Status</th>

    <th>Action</th>

</tr>
</thead>

<tbody>
@foreach ($users as $user)
@if($user->status =='active' || $user->status =='nonactive')

<tr>

<td>{{ $user->name}}</td>

<td>{{ $user->username}}</td>

<td>{{ $user->email}}</td>

<td>{{ $user->departement->dept}}</td>

<td>{{ $user->role->namaRule}}</td>

@if($user->status === "nonactive")
<td>Blocked</td>
@else
<td>{{ $user->status}}</td>
@endif

<td>

    {{csrf_field()}}
    <a class="btn btn-info" href="{{ route('showuser',$user->id) }}">Lihat</a>
    @if($user->status == 'active')
    <a class="btn btn-danger" href="{{ route('userblok',$user->id) }}">Blokir</a>
    @elseif($user->status == 'nonactive')
    <a class="btn btn-primary" href="{{ route('openblok',$user->id) }}">Buka Blokir</a>
    @endif

</td>

</tr>
@endif
@endforeach
</tbody>
</table>

</div>
</div>
</div>

@endsection
