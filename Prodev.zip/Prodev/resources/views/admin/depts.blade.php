@extends('admin.tempadmin')

@section('title', 'DataDepartement')

@section('judulnya','Data Departement')

@section('content')

<div class="row">


            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif



    <div class="col-md-12">
        <div class="form-panel">
        <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Departement</a>
<table class="table table-striped table-advance table-hover" id="Table">
<thead>
<tr>

    <th>ID</th>

    <th>Departement</th>

    <th>Keterangan (Nama Departement) </th>

    <th>Manager</th>

    <th>Action</th>
        

</tr>
</thead>

<tbody>
@foreach ($depts as $dept)

<tr>

<td>{{ $dept->id}}</td>

<td>{{ $dept->dept}}</td>

<td>{{ $dept->nama_dept}}</td>

<td>
@foreach($users as $user)
@if($user->id == $dept->manager_id)
{{ $user->name}}
@endif 
@endforeach
</td>


<td>

    
    <a class="btn btn-warning" href="{{ route('updatedept',$dept->id) }}"><i class="fa fa-edit"></i> Update</a>
    <a class="btn btn-danger" onclick="return confirm('Are You Sure ?')" href="{{ route('deldept',$dept->id) }}"><i class="fa fa-times"></i> Delete</a>
    

</td>

</tr>
@endforeach
</tbody>
</table>

</div>

<div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
        <div class="form-panel" >
        <h4><i class="fa fa-plus"></i> Tambah Departement</h4>
        <form method="POST" action="{{ route('adddept') }}">
        <label for="" class="control-label">Departement</label>
        <input class="form-control" id="dept" name="dept" placeholder="Ex. RKA" required />
        <label for="" class="control-label">Keterangan</label>
        <input class="form-control" id="nama_dept" name="nama_dept" placeholder="Ex. R&D Packaging and Service" required />
        <label for="" class="control-label">Manager</label>
        <br>
            <select id="manager" name="manager" class="form-control" style="width:500px;">
                @foreach($users as $user) 
                <option value="{{  $user->id }}" {{ old('manager') == $user->id ? 'selected' : '' }}>{{ $user->role->namaRule}} - {{ $user->name }}</option>
                @endforeach
            </select>
        <br>
        <br>
        {{ csrf_field() }}
        <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
        <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
        </form>
        </div>
</div>

</div>
</div>

@endsection

@section('s')
<script type="text/javascript">
$('#manager').select2({
    placeholder: "Pilih User Sebagai Manager",
    allowClear: true
});
$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
@endsection

