@extends('admin.tempadmin')

@section('title', 'Approval')

@section('judulnya', 'User Approval')

@section('content')


<div class="row">
    <div class="col-md-12">
        <div class="form-panel">

<table class="table table-striped table-advance table-hover" id="Table">
<thead>
<tr>

    <th>Nama</th>

    <th>Username</th>

    <th>Email</th>

    <th>Departement</th>

    <th>Level</th>

    <th>Status</th>

    <th>Action</th>

</tr>
</thead>

<tbody>
@foreach ($users as $user)

@if($user->status =='sending')
<tr>

<td>{{ $user->name}}</td>

<td>{{ $user->username}}</td>

<td>{{ $user->email}}</td>

<td>{{ $user->departement->dept}}</td>

<td>{{ $user->role->namaRule}}</td>

<td>{{ $user->status}}</td>

<td>

    {{csrf_field()}}
    <a class="btn btn-primary" href="{{ route('ua.update',$user->id) }}">Approve</a>
    <a class="btn btn-danger" href="{{ route('ua.destroy',$user->id) }}">Delete</a>


</td>

</tr>   
@endif
@endforeach
</tbody>
</table>

</div>
</div>
</div>

@endsection

