@extends('devwb.tempwb')

@section('title', 'Workbook')

@section('judulnya', 'WORKBOOK LIST')

@section('content')


            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif


    <div class="col-lg-12 col-md-10 col-sm-12">
            <div class="showback">
<button class="btn btn-primary btn-lg btn-block" data-toggle="modal" data-target="#NW"><i class="fa fa-plus-circle"></i> Project Baru</button>     
<table class="table table-striped table-advance table-hover" id="Table">
<thead>
<tr>

    <th>ID</th>

    <th>Nama_Project</th>

    <th>Mandatory Requirement</th>

    <th>Target_Konsumen</th>

    <th>Status_Project</th>

    <th>Last Updated</th>

    <th>_Action_</th>

</tr>
</thead>

<tbody>
@foreach ($workbooks as $workbook)


<tr>

<td>{{ $workbook->id }}</td>

<td>{{ $workbook->nama_project}}</td>

<td>{{ $workbook->mnrq}}</td>

<td>{{ $workbook->tarkon->tarkon}}</td>

<td>{{ $workbook->keterangan}}</td>

<td>{{ $workbook->updated_at}}</td>

<td>

    {{csrf_field()}}
    <a class="btn btn-info" href="{{ route('showworkbook',$workbook->id) }}"><i class="fa fa-edit"></i></a>
    <a class="btn btn-danger" onclick="return confirm('Are You Sure Delete Project ?')" href="{{ route('deleteworkbook',$workbook->id) }}"><i class="fa fa-trash"></i></a>  

</td>

</tr>

@endforeach
</tbody>
</table>
</div>
</div>



@endsection

<!--- New Workbook --->
<div class="modal fade" id="NW" tabindex="-1" role="dialog" aria-labelledby="NWModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="NWModalLabel">Workbook Baru</h4>
                    </div>
                    <div class="modal-body">
                    <form class="cmxform form-horizontal style-form" id="new" method="POST" action="{{ route('newworkbook') }}">
                        
                        <input class="form-control " id="user" name="user" type="hidden" value="{{ Auth::user()->id }}"/>   
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Nama Project</label>
                            <div class="col-lg-8">
                            <input class="form-control " id="nama" name="nama" type="text" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Mandatory Requirement</label>
                            <div class="col-lg-8">
                            <input class="form-control " id="mnrq" name="mnrq" type="text" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Target Konsumen</label>
                            <div class="col-lg-8">
                            <select class="form-control" id="tarkon" name="tarkon">
                            @foreach($tarkons as $tarkon)
                            <option value="{{ $tarkon->id }}">{{ $tarkon->tarkon }}</option>
                            @endforeach
                            </select>
                            </div>
                        </div>
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                      <button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> ADD</button>
                        </div>
                        </form>
                  </div>
                </div>
              </div>
