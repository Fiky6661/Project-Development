@extends('formula.tempformula')

@section('title', 'Detail Formula')

@section('judul', 'Detail Formula')

@section('content')

@endsection