<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>PRODEV - Project Development</title>

  <!-- Favicons -->
  <link href="{{ asset('img/pro.png') }}" rel="icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">

</head>

<body>
  <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
  <div id="login-page">
    <div class="container">
      <form class="form-login" method="post" action="{{ route('add') }}">
        <h2 class="form-login-heading">Register Now</h2>
        <div class="login-wrap">
                    <input class="form-control" id="name" name="name" placeholder="nama" value="{{ old('name') }}" type="text" minlength="2" autofocus required/>
                    <br>
                    <input class="form-control " id="username" name="username" placeholder="username" value="{{ old('username') }}" type="text" minlength="6" maxlength="12" required/>
                    <br>
                    <input class="form-control " id="password" name="password" placeholder="password" type="password" minlength="6" maxlength="12" required/>
                    <br>
                    <input class="form-control " id="password_confirmation" name="password_confirmation" placeholder="confirm_password" type="password" required/>
                    <br>
                    <input class="form-control " id="email" name="email" placeholder="E-mail" value="{{ old('email') }}" type="email" required/>
                    <br>
                    <select id="departement" name="departement" class="form-control" >
                    <option disabled selected>Departement</option>
                    @foreach($depts as $dept)
                    <option value="{{  $dept->id }}" {{ old('departement') == $dept->id ? 'selected' : '' }}>{{ $dept->dept }}</option>
                    @endforeach
                    </select>
                    <br>
                    <select class="form-control" id="role" name="role">
                    <option disabled selected>Levels</option>
                    @foreach($roles as $role)
                    <option value="{{  $role->id }}" {{ old('role') == $role->id ? 'selected' : '' }}>{{ $role->namaRule }}</option>
                    @endforeach
                    </select>

                    <br>
          <button class="btn btn-theme btn-block" type="submit"><i class="fa fa-lock"></i> SIGN IN</button>
          {{ csrf_field() }}
          @include('formerrors')
        </form>
          <hr>
          <div class="registration">
            Already Have account ?<br/>
            <a href="{{ route('signin') }}">
              login
              </a>
          </div>
        </div>
    </div>
  </div>

  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="lib/jquery.backstretch.min.js"></script>
  <script>
    $.backstretch("img/awal.jpg", {
      speed: 1000
    });
  </script>
</body>

</html>
