@extends('admin.tempadmin')

@section('title', 'Data Maklon')

@section('content')

<div class="row">
            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif
</div>

<!-- Maklon -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
    <h4><i class="fa fa-angle-double-right"></i>List Maklon</h4>
    <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Maklon </a>
        <div class="form-panel">
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Maklon</th>
                            <th>Keterangan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($maklons as $maklon)
                        <tr>
                            <td>{{ $maklon->id }}</td>
                            <td>{{ $maklon->maklon }}</td>
                            <td>{{ $maklon->keterangan }}</td>
                            <td>
                                {!! Form::open(['method' => 'Delete', 'route' => ['maklon.destroy', $maklon->id]]) !!}
                                <a class="btn btn-primary" href="{{ route('maklon.edit',$maklon->id) }}" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <button class="btn btn-danger" onclick="return confirm('Hapus Maklon ?')"><i class="fa fa-trash-o"></i> Delete</button>
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
            <div class="form-panel" >
            <h4><i class="fa fa-plus"></i> Tambah Maklon</h4>
            <form method="POST" action="{{ route('maklon.store') }}">
            <label for="" class="control-label">Maklon</label>
            <input class="form-control" id="maklon" name="maklon" placeholder="Maklon" value="{{ old('maklon') }}" required />
            <label for="" class="control-label">Keterangan</label>
            <input class="form-control" id="keterangan" name="keterangan" placeholder="Keterangan" value="{{ old('keterangan') }}" required />
            {{ csrf_field() }}
            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

@endsection

@section('s')
<script type="text/javascript">

$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
@endsection

