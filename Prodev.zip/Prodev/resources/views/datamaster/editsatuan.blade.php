@extends('admin.tempadmin')

@section('title', 'Edit Satuan')

@section('content')

<div class="row">
    <div class="col-md-6" id="add">
            <div class="form-panel" >
            <h4><i class="fa fa-edit"></i> Edit Satuan</h4>
            <form method="POST" action="{{ route('satuan.update', $satuan->id) }}">
            <label for="" class="control-label">Satuan</label>
            <input class="form-control" id="satuan" name="satuan" placeholder="Satuan" value="{{ $satuan->satuan }}" required />
            {{ csrf_field() }}
            {{ method_field('PATCH') }}
            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-edit"></i> Simpan Perubahan</button>
            <a type="button" class="btn btn-danger" id="xx" href="{{ route('satuan.index') }}"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

@endsection