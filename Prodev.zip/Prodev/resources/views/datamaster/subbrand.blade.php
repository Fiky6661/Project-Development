@extends('admin.tempadmin')

@section('title', 'Data SubBrand')

@section('content')

<div class="row">
            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif
</div>

<!-- Subbrand -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
    <h4><i class="fa fa-angle-double-right"></i>List SubBrand</h4>
    <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Subbrand</a>
        <div class="form-panel">
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Subbrand</th>
                            <th>Brand</th>
                            <th>Manager</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($subbrands as $subbrand)
                        <tr>
                            <td>{{ $subbrand->id }}</td>
                            <td>{{ $subbrand->subbrand }}</td>
                            <td>{{ $subbrand->brand->brand }}</td>
                            <td>{{ $subbrand->user->name }}</td>
                            <td>
                                {!! Form::open(['method' => 'Delete', 'route' => ['subbrand.destroy', $subbrand->id]]) !!}
                                <a class="btn btn-primary" href="{{ route('subbrand.edit',$subbrand->id) }}" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <button class="btn btn-danger" onclick="return confirm('Hapus Subbrand ?')"><i class="fa fa-trash-o"></i> Delete</button>
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
            <div class="form-panel" >
            <h4><i class="fa fa-plus"></i> Tambah Subbrand</h4>
            <form method="POST" action="{{ route('subbrand.store') }}">
            <label for="" class="control-label">Subbrand</label>
            <input class="form-control" id="subbrand" name="subbrand" placeholder="Subbrand" value="{{ old('subbrand') }}" required />
            <br>
            <label for="" class="control-label">Brand</label>
            <br>
            <select id="brand" name="brand" class="form-control" style="width:500px;">
                    @foreach($brands as $brand) 
                    <option value="{{  $brand->id }}" {{ old('brand_id') == $brand->id ? 'selected' : '' }}>{{ $brand->brand}}</option>
                    @endforeach
            </select>
            <br>
            <label for="" class="control-label">Manager</label>
            <br>
                <select id="manager" name="manager" class="form-control" style="width:500px;">
                    @foreach($users as $user) 
                    <option value="{{  $user->id }}" {{ old('manager') == $user->id ? 'selected' : '' }}>{{ $user->role->namaRule}} - {{ $user->name }}</option>
                    @endforeach
                </select>
            <br>
            <br>
            {{ csrf_field() }}
            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

@endsection

@section('s')
<script type="text/javascript">
$('#manager').select2({
    placeholder: "Pilih User Sebagai Manager",
    allowClear: true
});
$('#brand').select2({
    placeholder: "Pilih Brand",
    allowClear: true
});
$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
@endsection

