@extends('admin.tempadmin')

@section('title', ' Edit Target Konsumen')

@section('content')
<div class="row">
    <div class="col-md-6" id="add">
            <div class="form-panel" >
            <h4><i class="fa fa-edit"></i> Edit Target Konsumen</h4>
            <form method="POST" action="{{ route('tarkon.update',$tarkon->id) }}">
            <label for="" class="control-label">Target Konsumen</label>
            <input class="form-control" id="tarkon" name="tarkon" placeholder="Target Konsumen" value="{{ $tarkon->tarkon }}" required />
            <label for="" class="control-label">Umur Dari</label>
            <input type="number" class="form-control" id="dari" name="dari" placeholder="dari" required value="{{ $tarkon->dari }}"/>
            <label for="" class="control-label">Sampai Umur</label>
            <input type="number" class="form-control" id="sampai" name="sampai" placeholder="sampai" value="{{ $tarkon->sampai }}" required />
            {{ csrf_field() }}
            {{ method_field('PATCH') }}
            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-edit"></i> Simpan Perubahan</button>
            <a type="button" class="btn btn-danger" id="xx" href="{{ route('tarkon.index') }}"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

@endsection