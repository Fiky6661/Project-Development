@extends('admin.tempadmin')

@section('title', 'Data Brand')

@section('content')

<div class="row">
            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif
</div>

<!-- BRAND -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <h4><i class="fa fa-angle-double-right"></i>List Brand</h4>
        <div class="form-panel">
        <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Brand</a>
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Brand</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($brands as $brand)
                        <tr>
                            <td>{{ $brand->id }}</td>
                            <td>{{ $brand->brand }}</td>
                            <td>{{ $brand->created_at }}</td>
                            <td>{{ $brand->updated_at }}</td>
                            <td>
                                <a class="btn btn-primary" href="{{ route('brand.edit',$brand->id) }}" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"> Edit</i></a>
                                <a class="btn btn-danger" onclick="return confirm('Hapus Bahan Baku ?')" href="{{ route('brand.destroy',$brand->id) }}"><i class="fa fa-trash-o"></i> Delete</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
        </div>
    </div>
    
</div>

<div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
        <div class="form-panel" >
        <h4><i class="fa fa-plus"></i> Tambah Brand</h4>
        <form method="POST" action="{{ route('brand.store') }}">
        <label for="nama_produk" class="control-label">Brand</label>
        <input class="form-control" id="brand" name=brand placeholder="Brand" required />
        {{ csrf_field() }}
        <br>
        <br>
        <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
        <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
        </form>
        </div>
</div>

</div>
</div>

@endsection

@section('s')
<script type="text/javascript">
$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
@endsection