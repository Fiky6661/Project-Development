@extends('admin.tempadmin')

@section('title', 'Data SubKategori')

@section('content')

<div class="row">
            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif
</div>

<!-- SubKategori -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
    <h4><i class="fa fa-angle-double-right"></i>List SubKategori</h4>
    <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah SubKategori </a>
        <div class="form-panel">
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Subkategori</th>
                            <th>Kategori</th>
                            <th>Pembulatan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($subkategoris as $subkategori)
                        <tr>
                            <td>{{ $subkategori->id }}</td>
                            <td>{{ $subkategori->subkategori }}</td>
                            <td>{{ $subkategori->kategori->kategori }}</td>
                            <td>{{ $subkategori->pembulatan }}</td>
                            <td>
                                {!! Form::open(['method' => 'Delete', 'route' => ['subkategori.destroy', $subkategori->id]]) !!}
                                <a class="btn btn-primary" href="{{ route('subkategori.edit',$subkategori->id) }}" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <button class="btn btn-danger" onclick="return confirm('Hapus SubKategori ?')"><i class="fa fa-trash-o"></i> Delete</button>
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
            <div class="form-panel" >
            <h4><i class="fa fa-plus"></i> Tambah SubKategori</h4>
            <form method="POST" action="{{ route('subkategori.store') }}">
            <label for="" class="control-label">SubKategori</label>
            <input class="form-control" id="subkategori" name="subkategori" placeholder="SubKategori" value="{{ old('subkategori') }}" required />
            <label for="" class="control-label">Pembulatan</label>
            <input type="number" step=any class="form-control" id="pembulatan" name="pembulatan" placeholder="Harga" required value="{{ old('harga') }}"/>
            <label for="" class="control-label">Kategori</label>
            <br>
            <select id="kategori" name="kategori" class="form-control" style="width:500px;">
                @foreach($kategoris as $kategori) 
                <option value="{{  $kategori->id }}" {{ old('kategori') == $kategori->id ? 'selected' : '' }}>{{ $kategori->kategori}}</option>
                @endforeach
            </select>
            {{ csrf_field() }}
            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

@endsection

@section('s')
<script type="text/javascript">

$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
@endsection

