@extends('admin.tempadmin')

@section('title', 'Data Target Konsumen')

@section('content')

<div class="row">
            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif
</div>

<!-- Target Konsumen -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
    <h4><i class="fa fa-angle-double-right"></i>List Target Konsumen</h4>
    <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Target Konsumen </a>
        <div class="form-panel">
                <table class="ALL">
                <thead>
                        <tr>
                            <th>ID</th>
                            <th>Target Konsumen</th>
                            <th>Umur Dari</th>
                            <th>Sampai</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($tarkons as $tarkon)
                        <tr>
                            <td>{{ $tarkon->id }}</td>
                            <td>{{ $tarkon->tarkon }}</td>
                            <td>{{ $tarkon->dari }}</td>
                            <td>{{ $tarkon->sampai }}</td>
                            <td>
                                {!! Form::open(['method' => 'Delete', 'route' => ['tarkon.destroy', $tarkon->id]]) !!}
                                <a class="btn btn-primary" href="{{ route('tarkon.edit',$tarkon->id) }}" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <button class="btn btn-danger" onclick="return confirm('Hapus Target Konsumen ?')"><i class="fa fa-trash-o"></i> Delete</button>
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
            <div class="form-panel" >
            <h4><i class="fa fa-plus"></i> Tambah Target Konsumen</h4>
            <form method="POST" action="{{ route('tarkon.store') }}">
            <label for="" class="control-label">Target Konsumen</label>
            <input class="form-control" id="tarkon" name="tarkon" placeholder="Target Konsumen" value="{{ old('tarkon') }}" required />
            <label for="" class="control-label">Umur Dari</label>
            <input type="number" class="form-control" id="dari" name="dari" placeholder="dari" required value="{{ old('dari') }}"/>
            <label for="" class="control-label">Sampai Umur</label>
            <input type="number" class="form-control" id="sampai" name="sampai" placeholder="sampai" value="{{ old('sampai') }}" required />
            {{ csrf_field() }}
            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

@endsection

@section('s')
<script type="text/javascript">

$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
@endsection

