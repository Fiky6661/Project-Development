@extends('admin.tempadmin')

@section('title', 'Data currency')

@section('content')

<div class="row">
            @if (session('status'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('status') }}
            </div>
            </div>
            @elseif(session('error'))
            <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
                {{ session('error') }}
            </div>
            </div>
            @endif
</div>

<!-- Currency -->

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
    <h4><i class="fa fa-angle-double-right"></i>List Currency</h4>
    <a type="button" class="btn btn-info" href="#add" id="tambah"><i class="fa fa-plus"></i> Tambah Currency </a>
        <div class="form-panel">
                <table class="ALL">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Currency</th>
                            <th>Harga</th>
                            <th>Keterangan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($currens as $curren)
                        <tr>
                            <td>{{ $curren->id }}</td>
                            <td>{{ $curren->currency }}</td>
                            <td>{{ $curren->harga }}</td>
                            <td>{{ $curren->keterangan }}</td>
                            <td>
                                {!! Form::open(['method' => 'Delete', 'route' => ['curren.destroy', $curren->id]]) !!}
                                <a class="btn btn-primary" href="{{ route('curren.edit',$curren->id) }}" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <button class="btn btn-danger" onclick="return confirm('Hapus currency ?')"><i class="fa fa-trash-o"></i> Delete</button>
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6" id="add" style="background-color:#2f323a;display:none">
            <div class="form-panel" >
            <h4><i class="fa fa-plus"></i> Tambah Currency</h4>
            <form method="POST" action="{{ route('curren.store') }}">
            <label for="" class="control-label">Currency</label>
            <input class="form-control" id="currency" name="currency" placeholder="Currency" value="{{ old('currency') }}" required />
            <label for="" class="control-label">Harga</label>
            <input type="number" step=any class="form-control" id="harga" name="harga" placeholder="Harga" required value="{{ old('harga') }}"/>
            <label for="" class="control-label">Keterangan</label>
            <input class="form-control" id="keterangan" name="keterangan" placeholder="Keterangan" value="{{ old('keterangan') }}" required />
            {{ csrf_field() }}
            <br>
            <br>
            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Submit</button>
            <a type="button" class="btn btn-danger" id="xx" href="#"><i class="fa fa-times"></i> BATAL</a>
            </form>
            </div>
    </div>
</div>

@endsection

@section('s')
<script type="text/javascript">

$(document).ready(function(){

$("#tambah").click(function(e) {
    $('#add').show();
    e.preventDefault();
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 2000);
  });

$("#xx").click(function(e) {
      $('#add').hide();
  });

});
</script>
@endsection

