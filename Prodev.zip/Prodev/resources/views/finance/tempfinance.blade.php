<!DOCTYPE html>
<html lang="en">

<head>
<title>@yield('title')</title></title>

<link href="{{ URL::asset('img/prodev.png') }}" rel="icon">
<link href="{{ URL::asset('img/apple-touch-icon.png') }}" rel="apple-touch-icon">
<link href="{{ URL::asset('lib/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('lib/advanced-datatable/css/jquery.dataTables.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('lib/advanced-datatable/css/jquery.dataTables4.min.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="{{ URL::asset('css/custom.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('lib/advanced-datatable/css/dataTables.bootstrap.css') }}" />
<link href="{{ URL::asset('css/dataTables.bootstrap4.min.css') }}">
<link href="{{ URL::asset('css/dataTables.min.css') }}">
<link href="{{ asset('css/asri.css') }}" rel="stylesheet">
<link href="{{ URL::asset('css/asri.css') }}" rel="stylesheet">
<link href="{{ URL::asset('lib/font-awesome/css/font-awesome.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('css/custom.min.css" rel="stylesheet') }}">
<link href="{{ URL::asset('css/style.css') }}" rel="stylesheet">
<link href="{{ URL::asset('css/style-responsive.css') }}" rel="stylesheet">
<link href="{{ URL::asset('lib/font-awesome/css/font-awesome.css') }}" rel="stylesheet" />

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Pro<span>dev</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
        <li><a class="btn btn-lg" href="{{ route('signout') }}"><i class="fa fa-sign-out"></i> Logout</a></li>
        <li><a class="btn btn-lg" href="{{ route('formula.feasibility') }}"><i class="fa fa-sign-out"></i> Kembali</a></li>
        </ul>
      </div>
    </header>
    
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
    <div id="sidebar" class="nav-collapse ">
  <ul class="sidebar-menu" id="nav-accordion">
    <p class="centered"><a href="profile.html"><img src="{{ URL::asset('img/prodev.png')}}" class="img-circle" width="80"></a></p>
      <h5 class="centered">Feasibility</h5>
        <li>
          <a href="{{ route('finance',$id) }}">
            <i class="fa fa-edit"></i>
              <span>Form </span>
          </a>
        </li>
        <li>
          <a href="{{ route('inboxfn',$id) }}">
            <i class="fa fa-envelope"></i>
              <span>Mail </span>
         </a>
        </li>
        <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-folder-open-o"></i>
              <span>Data Master</span>
              </a>
            <ul class="sub">
              <li><a href="{{ route('DMmesin',$id) }}">Data Mesin</a></li>
              <li><a href="{{ route('DMoh',$id) }}">Support Activity</a></li>
            </ul>
          </li>
  </ul>
 </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <section id="main-content">
      <section class="wrapperr site-min-height">
        @yield('content')
      </section>
      <!-- /wrapper -->
    </section>
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
        <strong>PT. NUTRIFOOD INDONESIA</strong>
        </p>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
    </section>
    <script src="{{ URL::asset('lib/jquery/jquery.min.js')}}"></script>
  <script type="text/javascript" language="javascript" src="{{ URL::asset('lib/advanced-datatable/js/jquery.dataTables.js')}}"></script>
  <script type="text/javascript" language="javascript" src="{{ URL::asset('lib/advanced-datatable/js/jquery.dataTables.min.js')}}"></script>
  <script src="{{ URL::asset('lib/dataTables.bootstrap.min.js')}}"></script>
  <script src="{{ URL::asset('lib/jquery-ui-1.9.2.custom.min.js')}}"></script>
  <script src="{{ URL::asset('lib/jquery-ui-1.9.2.custom.min.js')}}"></script>
  <script src="{{ URL::asset('lib/jquery-ui-1.9.2.custom.min.js')}}"></script>
  <script src="{{ URL::asset('lib/bootstrap/js/bootstrap.min.js')}}"></script>
  <script src="{{ URL::asset('lib/jquery-ui-1.9.2.custom.min.js')}}"></script>
  <script src="{{ URL::asset('lib/jquery.ui.touch-punch.min.js')}}"></script>
  <script class="include" type="text/javascript" src="{{ URL::asset('lib/jquery.dcjqaccordion.2.7.js')}}"></script>
  <script src="{{ URL::asset('lib/jquery.scrollTo.min.js')}}"></script>
  <script src="{{ URL::asset('lib/jquery.nicescroll.js')}}" type="text/javascript"></script>
  <script src="{{ URL::asset('lib/common-scripts.js')}}"></script>
	<script src="{{ URL::asset('lib/bootstrap/bootstrap.min.js')}}" type="text/javascript"></script>
  <script src="{{ URL::asset('js/datatables.min.js')}}"</script>
  <script src="{{ URL::asset('lib/dataTables.bootstrap4.min.css')}}"</script>
  <script type="text/javascript">$('.Table').DataTable({
      "language": {
        "search": "Cari :",
        "lengthMenu": "Tampilkan _MENU_ data",
        "zeroRecords": "Tidak ada data",
        "emptyTable": "Tidak ada data",
        "info": "Menampilkan data _START_  - _END_  dari _TOTAL_ data",
        "infoEmpty": "Tidak ada data",
        "paginate": {
          "first": "Awal",
          "last": "Akhir",
          "next": ">",
          "previous": "<"
        }
      }
    });</script>
    <script>
    $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever')
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
</script>
<script type="text/javascript">
  $('#kategori').on('change',function(e){
    console.log(e);
    var kategori=e.target.value;
    $.get('/json-workcenter?kategori='+kategori,function(data){
      console.log(data);
      $('#workcenter').empty();
      $('#workcenter').append(' <option value="0" disable="true" selected="true">--><--</option>');

    $.each(data,function(index,workcenterobj){
      $('#workcenter').append('<option value="'+workcenterobj.id+'">'+ workcenterobj.kategori +'</option>');
    }
    });
  });
  </script>

</body>

</html>