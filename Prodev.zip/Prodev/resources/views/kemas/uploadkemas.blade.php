@extends('feasibility.tempfeasibility')

@section('title', 'feasibility|kemas')

@section('judulnya', 'List Feasibility')

@section('content')

<div class="panel panel-default">
	<div class="panel-heading">
		<h3>Import Data Kemas</h3>
	</div>
	<div class="panel-body">
		<form action="{{ route('hasil') }}" method="post" enctype="multipart/form-data">
			{{ csrf_field() }}

			@if (session('success'))
			<div class="alert alert-success">
				{{ session('success') }}
			</div>
			@endif

			@if (session('error'))
			<div class="alert alert-success">
				{{ session('error') }}
			</div>
			@endif
			<div class="form-group">
				<div>
					<input type="hidden" name="finance" maxlength="45" required="required" value="{{$fe->id}}" class="form-control col-md-7 col-xs-12">
				</div>
				<label for="">File (.csv)</label>
				<input type="file" class="form-control" name="file">
				<p class="text-danger">{{ $errors->first('file') }}</p>
			</div>
			<div class="form-group">
				<button class="btn btn-primary btn-sm">Upload</button>
			</div>
		</form>

	</div>
</div>

@endsection