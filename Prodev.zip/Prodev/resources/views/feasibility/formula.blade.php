@extends('feasibility.tempfeasibility')

@section('title', 'Formula')

@section('judulnya', 'FORMULA LIST')

@section('content')

<div class="row">
  <div class="col-md-12"> 
    <div class="showback" style="border-radius:3px;">
      <table class="table table-hover table-bordered">
        <thead>
          
        <tr>
            <th class="text-center">No</th>
            <th class="text-center">Nama Pengirim</th>
            <th class="text-center">Departement</th>
            <th class="text-center">Nama Produk</th>
            <th class="text-center">Project</th>
            <th class="text-center">Tanggal Masuk</th>
            <th class="text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>
        @foreach($formulas as $formula)
          <tr>
            <td class="text-center">{{ $formula->id }}</td>
            <td class="text-center">{{ $formula->workbook->user->name}}</td>
            <td class="text-center">{{ $formula->workbook->user->departement->dept}}</td>
            <td class="text-center">{{ $formula->nama_produk }}</td>
            <td class="text-center">{{ $formula->workbook->nama_project}}</td>
            <td class="text-center">{{ $formula->updated_at }}</td>
              <div class="btn-group">
              <td class="text-center"><a href="{{ route('myFeasibility',$formula->id) }}" type="submit" data-toggle="tooltip" title="Lihat" class="btn btn-primary fa fa-folder-open"></a>
              </div>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>

@endsection