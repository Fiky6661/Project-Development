@extends('feasibility.tempfeasibility')

@section('title', 'feasibility')

@section('judulnya', 'List Feasibility')

@section('content')

<div class="row">
  <div class="col-md-12"> 
  
    <div class="showback" style="border-radius:3px;">
    <table>
    
    <tr><h4>Nama Produk : {{$myFormula->nama_produk }}</h4></tr>
    <tr><h4>Project : {{ $myFormula->workbook->nama_project }}</h4></tr>
    <tr><h4>Tanggal masuk : {{ $myFormula->updated_at }}</h4></tr>
    <tr><h4>Tambah Data : 
    <a class="btn btn-primary btn-sm fa fa-plus" data-toggle="tooltip" data-placement="top" title="tambah Data" href="{{ route('upFeasibility',$myFormula->id) }}"></a></h4>
    </tr>
    
  </table>
      <table class="table table-hover table-bordered ">
        <thead>
        
        <tr>
            <th class="text-center">Feasibility</th>
            <th class="text-center">Status Evaluator</th>
            <th class="text-center">Status Produksi</th>
            <th class="text-center">Status Kemas</th>
            <th class="text-center">Status Lab</th>
            <th class="text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>
        @foreach($dataF as $dF)
          <tr>
            <td class="text-center">{{ $dF->kemungkinan }}</td>
            <td class="text-center">{{ $dF->status_mesin }}</td>
            <td class="text-center">{{ $dF->status_sdm }}</td>
            <td class="text-center">{{ $dF->status_kemas }}</td>
            <td class="text-center">{{ $dF->status_lab }}</td>
            <td class="text-center">

            @if(auth()->user()->role->namaRule === 'evaluator')
            <a href="{{ route('datamesin',$dF->id_feasibility) }}" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            @elseif(auth()->user()->role->namaRule === 'kemas')
            <a href="{{ route('konsepkemas',$dF->id_feasibility) }}" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            @elseif(auth()->user()->role->namaRule === 'lab')
            <a href="{{ route('datalab',$dF->id_feasibility) }}" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            @elseif(auth()->user()->role->namaRule === 'produksi')
            <a href="{{ route('produksi',$dF->id_feasibility) }}" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            @elseif(auth()->user()->role->namaRule === 'finance')
            <a href="{{ route('finance',$dF->id_feasibility) }}" type="submit" class="btn btn-primary fa fa-edit" data-toggle="tooltip" data-placement="top" title="Edit"></a>
            @endif

            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>

@endsection