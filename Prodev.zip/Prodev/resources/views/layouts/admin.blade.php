<!DOCTYPE html>
<html lang="en">

<head>
<title>@yield('title')</title></title>

<!-- Favicons -->
<link href="{{ asset('img/pro.png') }}" rel="icon">
<link href="{{ asset('img/apple-touch-icon.png') }}" rel="apple-touch-icon">
<link href="{{ asset('lib/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('lib/advanced-datatable/css/jquery.dataTables.css') }}" rel="stylesheet" />
<link href="{{ asset('lib/advanced-datatable/css/jquery.dataTables.min.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="{{ asset('lib/advanced-datatable/css/dataTables.bootstrap.css') }}" />
<link href="{{ asset('css/dataTables.bootstrap4.min.css') }}">
<link href="{{ asset('css/dataTables.min.css') }}">
<link href="{{ asset('lib/font-awesome/css/font-awesome.css') }}" rel="stylesheet" />
<link href="{{ asset('css/custom.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/style.css') }}" rel="stylesheet">
<link href="{{ asset('css/style-responsive.css') }}" rel="stylesheet">
<link href="{{ asset('lib/font-awesome/css/font-awesome.css') }}" rel="stylesheet" />

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a class="logo"><b>Pro<span>dev</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
      </div>
      <div class="top-menu">
      <br>
        <ul class="nav pull-right top-menu">
        @if( auth()->check() )
        <li><a class="btn btn-lg" href="{{ route('MyProfile') }}"><i class="fa fa-user"></i> Hello,{{ Auth::user()->name }}</a></li>
        @endif
          <li><a href="signout" class="btn btn-lg"><i class="fa fa-sign-out"></i> Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
 @yield('menu')
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <section id="main-content">
      <section class="wrapper site-min-height">
        @yield('content')
      </section>
      <!-- /wrapper -->
    </section>
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
        <strong>PT. NUTRIFOOD INDONESIA</strong>
        </p>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
    </section>
    <script src="{{ asset('lib/jquery/jquery.min.js') }}"></script>
  <script type="text/javascript" language="javascript" src="{{ asset('lib/advanced-datatable/js/jquery.dataTables.js') }}"></script>
  <script type="text/javascript" language="javascript" src="{{ asset('lib/advanced-datatable/js/jquery.dataTables.min.js') }}"></script>
  <script src="{{ asset('lib/dataTables.bootstrap.min.js') }}"></script>
  <script src="{{ asset('lib/jquery-ui-1.9.2.custom.min.js') }}"></script>
  <script src="{{ asset('lib/bootstrap/js/bootstrap.min.js') }}"></script>
  <script src="{{ asset('lib/jquery-ui-1.9.2.custom.min.js') }}"></script>
  <script src="{{ asset('lib/jquery.ui.touch-punch.min.js') }}"></script>
  <script class="include" type="text/javascript" src="{{ asset('lib/jquery.dcjqaccordion.2.7.js') }}"></script>
  <script src="{{ asset('lib/jquery.scrollTo.min.js') }}"></script>
  <script src="{{ asset('lib/jquery.nicescroll.js') }}" type="text/javascript"></script>
  <script src="{{ asset('lib/common-scripts.js') }}"></script>
	<script src="{{ asset('lib/bootstrap/bootstrap.min.js') }}" type="text/javascript"></script>
  <script src="{{ asset('js/datatables.min.js') }}"></script>
  <script src="{{ asset('lib/dataTables.bootstrap4.min.css') }}"></script>
  <script type="text/javascript">$('#sampleTable').DataTable({
      "language": {
        "search": "Cari :",
        "lengthMenu": "Tampilkan _MENU_ data",
        "zeroRecords": "Tidak ada data",
        "emptyTable": "Tidak ada data",
        "info": "Menampilkan data _START_  - _END_  dari _TOTAL_ data",
        "infoEmpty": "Tidak ada data",
        "paginate": {
          "first": "Awal",
          "last": "Akhir",
          "next": ">",
          "previous": "<"
        }
      }
    });</script>
    <script type="text/javascript">$('#Table').DataTable({
      "language": {
        "search": "Cari :",
        "lengthMenu": "Tampilkan _MENU_ data",
        "zeroRecords": "Tidak ada data",
        "emptyTable": "Tidak ada data",
        "info": "Menampilkan data _START_  - _END_  dari _TOTAL_ data",
        "infoEmpty": "Tidak ada data",
        "paginate": {
          "first": "Awal",
          "last": "Akhir",
          "next": ">",
          "previous": "<"
        }
      }
    });</script>
</body>

</html>