@extends('mesin.tempmesin')

@section('title', 'feasibility|Inputor')

@section('judulnya', 'List Feasibility')

@section('content')
<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="form-panel">
      <div class="panel panel-default">
	      <div class="panel-heading">
      	<h2>*Filter Data</h2>
      	</div>
    </div>
  <div>
  <button type="button" class="btn btn-primary fa fa-plus" data-toggle="modal" data-target="#exampleModal" "> Mesin Baru</button>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content text-left">
          <div class="modal-header">
            <h3 class="modal-title" id="exampleModalLabel">Mesin Baru
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button></h3>
          </div>
          <div class="modal-body">
            <form >
            <div class="form-group">
                <label for="recipient-name" class="col-form-label">Mesin:</label>
                <input id="SDM" value="" name="SDM" class="date-picker form-control" type="text">
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Runtime:</label>
                <input id="SDM" value="" name="SDM" class="date-picker form-control" type="text">
              </div></div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
                        </div>
                      </div>
                    </div>
                  </div>
      <div id="DM" class="tab-pane active">
                <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="/mss" method="post">
                  <div class="row">
                    <div class="col-lg-12 detailed">
                      
                        
                        <table id="example" class="display" cellspacing="0" width="100%" >
                        <tfoot>
                            <tr>
                              <th style="display:none;"></th>
                              <th>workcenter</th>
                              <th style="display:none;"></th>
                              <th class="hidden-phone">kategori</th>
                              <th style="display:none;"></th>
                              <th style="display:none;"></th>
                            </tr>
                          </tfoot>
                          <thead>
                            <tr>
                            <th></th>
                              <th>workcenter</th>
                              <th>gedung</th>
                              <th class="hidden-phone">kategori</th>
                              <th class="hidden-phone">Activity</th>
                              <th class="hidden-phone">nama kategori</th>
                            </tr>
                          </thead>

                          

                          <tbody>
                          <div class="col-md-1 col-sm-1 col-xs-12">
                              <input type="hidden" name="finance" maxlength="45" required="required" value="{{$fe->id_feasibility}}" class="form-control col-md-7 col-xs-12">
                              </div>
                              @foreach($mesins as $mesin)
                              <tr>
                                <td><input type="checkbox" id="pmesin" name="pmesin[]" value="{{ $mesin->id_data_mesin }}"></td>
                                <td>{{ $mesin->workcenter }}</td>
                                <td>{{ $mesin->gedung }}</td>
                                <td>{{ $mesin->Direct_Activity }}</td>
                                <td>{{ $mesin->kategori }}</td>
                                <td>{{ $mesin->nama_kategori }}</td>
                              </tr>
                              @endforeach
                          </tbody>
                        </table>
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">                        
                      <a href='{!! url('/list-mesin'); !!}' class="btn btn-danger" type="button">Cancel</a>
                        <button type="submit" class="btn btn-success">Submit</button>
			                    {{ csrf_field() }}
                      </div>
                    </div>
                  </div>
                </form>
              </div>
      </div>
    </div>
</div>
<script>
  
</script>

@endsection