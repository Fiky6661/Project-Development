@extends('formula.tempformula')

@section('title', 'Edit Formula')

@section('judul', 'Edit Formula')

@section('content')

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12"></div>
<div class="col-lg-8 col-md-8 col-sm-12">
<div class="tabbable">
  <ul class="nav nav-tabs wizard">
    <li class="completed"><a href="{{ route('step1',$formula->id) }}" ><span class="nmbr">1</span>Informasi Formula</a></li>
    <li class="completed"><a href="{{ route('step2',$formula->id) }}"><span class="nmbr">2</span>Penyusunan</a></li>
    <li class="active"><a href="{{ route('step3',$formula->id) }}"><span class="nmbr">3</span>Premixs</a></li>
</ul>
</div>
</div>
</div>

<div class="row">
                            <div class="col-md-12">
                        
                            <div class="form-panel">
                            <h3>PREMIX</h3>

                        <form name="add_name" id="add_name">
                        <table class="table table-stripe">
                        <tr>
                        <th >No</th>
                        <th >Nama_Sederhana</th>
                        <th >Per Serving</th>
                        <th >Per Batch</th>
                        <th style="width:50px;">ke-1</th>
                        <th style="width:50px;">ke-2</th>
                        <th style="width:50px;">ke-3</th>
                        <th style="width:50px;">ke-4</th>
                        <th style="width:50px;">ke-5</th>
                        <th style="width:50px;">ke-6</th>
                        <th style="width:50px;">ke-7</th>
                        <th style="width:50px;">ke-8</th>
                        <th style="width:50px;">ke-9</th>
                        <th style="width:50px;">ke-10</th>
                        </tr>

                        @foreach($fortails as $fortail)
                        <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $fortail->nama_bahan }}</td>
                        <td><input type="number" name="ps" placeholder="per_serving" class="form-control" value="{{ $fortail->per_serving }}"/></td>
                        <td><input type="number" name="pb" placeholder="per_batch" class="form-control" value="{{ $fortail->per_batch }}" /></td>
                        <td><input type="number" name="ns" class="form-control" /></td>
                        <td><input type="number" name="ps" class="form-control" /></td>
                        <td><input type="number" name="pb" class="form-control" /></td>
                        <td><input type="number" name="pb" class="form-control" /></td>
                        <td><input type="number" name="ns" class="form-control" /></td>
                        <td><input type="number" name="ps" class="form-control" /></td>
                        <td><input type="number" name="pb" class="form-control" /></td>
                        <td><input type="number" name="pb" class="form-control" /></td>
                        <td><input type="number" name="ns" class="form-control" /></td>
                        <td><input type="number" name="ps" class="form-control" /></td>
                        </tr>
                        @endforeach

                    </table>

                            <button type="button" class="btn btn-default prev-step">Previous</button>
                            <button type="button" class="btn btn-primary next-step">Save and continue</button>

                            </form>
                        </div>
                    </div>
            </div>

@endsection