@extends('pv.tempvv')

@section('title', 'Approval Formula')

@section('content')

<div class="row mt">
          <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="showback">
                <h4>FORMULA YANG SEDANG DIPROSES</h4>
                <table class="table table-striped table-advance table-hover" id="Table">

                <tr>

                <th>ID</th>
                <th>User</th>
                <th>Departement</th>
                <th>Kode Formula</th>
                <th>Nama Produk</th>
                <th>Revisi</th>
                <th>Versi</th>
                <th>PV</th>
                <th>Action</th>

                </tr>

              @foreach ($formulas as $formula)

              <tr>

              <td>{{ $formula->id}}</td>
              <td>{{ $formula->workbook->user->name }}</td>
              <td>{{ $formula->workbook->user->departement->dept }}</td>
              <td>{{ $formula->kode_formula}}</td>
              <td>{{ $formula->nama_produk}}</td>
              <td>{{ $formula->revisi}}</td>
              <td>{{ $formula->versi}}</td>
              <td>{{ $formula->vv}}</td>

              <td>

              {{csrf_field()}}
              <a class="btn btn-primary" href="">Lihat</a>
              <a class="btn btn-info" href="{{ route('approveformula',$formula->id) }}">Approve</a>
              <a class="btn btn-warning" href="{{ route('rejectformula',$formula->id) }}">Reject</a>
              </td>

              </tr>
              @endforeach
                
                </table>

              </div>

@endsection


