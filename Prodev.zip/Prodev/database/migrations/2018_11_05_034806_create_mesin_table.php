<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMesinTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fs_mesin', function (Blueprint $table) {
            $table->increments('id_mesin');
            $table->integer('id_feasibility')->unsigned();
            $table->integer('id_data_mesin')->nullable();
            $table->integer('runtime')->nullable();
            $table->integer('SDM')->nullable();
            $table->integer('rate_mesin')->nullable();
            $table->integer('rate_sdm')->nullable();
            $table->integer('standar_sdm')->nullable();
            $table->integer('id_chat')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fs_mesin');
    }
}
