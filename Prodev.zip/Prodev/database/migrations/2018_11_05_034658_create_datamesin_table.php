<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDatamesinTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fs_datamesin', function (Blueprint $table) {
            $table->increments('id_data_mesin');
            $table->enum('workcenter', ['ciawi', 'sentul', 'cibitung']);
            $table->enum('gedung', ['CIAWI_GD D','CIAWI_GD A','CIAWI_GD G','CIAWI_GD H','CIBITUNG_PROD DAIRY','CIBITUNG_PROD NS','SENTUL_PROD SENTUL']);
            $table->enum('kategori',['mixing', 'filling', 'packing']);
            $table->string('Direct_Activity', 225);
            $table->string('nama_kategori',150);
            $table->double('rate_mesin')->nullable();
            $table->integer('defaultSDM')->nullable();
            $table->double('harga_SDM')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fs_datamesin');
    }
}
