<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLabTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fs_biaya_lab', function (Blueprint $table) {
            $table->increments('id_lab');
            $table->integer('id_feasibility')->unsigned();
            $table->string('refer_exist', 50);
            $table->string('nama_item', 100);
            $table->integer('jumlah_sample');
            $table->integer('parameter');
            $table->double('total');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fs_biaya_lab');
    }
}
